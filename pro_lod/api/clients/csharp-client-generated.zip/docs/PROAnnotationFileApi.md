# IO.Swagger.Api.PROAnnotationFileApi

All URIs are relative to *https://research.bioinformatics.udel.edu/PRO_API/V1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetPROAnnotationsByPROIDs**](PROAnnotationFileApi.md#getproannotationsbyproids) | **GET** /paf/{proIds} | Returns annotations for the given PRO ID(s).

<a name="getproannotationsbyproids"></a>
# **GetPROAnnotationsByPROIDs**
> List<Annotation> GetPROAnnotationsByPROIDs (string proIds)

Returns annotations for the given PRO ID(s).

Gets annotations for the given PRO ID(s).

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetPROAnnotationsByPROIDsExample
    {
        public void main()
        {
            var apiInstance = new PROAnnotationFileApi();
            var proIds = proIds_example;  // string | PRO ID(s). Space separated values accepted up to 100.

            try
            {
                // Returns annotations for the given PRO ID(s).
                List&lt;Annotation&gt; result = apiInstance.GetPROAnnotationsByPROIDs(proIds);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling PROAnnotationFileApi.GetPROAnnotationsByPROIDs: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **proIds** | **string**| PRO ID(s). Space separated values accepted up to 100. | 

### Return type

[**List<Annotation>**](Annotation.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml, text/tab-separated-values

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
