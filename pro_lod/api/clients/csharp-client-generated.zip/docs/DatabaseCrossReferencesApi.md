# IO.Swagger.Api.DatabaseCrossReferencesApi

All URIs are relative to *https://research.bioinformatics.udel.edu/PRO_API/V1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetPROTermsWithEcoCyCId**](DatabaseCrossReferencesApi.md#getprotermswithecocycid) | **GET** /dbxrefs/EcoCyc_ID | Returns a list of PRO terms with EcoCyC ID as cross-reference.
[**GetPROTermsWithHGNCId**](DatabaseCrossReferencesApi.md#getprotermswithhgncid) | **GET** /dbxrefs/HGNC_ID | Returns a list of PRO terms with HGNC ID as cross-reference.
[**GetPROTermsWithMGIId**](DatabaseCrossReferencesApi.md#getprotermswithmgiid) | **GET** /dbxrefs/MGI_ID | Returns a list of PRO terms with MGI ID as cross-reference.
[**GetPROTermsWithNCBITaxonID**](DatabaseCrossReferencesApi.md#getprotermswithncbitaxonid) | **GET** /dbxrefs/NCBITaxon_ID | Returns a list of PRO terms with NCBI Taxon ID as cross-reference.
[**GetPROTermsWithOntologyId**](DatabaseCrossReferencesApi.md#getprotermswithontologyid) | **GET** /dbxrefs/Ontology_ID | Returns a list of PRO terms with Ontology ID as cross-reference.
[**GetPROTermsWithPANTHERId**](DatabaseCrossReferencesApi.md#getprotermswithpantherid) | **GET** /dbxrefs/PANTHER_ID | Returns a list of PRO terms with PANTHER ID as cross-reference.
[**GetPROTermsWithPIRSFId**](DatabaseCrossReferencesApi.md#getprotermswithpirsfid) | **GET** /dbxrefs/PIRSF_ID | Returns a list of PRO terms with PIRSF ID as cross-reference.
[**GetPROTermsWithPMID**](DatabaseCrossReferencesApi.md#getprotermswithpmid) | **GET** /dbxrefs/PMID | Returns a list of PRO terms with PMID as cross-reference.
[**GetPROTermsWithReactomeID**](DatabaseCrossReferencesApi.md#getprotermswithreactomeid) | **GET** /dbxrefs/Reactome_ID | Returns a list of PRO terms with Reactome ID as cross-reference.
[**GetPROTermsWithUniProtKBID**](DatabaseCrossReferencesApi.md#getprotermswithuniprotkbid) | **GET** /dbxrefs/UniProtKB_ID | Returns a list of PRO terms with UniProtKB ID as cross-reference.

<a name="getprotermswithecocycid"></a>
# **GetPROTermsWithEcoCyCId**
> List<PROTerm> GetPROTermsWithEcoCyCId (string searchField = null, string searchValue = null, bool? showPROName = null, bool? showPROTermDefinition = null, bool? showCategory = null, bool? showEcoCycID = null, bool? showAnnotation = null, bool? showAnyRelationship = null, bool? showChild = null, bool? showComment = null, bool? showGeneName = null, bool? showHGNCID = null, bool? showMGIID = null, bool? showOrthoIsoform = null, bool? showOrthoModifiedForm = null, bool? showPANTHERID = null, bool? showPIRSFID = null, bool? showPMID = null, bool? showReactomeID = null, bool? showSynonym = null, bool? showUniProtKBID = null, int? offset = null, int? limit = null)

Returns a list of PRO terms with EcoCyC ID as cross-reference.

Gets a list of PRO terms with EcoCyC ID as cross-reference and associated information.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetPROTermsWithEcoCyCIdExample
    {
        public void main()
        {
            var apiInstance = new DatabaseCrossReferencesApi();
            var searchField = searchField_example;  // string | Search field that needs to be considered for filter (optional) 
            var searchValue = searchValue_example;  // string | any string or \"null\" or \"not null\" or a list of space separated ids (optional) 
            var showPROName = true;  // bool? |  (optional)  (default to true)
            var showPROTermDefinition = true;  // bool? |  (optional)  (default to true)
            var showCategory = true;  // bool? |  (optional)  (default to true)
            var showEcoCycID = true;  // bool? |  (optional)  (default to true)
            var showAnnotation = true;  // bool? |  (optional)  (default to false)
            var showAnyRelationship = true;  // bool? |  (optional)  (default to false)
            var showChild = true;  // bool? |  (optional)  (default to false)
            var showComment = true;  // bool? |  (optional)  (default to false)
            var showGeneName = true;  // bool? |  (optional)  (default to false)
            var showHGNCID = true;  // bool? |  (optional)  (default to false)
            var showMGIID = true;  // bool? |  (optional)  (default to false)
            var showOrthoIsoform = true;  // bool? |  (optional)  (default to false)
            var showOrthoModifiedForm = true;  // bool? |  (optional)  (default to false)
            var showPANTHERID = true;  // bool? |  (optional)  (default to false)
            var showPIRSFID = true;  // bool? |  (optional)  (default to false)
            var showPMID = true;  // bool? |  (optional)  (default to false)
            var showReactomeID = true;  // bool? |  (optional)  (default to false)
            var showSynonym = true;  // bool? |  (optional)  (default to false)
            var showUniProtKBID = true;  // bool? |  (optional)  (default to false)
            var offset = 56;  // int? | The number of items to skip before starting to collect the result set. (optional)  (default to 0)
            var limit = 56;  // int? | The numbers of items to return. (optional)  (default to 50)

            try
            {
                // Returns a list of PRO terms with EcoCyC ID as cross-reference.
                List&lt;PROTerm&gt; result = apiInstance.GetPROTermsWithEcoCyCId(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showEcoCycID, showAnnotation, showAnyRelationship, showChild, showComment, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DatabaseCrossReferencesApi.GetPROTermsWithEcoCyCId: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **string**| Search field that needs to be considered for filter | [optional] 
 **searchValue** | **string**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **showPROName** | **bool?**|  | [optional] [default to true]
 **showPROTermDefinition** | **bool?**|  | [optional] [default to true]
 **showCategory** | **bool?**|  | [optional] [default to true]
 **showEcoCycID** | **bool?**|  | [optional] [default to true]
 **showAnnotation** | **bool?**|  | [optional] [default to false]
 **showAnyRelationship** | **bool?**|  | [optional] [default to false]
 **showChild** | **bool?**|  | [optional] [default to false]
 **showComment** | **bool?**|  | [optional] [default to false]
 **showGeneName** | **bool?**|  | [optional] [default to false]
 **showHGNCID** | **bool?**|  | [optional] [default to false]
 **showMGIID** | **bool?**|  | [optional] [default to false]
 **showOrthoIsoform** | **bool?**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **bool?**|  | [optional] [default to false]
 **showPANTHERID** | **bool?**|  | [optional] [default to false]
 **showPIRSFID** | **bool?**|  | [optional] [default to false]
 **showPMID** | **bool?**|  | [optional] [default to false]
 **showReactomeID** | **bool?**|  | [optional] [default to false]
 **showSynonym** | **bool?**|  | [optional] [default to false]
 **showUniProtKBID** | **bool?**|  | [optional] [default to false]
 **offset** | **int?**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int?**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**List<PROTerm>**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="getprotermswithhgncid"></a>
# **GetPROTermsWithHGNCId**
> List<PROTerm> GetPROTermsWithHGNCId (string searchField = null, string searchValue = null, bool? showPROName = null, bool? showPROTermDefinition = null, bool? showCategory = null, bool? showParent = null, bool? showHGNCID = null, bool? showAnnotation = null, bool? showAnyRelationship = null, bool? showChild = null, bool? showComment = null, bool? showEcoCycID = null, bool? showGeneName = null, bool? showMGIID = null, bool? showOrthoIsoform = null, bool? showOrthoModifiedForm = null, bool? showPANTHERID = null, bool? showPIRSFID = null, bool? showPMID = null, bool? showReactomeID = null, bool? showSynonym = null, bool? showUniProtKBID = null, int? offset = null, int? limit = null)

Returns a list of PRO terms with HGNC ID as cross-reference.

Gets a list of PRO terms with HGNC ID as cross-reference and associated information.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetPROTermsWithHGNCIdExample
    {
        public void main()
        {
            var apiInstance = new DatabaseCrossReferencesApi();
            var searchField = searchField_example;  // string | Search field that needs to be considered for filter (optional) 
            var searchValue = searchValue_example;  // string | any string or \"null\" or \"not null\" or a list of space separated ids (optional) 
            var showPROName = true;  // bool? |  (optional)  (default to true)
            var showPROTermDefinition = true;  // bool? |  (optional)  (default to true)
            var showCategory = true;  // bool? |  (optional)  (default to true)
            var showParent = true;  // bool? |  (optional)  (default to true)
            var showHGNCID = true;  // bool? |  (optional)  (default to true)
            var showAnnotation = true;  // bool? |  (optional)  (default to false)
            var showAnyRelationship = true;  // bool? |  (optional)  (default to false)
            var showChild = true;  // bool? |  (optional)  (default to false)
            var showComment = true;  // bool? |  (optional)  (default to false)
            var showEcoCycID = true;  // bool? |  (optional)  (default to false)
            var showGeneName = true;  // bool? |  (optional)  (default to false)
            var showMGIID = true;  // bool? |  (optional)  (default to false)
            var showOrthoIsoform = true;  // bool? |  (optional)  (default to false)
            var showOrthoModifiedForm = true;  // bool? |  (optional)  (default to false)
            var showPANTHERID = true;  // bool? |  (optional)  (default to false)
            var showPIRSFID = true;  // bool? |  (optional)  (default to false)
            var showPMID = true;  // bool? |  (optional)  (default to false)
            var showReactomeID = true;  // bool? |  (optional)  (default to false)
            var showSynonym = true;  // bool? |  (optional)  (default to false)
            var showUniProtKBID = true;  // bool? |  (optional)  (default to false)
            var offset = 56;  // int? | The number of items to skip before starting to collect the result set. (optional)  (default to 0)
            var limit = 56;  // int? | The numbers of items to return. (optional)  (default to 50)

            try
            {
                // Returns a list of PRO terms with HGNC ID as cross-reference.
                List&lt;PROTerm&gt; result = apiInstance.GetPROTermsWithHGNCId(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showHGNCID, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DatabaseCrossReferencesApi.GetPROTermsWithHGNCId: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **string**| Search field that needs to be considered for filter | [optional] 
 **searchValue** | **string**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **showPROName** | **bool?**|  | [optional] [default to true]
 **showPROTermDefinition** | **bool?**|  | [optional] [default to true]
 **showCategory** | **bool?**|  | [optional] [default to true]
 **showParent** | **bool?**|  | [optional] [default to true]
 **showHGNCID** | **bool?**|  | [optional] [default to true]
 **showAnnotation** | **bool?**|  | [optional] [default to false]
 **showAnyRelationship** | **bool?**|  | [optional] [default to false]
 **showChild** | **bool?**|  | [optional] [default to false]
 **showComment** | **bool?**|  | [optional] [default to false]
 **showEcoCycID** | **bool?**|  | [optional] [default to false]
 **showGeneName** | **bool?**|  | [optional] [default to false]
 **showMGIID** | **bool?**|  | [optional] [default to false]
 **showOrthoIsoform** | **bool?**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **bool?**|  | [optional] [default to false]
 **showPANTHERID** | **bool?**|  | [optional] [default to false]
 **showPIRSFID** | **bool?**|  | [optional] [default to false]
 **showPMID** | **bool?**|  | [optional] [default to false]
 **showReactomeID** | **bool?**|  | [optional] [default to false]
 **showSynonym** | **bool?**|  | [optional] [default to false]
 **showUniProtKBID** | **bool?**|  | [optional] [default to false]
 **offset** | **int?**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int?**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**List<PROTerm>**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="getprotermswithmgiid"></a>
# **GetPROTermsWithMGIId**
> List<PROTerm> GetPROTermsWithMGIId (string searchField = null, string searchValue = null, bool? showPROName = null, bool? showPROTermDefinition = null, bool? showCategory = null, bool? showParent = null, bool? showMGIID = null, bool? showAnnotation = null, bool? showAnyRelationship = null, bool? showChild = null, bool? showComment = null, bool? showEcoCycID = null, bool? showGeneName = null, bool? showHGNCID = null, bool? showOrthoIsoform = null, bool? showOrthoModifiedForm = null, bool? showPANTHERID = null, bool? showPIRSFID = null, bool? showPMID = null, bool? showReactomeID = null, bool? showSynonym = null, bool? showUniProtKBID = null, int? offset = null, int? limit = null)

Returns a list of PRO terms with MGI ID as cross-reference.

Gets a list of PRO terms with MGI ID as cross-reference and associated information.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetPROTermsWithMGIIdExample
    {
        public void main()
        {
            var apiInstance = new DatabaseCrossReferencesApi();
            var searchField = searchField_example;  // string | Search field that needs to be considered for filter (optional) 
            var searchValue = searchValue_example;  // string | any string or \"null\" or \"not null\" or a list of space separated ids (optional) 
            var showPROName = true;  // bool? |  (optional)  (default to true)
            var showPROTermDefinition = true;  // bool? |  (optional)  (default to true)
            var showCategory = true;  // bool? |  (optional)  (default to true)
            var showParent = true;  // bool? |  (optional)  (default to true)
            var showMGIID = true;  // bool? |  (optional)  (default to true)
            var showAnnotation = true;  // bool? |  (optional)  (default to false)
            var showAnyRelationship = true;  // bool? |  (optional)  (default to false)
            var showChild = true;  // bool? |  (optional)  (default to false)
            var showComment = true;  // bool? |  (optional)  (default to false)
            var showEcoCycID = true;  // bool? |  (optional)  (default to false)
            var showGeneName = true;  // bool? |  (optional)  (default to false)
            var showHGNCID = true;  // bool? |  (optional)  (default to false)
            var showOrthoIsoform = true;  // bool? |  (optional)  (default to false)
            var showOrthoModifiedForm = true;  // bool? |  (optional)  (default to false)
            var showPANTHERID = true;  // bool? |  (optional)  (default to false)
            var showPIRSFID = true;  // bool? |  (optional)  (default to false)
            var showPMID = true;  // bool? |  (optional)  (default to false)
            var showReactomeID = true;  // bool? |  (optional)  (default to false)
            var showSynonym = true;  // bool? |  (optional)  (default to false)
            var showUniProtKBID = true;  // bool? |  (optional)  (default to false)
            var offset = 56;  // int? | The number of items to skip before starting to collect the result set. (optional)  (default to 0)
            var limit = 56;  // int? | The numbers of items to return. (optional)  (default to 50)

            try
            {
                // Returns a list of PRO terms with MGI ID as cross-reference.
                List&lt;PROTerm&gt; result = apiInstance.GetPROTermsWithMGIId(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showMGIID, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DatabaseCrossReferencesApi.GetPROTermsWithMGIId: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **string**| Search field that needs to be considered for filter | [optional] 
 **searchValue** | **string**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **showPROName** | **bool?**|  | [optional] [default to true]
 **showPROTermDefinition** | **bool?**|  | [optional] [default to true]
 **showCategory** | **bool?**|  | [optional] [default to true]
 **showParent** | **bool?**|  | [optional] [default to true]
 **showMGIID** | **bool?**|  | [optional] [default to true]
 **showAnnotation** | **bool?**|  | [optional] [default to false]
 **showAnyRelationship** | **bool?**|  | [optional] [default to false]
 **showChild** | **bool?**|  | [optional] [default to false]
 **showComment** | **bool?**|  | [optional] [default to false]
 **showEcoCycID** | **bool?**|  | [optional] [default to false]
 **showGeneName** | **bool?**|  | [optional] [default to false]
 **showHGNCID** | **bool?**|  | [optional] [default to false]
 **showOrthoIsoform** | **bool?**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **bool?**|  | [optional] [default to false]
 **showPANTHERID** | **bool?**|  | [optional] [default to false]
 **showPIRSFID** | **bool?**|  | [optional] [default to false]
 **showPMID** | **bool?**|  | [optional] [default to false]
 **showReactomeID** | **bool?**|  | [optional] [default to false]
 **showSynonym** | **bool?**|  | [optional] [default to false]
 **showUniProtKBID** | **bool?**|  | [optional] [default to false]
 **offset** | **int?**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int?**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**List<PROTerm>**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="getprotermswithncbitaxonid"></a>
# **GetPROTermsWithNCBITaxonID**
> List<PROTerm> GetPROTermsWithNCBITaxonID (string searchField = null, string searchValue = null, bool? showPROName = null, bool? showPROTermDefinition = null, bool? showCategory = null, bool? showParent = null, bool? showAnnotation = null, bool? showAnyRelationship = null, bool? showChild = null, bool? showComment = null, bool? showEcoCycID = null, bool? showGeneName = null, bool? showHGNCID = null, bool? showMGIID = null, bool? showOrthoIsoform = null, bool? showOrthoModifiedForm = null, bool? showPANTHERID = null, bool? showPIRSFID = null, bool? showPMID = null, bool? showReactomeID = null, bool? showUniProtKBID = null, int? offset = null, int? limit = null)

Returns a list of PRO terms with NCBI Taxon ID as cross-reference.

Gets a list of PRO terms with NCBI Taxon ID as cross-reference and associated information.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetPROTermsWithNCBITaxonIDExample
    {
        public void main()
        {
            var apiInstance = new DatabaseCrossReferencesApi();
            var searchField = searchField_example;  // string | Search field that needs to be considered for filter (optional) 
            var searchValue = searchValue_example;  // string | any string or \"null\" or \"not null\" or a list of space separated ids (optional) 
            var showPROName = true;  // bool? |  (optional)  (default to true)
            var showPROTermDefinition = true;  // bool? |  (optional)  (default to true)
            var showCategory = true;  // bool? |  (optional)  (default to true)
            var showParent = true;  // bool? |  (optional)  (default to true)
            var showAnnotation = true;  // bool? |  (optional)  (default to true)
            var showAnyRelationship = true;  // bool? |  (optional)  (default to false)
            var showChild = true;  // bool? |  (optional)  (default to false)
            var showComment = true;  // bool? |  (optional)  (default to false)
            var showEcoCycID = true;  // bool? |  (optional)  (default to false)
            var showGeneName = true;  // bool? |  (optional)  (default to false)
            var showHGNCID = true;  // bool? |  (optional)  (default to false)
            var showMGIID = true;  // bool? |  (optional)  (default to false)
            var showOrthoIsoform = true;  // bool? |  (optional)  (default to false)
            var showOrthoModifiedForm = true;  // bool? |  (optional)  (default to false)
            var showPANTHERID = true;  // bool? |  (optional)  (default to false)
            var showPIRSFID = true;  // bool? |  (optional)  (default to false)
            var showPMID = true;  // bool? |  (optional)  (default to false)
            var showReactomeID = true;  // bool? |  (optional)  (default to false)
            var showUniProtKBID = true;  // bool? |  (optional)  (default to false)
            var offset = 56;  // int? | The number of items to skip before starting to collect the result set. (optional)  (default to 0)
            var limit = 56;  // int? | The numbers of items to return. (optional)  (default to 50)

            try
            {
                // Returns a list of PRO terms with NCBI Taxon ID as cross-reference.
                List&lt;PROTerm&gt; result = apiInstance.GetPROTermsWithNCBITaxonID(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showUniProtKBID, offset, limit);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DatabaseCrossReferencesApi.GetPROTermsWithNCBITaxonID: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **string**| Search field that needs to be considered for filter | [optional] 
 **searchValue** | **string**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **showPROName** | **bool?**|  | [optional] [default to true]
 **showPROTermDefinition** | **bool?**|  | [optional] [default to true]
 **showCategory** | **bool?**|  | [optional] [default to true]
 **showParent** | **bool?**|  | [optional] [default to true]
 **showAnnotation** | **bool?**|  | [optional] [default to true]
 **showAnyRelationship** | **bool?**|  | [optional] [default to false]
 **showChild** | **bool?**|  | [optional] [default to false]
 **showComment** | **bool?**|  | [optional] [default to false]
 **showEcoCycID** | **bool?**|  | [optional] [default to false]
 **showGeneName** | **bool?**|  | [optional] [default to false]
 **showHGNCID** | **bool?**|  | [optional] [default to false]
 **showMGIID** | **bool?**|  | [optional] [default to false]
 **showOrthoIsoform** | **bool?**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **bool?**|  | [optional] [default to false]
 **showPANTHERID** | **bool?**|  | [optional] [default to false]
 **showPIRSFID** | **bool?**|  | [optional] [default to false]
 **showPMID** | **bool?**|  | [optional] [default to false]
 **showReactomeID** | **bool?**|  | [optional] [default to false]
 **showUniProtKBID** | **bool?**|  | [optional] [default to false]
 **offset** | **int?**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int?**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**List<PROTerm>**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="getprotermswithontologyid"></a>
# **GetPROTermsWithOntologyId**
> List<PROTerm> GetPROTermsWithOntologyId (string searchField = null, string searchValue = null, bool? showPROName = null, bool? showPROTermDefinition = null, bool? showCategory = null, bool? showParent = null, bool? showAnnotation = null, bool? showAnyRelationship = null, bool? showChild = null, bool? showComment = null, bool? showEcoCycID = null, bool? showGeneName = null, bool? showHGNCID = null, bool? showMGIID = null, bool? showOrthoIsoform = null, bool? showOrthoModifiedForm = null, bool? showPANTHERID = null, bool? showPIRSFID = null, bool? showPMID = null, bool? showReactomeID = null, bool? showSynonym = null, bool? showUniProtKBID = null, int? offset = null, int? limit = null)

Returns a list of PRO terms with Ontology ID as cross-reference.

Gets a list of PRO terms with Ontology ID as cross-reference and associated information.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetPROTermsWithOntologyIdExample
    {
        public void main()
        {
            var apiInstance = new DatabaseCrossReferencesApi();
            var searchField = searchField_example;  // string | Search field that needs to be considered for filter (optional) 
            var searchValue = searchValue_example;  // string | any string or \"null\" or \"not null\" or a list of space separated ids (optional) 
            var showPROName = true;  // bool? |  (optional)  (default to true)
            var showPROTermDefinition = true;  // bool? |  (optional)  (default to true)
            var showCategory = true;  // bool? |  (optional)  (default to true)
            var showParent = true;  // bool? |  (optional)  (default to true)
            var showAnnotation = true;  // bool? |  (optional)  (default to true)
            var showAnyRelationship = true;  // bool? |  (optional)  (default to false)
            var showChild = true;  // bool? |  (optional)  (default to false)
            var showComment = true;  // bool? |  (optional)  (default to false)
            var showEcoCycID = true;  // bool? |  (optional)  (default to false)
            var showGeneName = true;  // bool? |  (optional)  (default to false)
            var showHGNCID = true;  // bool? |  (optional)  (default to false)
            var showMGIID = true;  // bool? |  (optional)  (default to false)
            var showOrthoIsoform = true;  // bool? |  (optional)  (default to false)
            var showOrthoModifiedForm = true;  // bool? |  (optional)  (default to false)
            var showPANTHERID = true;  // bool? |  (optional)  (default to false)
            var showPIRSFID = true;  // bool? |  (optional)  (default to false)
            var showPMID = true;  // bool? |  (optional)  (default to false)
            var showReactomeID = true;  // bool? |  (optional)  (default to false)
            var showSynonym = true;  // bool? |  (optional)  (default to false)
            var showUniProtKBID = true;  // bool? |  (optional)  (default to false)
            var offset = 56;  // int? | The number of items to skip before starting to collect the result set. (optional)  (default to 0)
            var limit = 56;  // int? | The numbers of items to return. (optional)  (default to 50)

            try
            {
                // Returns a list of PRO terms with Ontology ID as cross-reference.
                List&lt;PROTerm&gt; result = apiInstance.GetPROTermsWithOntologyId(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DatabaseCrossReferencesApi.GetPROTermsWithOntologyId: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **string**| Search field that needs to be considered for filter | [optional] 
 **searchValue** | **string**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **showPROName** | **bool?**|  | [optional] [default to true]
 **showPROTermDefinition** | **bool?**|  | [optional] [default to true]
 **showCategory** | **bool?**|  | [optional] [default to true]
 **showParent** | **bool?**|  | [optional] [default to true]
 **showAnnotation** | **bool?**|  | [optional] [default to true]
 **showAnyRelationship** | **bool?**|  | [optional] [default to false]
 **showChild** | **bool?**|  | [optional] [default to false]
 **showComment** | **bool?**|  | [optional] [default to false]
 **showEcoCycID** | **bool?**|  | [optional] [default to false]
 **showGeneName** | **bool?**|  | [optional] [default to false]
 **showHGNCID** | **bool?**|  | [optional] [default to false]
 **showMGIID** | **bool?**|  | [optional] [default to false]
 **showOrthoIsoform** | **bool?**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **bool?**|  | [optional] [default to false]
 **showPANTHERID** | **bool?**|  | [optional] [default to false]
 **showPIRSFID** | **bool?**|  | [optional] [default to false]
 **showPMID** | **bool?**|  | [optional] [default to false]
 **showReactomeID** | **bool?**|  | [optional] [default to false]
 **showSynonym** | **bool?**|  | [optional] [default to false]
 **showUniProtKBID** | **bool?**|  | [optional] [default to false]
 **offset** | **int?**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int?**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**List<PROTerm>**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="getprotermswithpantherid"></a>
# **GetPROTermsWithPANTHERId**
> List<PROTerm> GetPROTermsWithPANTHERId (string searchField = null, string searchValue = null, bool? showPROName = null, bool? showPROTermDefinition = null, bool? showCategory = null, bool? showParent = null, bool? showPANTHERID = null, bool? showAnnotation = null, bool? showAnyRelationship = null, bool? showChild = null, bool? showComment = null, bool? showEcoCycID = null, bool? showGeneName = null, bool? showHGNCID = null, bool? showMGIID = null, bool? showOrthoIsoform = null, bool? showOrthoModifiedForm = null, bool? showPIRSFID = null, bool? showPMID = null, bool? showReactomeID = null, bool? showSynonym = null, bool? showUniProtKBID = null, int? offset = null, int? limit = null)

Returns a list of PRO terms with PANTHER ID as cross-reference.

Gets a list of PRO terms with PANTHER ID as cross-reference and associated information.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetPROTermsWithPANTHERIdExample
    {
        public void main()
        {
            var apiInstance = new DatabaseCrossReferencesApi();
            var searchField = searchField_example;  // string | Search field that needs to be considered for filter (optional) 
            var searchValue = searchValue_example;  // string | any string or \"null\" or \"not null\" or a list of space separated ids (optional) 
            var showPROName = true;  // bool? |  (optional)  (default to true)
            var showPROTermDefinition = true;  // bool? |  (optional)  (default to true)
            var showCategory = true;  // bool? |  (optional)  (default to true)
            var showParent = true;  // bool? |  (optional)  (default to true)
            var showPANTHERID = true;  // bool? |  (optional)  (default to true)
            var showAnnotation = true;  // bool? |  (optional)  (default to false)
            var showAnyRelationship = true;  // bool? |  (optional)  (default to false)
            var showChild = true;  // bool? |  (optional)  (default to false)
            var showComment = true;  // bool? |  (optional)  (default to false)
            var showEcoCycID = true;  // bool? |  (optional)  (default to false)
            var showGeneName = true;  // bool? |  (optional)  (default to false)
            var showHGNCID = true;  // bool? |  (optional)  (default to false)
            var showMGIID = true;  // bool? |  (optional)  (default to false)
            var showOrthoIsoform = true;  // bool? |  (optional)  (default to false)
            var showOrthoModifiedForm = true;  // bool? |  (optional)  (default to false)
            var showPIRSFID = true;  // bool? |  (optional)  (default to false)
            var showPMID = true;  // bool? |  (optional)  (default to false)
            var showReactomeID = true;  // bool? |  (optional)  (default to false)
            var showSynonym = true;  // bool? |  (optional)  (default to false)
            var showUniProtKBID = true;  // bool? |  (optional)  (default to false)
            var offset = 56;  // int? | The number of items to skip before starting to collect the result set. (optional)  (default to 0)
            var limit = 56;  // int? | The numbers of items to return. (optional)  (default to 50)

            try
            {
                // Returns a list of PRO terms with PANTHER ID as cross-reference.
                List&lt;PROTerm&gt; result = apiInstance.GetPROTermsWithPANTHERId(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showPANTHERID, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DatabaseCrossReferencesApi.GetPROTermsWithPANTHERId: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **string**| Search field that needs to be considered for filter | [optional] 
 **searchValue** | **string**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **showPROName** | **bool?**|  | [optional] [default to true]
 **showPROTermDefinition** | **bool?**|  | [optional] [default to true]
 **showCategory** | **bool?**|  | [optional] [default to true]
 **showParent** | **bool?**|  | [optional] [default to true]
 **showPANTHERID** | **bool?**|  | [optional] [default to true]
 **showAnnotation** | **bool?**|  | [optional] [default to false]
 **showAnyRelationship** | **bool?**|  | [optional] [default to false]
 **showChild** | **bool?**|  | [optional] [default to false]
 **showComment** | **bool?**|  | [optional] [default to false]
 **showEcoCycID** | **bool?**|  | [optional] [default to false]
 **showGeneName** | **bool?**|  | [optional] [default to false]
 **showHGNCID** | **bool?**|  | [optional] [default to false]
 **showMGIID** | **bool?**|  | [optional] [default to false]
 **showOrthoIsoform** | **bool?**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **bool?**|  | [optional] [default to false]
 **showPIRSFID** | **bool?**|  | [optional] [default to false]
 **showPMID** | **bool?**|  | [optional] [default to false]
 **showReactomeID** | **bool?**|  | [optional] [default to false]
 **showSynonym** | **bool?**|  | [optional] [default to false]
 **showUniProtKBID** | **bool?**|  | [optional] [default to false]
 **offset** | **int?**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int?**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**List<PROTerm>**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="getprotermswithpirsfid"></a>
# **GetPROTermsWithPIRSFId**
> List<PROTerm> GetPROTermsWithPIRSFId (string searchField = null, string searchValue = null, bool? showPROName = null, bool? showPROTermDefinition = null, bool? showCategory = null, bool? showParent = null, bool? showPIRSFID = null, bool? showAnnotation = null, bool? showAnyRelationship = null, bool? showChild = null, bool? showComment = null, bool? showEcoCycID = null, bool? showGeneName = null, bool? showHGNCID = null, bool? showMGIID = null, bool? showOrthoIsoform = null, bool? showOrthoModifiedForm = null, bool? showPANTHERID = null, bool? showPMID = null, bool? showReactomeID = null, bool? showSynonym = null, bool? showUniProtKBID = null, int? offset = null, int? limit = null)

Returns a list of PRO terms with PIRSF ID as cross-reference.

Gets a list of PRO terms with PIRSF ID as cross-reference and associated information.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetPROTermsWithPIRSFIdExample
    {
        public void main()
        {
            var apiInstance = new DatabaseCrossReferencesApi();
            var searchField = searchField_example;  // string | Search field that needs to be considered for filter (optional) 
            var searchValue = searchValue_example;  // string | any string or \"null\" or \"not null\" or a list of space separated ids (optional) 
            var showPROName = true;  // bool? |  (optional)  (default to true)
            var showPROTermDefinition = true;  // bool? |  (optional)  (default to true)
            var showCategory = true;  // bool? |  (optional)  (default to true)
            var showParent = true;  // bool? |  (optional)  (default to true)
            var showPIRSFID = true;  // bool? |  (optional)  (default to true)
            var showAnnotation = true;  // bool? |  (optional)  (default to false)
            var showAnyRelationship = true;  // bool? |  (optional)  (default to false)
            var showChild = true;  // bool? |  (optional)  (default to false)
            var showComment = true;  // bool? |  (optional)  (default to false)
            var showEcoCycID = true;  // bool? |  (optional)  (default to false)
            var showGeneName = true;  // bool? |  (optional)  (default to false)
            var showHGNCID = true;  // bool? |  (optional)  (default to false)
            var showMGIID = true;  // bool? |  (optional)  (default to false)
            var showOrthoIsoform = true;  // bool? |  (optional)  (default to false)
            var showOrthoModifiedForm = true;  // bool? |  (optional)  (default to false)
            var showPANTHERID = true;  // bool? |  (optional)  (default to false)
            var showPMID = true;  // bool? |  (optional)  (default to false)
            var showReactomeID = true;  // bool? |  (optional)  (default to false)
            var showSynonym = true;  // bool? |  (optional)  (default to false)
            var showUniProtKBID = true;  // bool? |  (optional)  (default to false)
            var offset = 56;  // int? | The number of items to skip before starting to collect the result set. (optional)  (default to 0)
            var limit = 56;  // int? | The numbers of items to return. (optional)  (default to 50)

            try
            {
                // Returns a list of PRO terms with PIRSF ID as cross-reference.
                List&lt;PROTerm&gt; result = apiInstance.GetPROTermsWithPIRSFId(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showPIRSFID, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DatabaseCrossReferencesApi.GetPROTermsWithPIRSFId: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **string**| Search field that needs to be considered for filter | [optional] 
 **searchValue** | **string**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **showPROName** | **bool?**|  | [optional] [default to true]
 **showPROTermDefinition** | **bool?**|  | [optional] [default to true]
 **showCategory** | **bool?**|  | [optional] [default to true]
 **showParent** | **bool?**|  | [optional] [default to true]
 **showPIRSFID** | **bool?**|  | [optional] [default to true]
 **showAnnotation** | **bool?**|  | [optional] [default to false]
 **showAnyRelationship** | **bool?**|  | [optional] [default to false]
 **showChild** | **bool?**|  | [optional] [default to false]
 **showComment** | **bool?**|  | [optional] [default to false]
 **showEcoCycID** | **bool?**|  | [optional] [default to false]
 **showGeneName** | **bool?**|  | [optional] [default to false]
 **showHGNCID** | **bool?**|  | [optional] [default to false]
 **showMGIID** | **bool?**|  | [optional] [default to false]
 **showOrthoIsoform** | **bool?**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **bool?**|  | [optional] [default to false]
 **showPANTHERID** | **bool?**|  | [optional] [default to false]
 **showPMID** | **bool?**|  | [optional] [default to false]
 **showReactomeID** | **bool?**|  | [optional] [default to false]
 **showSynonym** | **bool?**|  | [optional] [default to false]
 **showUniProtKBID** | **bool?**|  | [optional] [default to false]
 **offset** | **int?**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int?**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**List<PROTerm>**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="getprotermswithpmid"></a>
# **GetPROTermsWithPMID**
> List<PROTerm> GetPROTermsWithPMID (string searchField = null, string searchValue = null, bool? showPROName = null, bool? showPROTermDefinition = null, bool? showCategory = null, bool? showParent = null, bool? showPMID = null, bool? showAnnotation = null, bool? showAnyRelationship = null, bool? showChild = null, bool? showComment = null, bool? showEcoCycID = null, bool? showGeneName = null, bool? showHGNCID = null, bool? showMGIID = null, bool? showOrthoIsoform = null, bool? showOrthoModifiedForm = null, bool? showPANTHERID = null, bool? showPIRSFID = null, bool? showReactomeID = null, bool? showSynonym = null, bool? showUniProtKBID = null, int? offset = null, int? limit = null)

Returns a list of PRO terms with PMID as cross-reference.

Gets a list of PRO terms with PMID as cross-reference and associated information.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetPROTermsWithPMIDExample
    {
        public void main()
        {
            var apiInstance = new DatabaseCrossReferencesApi();
            var searchField = searchField_example;  // string | Search field that needs to be considered for filter (optional) 
            var searchValue = searchValue_example;  // string | any string or \"null\" or \"not null\" or a list of space separated ids (optional) 
            var showPROName = true;  // bool? |  (optional)  (default to true)
            var showPROTermDefinition = true;  // bool? |  (optional)  (default to true)
            var showCategory = true;  // bool? |  (optional)  (default to true)
            var showParent = true;  // bool? |  (optional)  (default to true)
            var showPMID = true;  // bool? |  (optional)  (default to true)
            var showAnnotation = true;  // bool? |  (optional)  (default to false)
            var showAnyRelationship = true;  // bool? |  (optional)  (default to false)
            var showChild = true;  // bool? |  (optional)  (default to false)
            var showComment = true;  // bool? |  (optional)  (default to false)
            var showEcoCycID = true;  // bool? |  (optional)  (default to false)
            var showGeneName = true;  // bool? |  (optional)  (default to false)
            var showHGNCID = true;  // bool? |  (optional)  (default to false)
            var showMGIID = true;  // bool? |  (optional)  (default to false)
            var showOrthoIsoform = true;  // bool? |  (optional)  (default to false)
            var showOrthoModifiedForm = true;  // bool? |  (optional)  (default to false)
            var showPANTHERID = true;  // bool? |  (optional)  (default to false)
            var showPIRSFID = true;  // bool? |  (optional)  (default to false)
            var showReactomeID = true;  // bool? |  (optional)  (default to false)
            var showSynonym = true;  // bool? |  (optional)  (default to false)
            var showUniProtKBID = true;  // bool? |  (optional)  (default to false)
            var offset = 56;  // int? | The number of items to skip before starting to collect the result set. (optional)  (default to 0)
            var limit = 56;  // int? | The numbers of items to return. (optional)  (default to 50)

            try
            {
                // Returns a list of PRO terms with PMID as cross-reference.
                List&lt;PROTerm&gt; result = apiInstance.GetPROTermsWithPMID(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showPMID, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showReactomeID, showSynonym, showUniProtKBID, offset, limit);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DatabaseCrossReferencesApi.GetPROTermsWithPMID: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **string**| Search field that needs to be considered for filter | [optional] 
 **searchValue** | **string**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **showPROName** | **bool?**|  | [optional] [default to true]
 **showPROTermDefinition** | **bool?**|  | [optional] [default to true]
 **showCategory** | **bool?**|  | [optional] [default to true]
 **showParent** | **bool?**|  | [optional] [default to true]
 **showPMID** | **bool?**|  | [optional] [default to true]
 **showAnnotation** | **bool?**|  | [optional] [default to false]
 **showAnyRelationship** | **bool?**|  | [optional] [default to false]
 **showChild** | **bool?**|  | [optional] [default to false]
 **showComment** | **bool?**|  | [optional] [default to false]
 **showEcoCycID** | **bool?**|  | [optional] [default to false]
 **showGeneName** | **bool?**|  | [optional] [default to false]
 **showHGNCID** | **bool?**|  | [optional] [default to false]
 **showMGIID** | **bool?**|  | [optional] [default to false]
 **showOrthoIsoform** | **bool?**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **bool?**|  | [optional] [default to false]
 **showPANTHERID** | **bool?**|  | [optional] [default to false]
 **showPIRSFID** | **bool?**|  | [optional] [default to false]
 **showReactomeID** | **bool?**|  | [optional] [default to false]
 **showSynonym** | **bool?**|  | [optional] [default to false]
 **showUniProtKBID** | **bool?**|  | [optional] [default to false]
 **offset** | **int?**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int?**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**List<PROTerm>**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="getprotermswithreactomeid"></a>
# **GetPROTermsWithReactomeID**
> List<PROTerm> GetPROTermsWithReactomeID (string searchField = null, string searchValue = null, bool? showPROName = null, bool? showPROTermDefinition = null, bool? showCategory = null, bool? showParent = null, bool? showReactomeID = null, bool? showAnnotation = null, bool? showAnyRelationship = null, bool? showChild = null, bool? showComment = null, bool? showEcoCycID = null, bool? showGeneName = null, bool? showHGNCID = null, bool? showMGIID = null, bool? showOrthoIsoform = null, bool? showOrthoModifiedForm = null, bool? showPANTHERID = null, bool? showPIRSFID = null, bool? showPMID = null, bool? showUniProtKBID = null, int? offset = null, int? limit = null)

Returns a list of PRO terms with Reactome ID as cross-reference.

Gets a list of PRO terms with Reactome ID as cross-reference and associated information.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetPROTermsWithReactomeIDExample
    {
        public void main()
        {
            var apiInstance = new DatabaseCrossReferencesApi();
            var searchField = searchField_example;  // string | Search field that needs to be considered for filter (optional) 
            var searchValue = searchValue_example;  // string | any string or \"null\" or \"not null\" or a list of space separated ids (optional) 
            var showPROName = true;  // bool? |  (optional)  (default to true)
            var showPROTermDefinition = true;  // bool? |  (optional)  (default to true)
            var showCategory = true;  // bool? |  (optional)  (default to true)
            var showParent = true;  // bool? |  (optional)  (default to true)
            var showReactomeID = true;  // bool? |  (optional)  (default to true)
            var showAnnotation = true;  // bool? |  (optional)  (default to false)
            var showAnyRelationship = true;  // bool? |  (optional)  (default to false)
            var showChild = true;  // bool? |  (optional)  (default to false)
            var showComment = true;  // bool? |  (optional)  (default to false)
            var showEcoCycID = true;  // bool? |  (optional)  (default to false)
            var showGeneName = true;  // bool? |  (optional)  (default to false)
            var showHGNCID = true;  // bool? |  (optional)  (default to false)
            var showMGIID = true;  // bool? |  (optional)  (default to false)
            var showOrthoIsoform = true;  // bool? |  (optional)  (default to false)
            var showOrthoModifiedForm = true;  // bool? |  (optional)  (default to false)
            var showPANTHERID = true;  // bool? |  (optional)  (default to false)
            var showPIRSFID = true;  // bool? |  (optional)  (default to false)
            var showPMID = true;  // bool? |  (optional)  (default to false)
            var showUniProtKBID = true;  // bool? |  (optional)  (default to false)
            var offset = 56;  // int? | The number of items to skip before starting to collect the result set. (optional)  (default to 0)
            var limit = 56;  // int? | The numbers of items to return. (optional)  (default to 50)

            try
            {
                // Returns a list of PRO terms with Reactome ID as cross-reference.
                List&lt;PROTerm&gt; result = apiInstance.GetPROTermsWithReactomeID(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showReactomeID, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showUniProtKBID, offset, limit);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DatabaseCrossReferencesApi.GetPROTermsWithReactomeID: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **string**| Search field that needs to be considered for filter | [optional] 
 **searchValue** | **string**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **showPROName** | **bool?**|  | [optional] [default to true]
 **showPROTermDefinition** | **bool?**|  | [optional] [default to true]
 **showCategory** | **bool?**|  | [optional] [default to true]
 **showParent** | **bool?**|  | [optional] [default to true]
 **showReactomeID** | **bool?**|  | [optional] [default to true]
 **showAnnotation** | **bool?**|  | [optional] [default to false]
 **showAnyRelationship** | **bool?**|  | [optional] [default to false]
 **showChild** | **bool?**|  | [optional] [default to false]
 **showComment** | **bool?**|  | [optional] [default to false]
 **showEcoCycID** | **bool?**|  | [optional] [default to false]
 **showGeneName** | **bool?**|  | [optional] [default to false]
 **showHGNCID** | **bool?**|  | [optional] [default to false]
 **showMGIID** | **bool?**|  | [optional] [default to false]
 **showOrthoIsoform** | **bool?**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **bool?**|  | [optional] [default to false]
 **showPANTHERID** | **bool?**|  | [optional] [default to false]
 **showPIRSFID** | **bool?**|  | [optional] [default to false]
 **showPMID** | **bool?**|  | [optional] [default to false]
 **showUniProtKBID** | **bool?**|  | [optional] [default to false]
 **offset** | **int?**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int?**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**List<PROTerm>**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="getprotermswithuniprotkbid"></a>
# **GetPROTermsWithUniProtKBID**
> List<PROTerm> GetPROTermsWithUniProtKBID (string searchField = null, string searchValue = null, bool? showPROName = null, bool? showPROTermDefinition = null, bool? showCategory = null, bool? showParent = null, bool? showUniProtKBID = null, bool? showAnnotation = null, bool? showAnyRelationship = null, bool? showChild = null, bool? showComment = null, bool? showEcoCycID = null, bool? showGeneName = null, bool? showHGNCID = null, bool? showMGIID = null, bool? showOrthoIsoform = null, bool? showOrthoModifiedForm = null, bool? showPANTHERID = null, bool? showPIRSFID = null, bool? showPMID = null, bool? showReactomeID = null, int? offset = null, int? limit = null)

Returns a list of PRO terms with UniProtKB ID as cross-reference.

Gets a list of PRO terms with UniProtKB ID as cross-reference and associated information.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetPROTermsWithUniProtKBIDExample
    {
        public void main()
        {
            var apiInstance = new DatabaseCrossReferencesApi();
            var searchField = searchField_example;  // string | Search field that needs to be considered for filter (optional) 
            var searchValue = searchValue_example;  // string | any string or \"null\" or \"not null\" or a list of space separated ids (optional) 
            var showPROName = true;  // bool? |  (optional)  (default to true)
            var showPROTermDefinition = true;  // bool? |  (optional)  (default to true)
            var showCategory = true;  // bool? |  (optional)  (default to true)
            var showParent = true;  // bool? |  (optional)  (default to true)
            var showUniProtKBID = true;  // bool? |  (optional)  (default to true)
            var showAnnotation = true;  // bool? |  (optional)  (default to false)
            var showAnyRelationship = true;  // bool? |  (optional)  (default to false)
            var showChild = true;  // bool? |  (optional)  (default to false)
            var showComment = true;  // bool? |  (optional)  (default to false)
            var showEcoCycID = true;  // bool? |  (optional)  (default to false)
            var showGeneName = true;  // bool? |  (optional)  (default to false)
            var showHGNCID = true;  // bool? |  (optional)  (default to false)
            var showMGIID = true;  // bool? |  (optional)  (default to false)
            var showOrthoIsoform = true;  // bool? |  (optional)  (default to false)
            var showOrthoModifiedForm = true;  // bool? |  (optional)  (default to false)
            var showPANTHERID = true;  // bool? |  (optional)  (default to false)
            var showPIRSFID = true;  // bool? |  (optional)  (default to false)
            var showPMID = true;  // bool? |  (optional)  (default to false)
            var showReactomeID = true;  // bool? |  (optional)  (default to false)
            var offset = 56;  // int? | The number of items to skip before starting to collect the result set. (optional)  (default to 0)
            var limit = 56;  // int? | The numbers of items to return. (optional)  (default to 50)

            try
            {
                // Returns a list of PRO terms with UniProtKB ID as cross-reference.
                List&lt;PROTerm&gt; result = apiInstance.GetPROTermsWithUniProtKBID(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showUniProtKBID, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, offset, limit);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DatabaseCrossReferencesApi.GetPROTermsWithUniProtKBID: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **string**| Search field that needs to be considered for filter | [optional] 
 **searchValue** | **string**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **showPROName** | **bool?**|  | [optional] [default to true]
 **showPROTermDefinition** | **bool?**|  | [optional] [default to true]
 **showCategory** | **bool?**|  | [optional] [default to true]
 **showParent** | **bool?**|  | [optional] [default to true]
 **showUniProtKBID** | **bool?**|  | [optional] [default to true]
 **showAnnotation** | **bool?**|  | [optional] [default to false]
 **showAnyRelationship** | **bool?**|  | [optional] [default to false]
 **showChild** | **bool?**|  | [optional] [default to false]
 **showComment** | **bool?**|  | [optional] [default to false]
 **showEcoCycID** | **bool?**|  | [optional] [default to false]
 **showGeneName** | **bool?**|  | [optional] [default to false]
 **showHGNCID** | **bool?**|  | [optional] [default to false]
 **showMGIID** | **bool?**|  | [optional] [default to false]
 **showOrthoIsoform** | **bool?**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **bool?**|  | [optional] [default to false]
 **showPANTHERID** | **bool?**|  | [optional] [default to false]
 **showPIRSFID** | **bool?**|  | [optional] [default to false]
 **showPMID** | **bool?**|  | [optional] [default to false]
 **showReactomeID** | **bool?**|  | [optional] [default to false]
 **offset** | **int?**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int?**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**List<PROTerm>**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
