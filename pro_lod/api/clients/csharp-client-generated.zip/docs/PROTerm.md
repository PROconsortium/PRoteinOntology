# IO.Swagger.Model.PROTerm
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** | The PRO ID. | [optional] 
**Name** | **string** | The PRO name. | [optional] 
**TermDef** | **string** | The PRO term definition. | [optional] 
**Category** | **string** | The PRO term category. | [optional] 
**Annotation** | [**List&lt;Annotation&gt;**](Annotation.md) |  | [optional] 
**AnyRelationship** | **string** |  | [optional] 
**Child** | **List&lt;string&gt;** |  | [optional] 
**EcoCycID** | **string** |  | [optional] 
**GeneName** | **string** |  | [optional] 
**HgncID** | **List&lt;string&gt;** |  | [optional] 
**MgiID** | **List&lt;string&gt;** |  | [optional] 
**OrthoIsoform** | **List&lt;string&gt;** |  | [optional] 
**OrthoModifiedForm** | **List&lt;string&gt;** |  | [optional] 
**PantherID** | **string** |  | [optional] 
**Paraent** | **List&lt;string&gt;** |  | [optional] 
**PirsfID** | **string** |  | [optional] 
**PmID** | **string** |  | [optional] 
**Synonym** | **List&lt;string&gt;** |  | [optional] 
**ReactomeID** | **List&lt;string&gt;** |  | [optional] 
**UniprotKBID** | **List&lt;string&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

