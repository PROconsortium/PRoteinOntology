# IO.Swagger.Api.PROTermsApi

All URIs are relative to *https://research.bioinformatics.udel.edu/PRO_API/V1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetPROTermByIDs**](PROTermsApi.md#getprotermbyids) | **GET** /pros/{proIds} | Return PRO terms by IDs.
[**GetPROTerms**](PROTermsApi.md#getproterms) | **GET** /pros | Search PRO terms.

<a name="getprotermbyids"></a>
# **GetPROTermByIDs**
> PROTerm GetPROTermByIDs (string proIds, bool? showPROName = null, bool? showPROTermDefinition = null, bool? showCategory = null, bool? showParent = null, bool? showAnnotation = null, bool? showAnyRelationship = null, bool? showChild = null, bool? showComment = null, bool? showEcoCycID = null, bool? showGeneName = null, bool? showHGNCID = null, bool? showMGIID = null, bool? showOrthoIsoform = null, bool? showOrthoModifiedForm = null, bool? showPANTHERID = null, bool? showPIRSFID = null, bool? showPMID = null, bool? showReactomeID = null, bool? showSynonym = null, bool? showUniProtKBID = null)

Return PRO terms by IDs.

Gets PRO terms and associated information.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetPROTermByIDsExample
    {
        public void main()
        {
            var apiInstance = new PROTermsApi();
            var proIds = proIds_example;  // string | PRO ID(s). Space separated values accepted up to 100.
            var showPROName = true;  // bool? |  (optional)  (default to true)
            var showPROTermDefinition = true;  // bool? |  (optional)  (default to true)
            var showCategory = true;  // bool? |  (optional)  (default to true)
            var showParent = true;  // bool? |  (optional)  (default to true)
            var showAnnotation = true;  // bool? |  (optional)  (default to false)
            var showAnyRelationship = true;  // bool? |  (optional)  (default to false)
            var showChild = true;  // bool? |  (optional)  (default to false)
            var showComment = true;  // bool? |  (optional)  (default to false)
            var showEcoCycID = true;  // bool? |  (optional)  (default to false)
            var showGeneName = true;  // bool? |  (optional)  (default to false)
            var showHGNCID = true;  // bool? |  (optional)  (default to false)
            var showMGIID = true;  // bool? |  (optional)  (default to false)
            var showOrthoIsoform = true;  // bool? |  (optional)  (default to false)
            var showOrthoModifiedForm = true;  // bool? |  (optional)  (default to false)
            var showPANTHERID = true;  // bool? |  (optional)  (default to false)
            var showPIRSFID = true;  // bool? |  (optional)  (default to false)
            var showPMID = true;  // bool? |  (optional)  (default to false)
            var showReactomeID = true;  // bool? |  (optional)  (default to false)
            var showSynonym = true;  // bool? |  (optional)  (default to false)
            var showUniProtKBID = true;  // bool? |  (optional)  (default to false)

            try
            {
                // Return PRO terms by IDs.
                PROTerm result = apiInstance.GetPROTermByIDs(proIds, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling PROTermsApi.GetPROTermByIDs: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **proIds** | **string**| PRO ID(s). Space separated values accepted up to 100. | 
 **showPROName** | **bool?**|  | [optional] [default to true]
 **showPROTermDefinition** | **bool?**|  | [optional] [default to true]
 **showCategory** | **bool?**|  | [optional] [default to true]
 **showParent** | **bool?**|  | [optional] [default to true]
 **showAnnotation** | **bool?**|  | [optional] [default to false]
 **showAnyRelationship** | **bool?**|  | [optional] [default to false]
 **showChild** | **bool?**|  | [optional] [default to false]
 **showComment** | **bool?**|  | [optional] [default to false]
 **showEcoCycID** | **bool?**|  | [optional] [default to false]
 **showGeneName** | **bool?**|  | [optional] [default to false]
 **showHGNCID** | **bool?**|  | [optional] [default to false]
 **showMGIID** | **bool?**|  | [optional] [default to false]
 **showOrthoIsoform** | **bool?**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **bool?**|  | [optional] [default to false]
 **showPANTHERID** | **bool?**|  | [optional] [default to false]
 **showPIRSFID** | **bool?**|  | [optional] [default to false]
 **showPMID** | **bool?**|  | [optional] [default to false]
 **showReactomeID** | **bool?**|  | [optional] [default to false]
 **showSynonym** | **bool?**|  | [optional] [default to false]
 **showUniProtKBID** | **bool?**|  | [optional] [default to false]

### Return type

[**PROTerm**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="getproterms"></a>
# **GetPROTerms**
> List<PROTerm> GetPROTerms (string searchField = null, string searchValue = null, bool? showPROName = null, bool? showPROTermDefinition = null, bool? showCategory = null, bool? showParent = null, bool? showAnnotation = null, bool? showAnyRelationship = null, bool? showChild = null, bool? showComment = null, bool? showEcoCycID = null, bool? showGeneName = null, bool? showHGNCID = null, bool? showMGIID = null, bool? showOrthoIsoform = null, bool? showOrthoModifiedForm = null, bool? showPANTHERID = null, bool? showPIRSFID = null, bool? showPMID = null, bool? showReactomeID = null, bool? showSynonym = null, bool? showUniProtKBID = null, int? offset = null, int? limit = null)

Search PRO terms.

Gets a list of PRO terms and associated information.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetPROTermsExample
    {
        public void main()
        {
            var apiInstance = new PROTermsApi();
            var searchField = searchField_example;  // string | Search field that needs to be considered for filter (optional) 
            var searchValue = searchValue_example;  // string | any string or \"null\" or \"not null\" or a list of space separated ids (optional) 
            var showPROName = true;  // bool? |  (optional)  (default to true)
            var showPROTermDefinition = true;  // bool? |  (optional)  (default to true)
            var showCategory = true;  // bool? |  (optional)  (default to true)
            var showParent = true;  // bool? |  (optional)  (default to true)
            var showAnnotation = true;  // bool? |  (optional)  (default to false)
            var showAnyRelationship = true;  // bool? |  (optional)  (default to false)
            var showChild = true;  // bool? |  (optional)  (default to false)
            var showComment = true;  // bool? |  (optional)  (default to false)
            var showEcoCycID = true;  // bool? |  (optional)  (default to false)
            var showGeneName = true;  // bool? |  (optional)  (default to false)
            var showHGNCID = true;  // bool? |  (optional)  (default to false)
            var showMGIID = true;  // bool? |  (optional)  (default to false)
            var showOrthoIsoform = true;  // bool? |  (optional)  (default to false)
            var showOrthoModifiedForm = true;  // bool? |  (optional)  (default to false)
            var showPANTHERID = true;  // bool? |  (optional)  (default to false)
            var showPIRSFID = true;  // bool? |  (optional)  (default to false)
            var showPMID = true;  // bool? |  (optional)  (default to false)
            var showReactomeID = true;  // bool? |  (optional)  (default to false)
            var showSynonym = true;  // bool? |  (optional)  (default to false)
            var showUniProtKBID = true;  // bool? |  (optional)  (default to false)
            var offset = 56;  // int? | The number of items to skip before starting to collect the result set. (optional)  (default to 0)
            var limit = 56;  // int? | The numbers of items to return. (optional)  (default to 50)

            try
            {
                // Search PRO terms.
                List&lt;PROTerm&gt; result = apiInstance.GetPROTerms(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling PROTermsApi.GetPROTerms: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **string**| Search field that needs to be considered for filter | [optional] 
 **searchValue** | **string**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **showPROName** | **bool?**|  | [optional] [default to true]
 **showPROTermDefinition** | **bool?**|  | [optional] [default to true]
 **showCategory** | **bool?**|  | [optional] [default to true]
 **showParent** | **bool?**|  | [optional] [default to true]
 **showAnnotation** | **bool?**|  | [optional] [default to false]
 **showAnyRelationship** | **bool?**|  | [optional] [default to false]
 **showChild** | **bool?**|  | [optional] [default to false]
 **showComment** | **bool?**|  | [optional] [default to false]
 **showEcoCycID** | **bool?**|  | [optional] [default to false]
 **showGeneName** | **bool?**|  | [optional] [default to false]
 **showHGNCID** | **bool?**|  | [optional] [default to false]
 **showMGIID** | **bool?**|  | [optional] [default to false]
 **showOrthoIsoform** | **bool?**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **bool?**|  | [optional] [default to false]
 **showPANTHERID** | **bool?**|  | [optional] [default to false]
 **showPIRSFID** | **bool?**|  | [optional] [default to false]
 **showPMID** | **bool?**|  | [optional] [default to false]
 **showReactomeID** | **bool?**|  | [optional] [default to false]
 **showSynonym** | **bool?**|  | [optional] [default to false]
 **showUniProtKBID** | **bool?**|  | [optional] [default to false]
 **offset** | **int?**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int?**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**List<PROTerm>**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
