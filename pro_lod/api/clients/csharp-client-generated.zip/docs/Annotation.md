# IO.Swagger.Model.Annotation
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Modifier** | **string** |  | [optional] 
**Relation** | **string** |  | [optional] 
**OntologyID** | **string** |  | [optional] 
**OntologyTerm** | **string** |  | [optional] 
**RelativeTo** | **string** |  | [optional] 
**InteractionWith** | **string** |  | [optional] 
**Evidence** | [**Evidence**](Evidence.md) |  | [optional] 
**NcbiTaxonId** | **int?** |  | [optional] 
**InferredFrom** | **List&lt;string&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

