# IO.Swagger.Model.Evidence
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EvidenceSource** | **List&lt;string&gt;** |  | [optional] 
**EvidenceCode** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

