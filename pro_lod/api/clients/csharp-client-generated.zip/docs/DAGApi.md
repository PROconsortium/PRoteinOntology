# IO.Swagger.Api.DAGApi

All URIs are relative to *https://research.bioinformatics.udel.edu/PRO_API/V1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetAncestorByProIDs**](DAGApi.md#getancestorbyproids) | **GET** /dag/ancestor/{proIds} | Returns direct and indirect parent PRO terms by the given PRO ID(s).
[**GetChildrenByProIDs**](DAGApi.md#getchildrenbyproids) | **GET** /dag/children/{proIds} | Returns direct children PRO terms by the given PRO ID(s).
[**GetDescendantByProIDs**](DAGApi.md#getdescendantbyproids) | **GET** /dag/descendant/{proIds} | Returns direct and indirect children PRO terms by the given PRO ID(s).
[**GetHierarchyByProID**](DAGApi.md#gethierarchybyproid) | **GET** /dag/hierarchy/{proId} | Returns hierarchy of PRO terms by the given PRO ID.
[**GetParentByProIDs**](DAGApi.md#getparentbyproids) | **GET** /dag/parent/{proIds} | Returns direct parent PRO terms by the given PRO ID(s).

<a name="getancestorbyproids"></a>
# **GetAncestorByProIDs**
> List<PROTerm> GetAncestorByProIDs (string proIds, bool? showPROName = null, bool? showPROTermDefinition = null, bool? showCategory = null, bool? showParent = null, bool? showAnnotation = null, bool? showAnyRelationship = null, bool? showChild = null, bool? showComment = null, bool? showEcoCycID = null, bool? showGeneName = null, bool? showHGNCID = null, bool? showMGIID = null, bool? showOrthoIsoform = null, bool? showOrthoModifiedForm = null, bool? showPANTHERID = null, bool? showPIRSFID = null, bool? showPMID = null, bool? showReactomeID = null, bool? showUniProtKBID = null, int? offset = null, int? limit = null)

Returns direct and indirect parent PRO terms by the given PRO ID(s).

Gets direct and indirect parent PRO terms by the given PRO ID(s) and associated information.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetAncestorByProIDsExample
    {
        public void main()
        {
            var apiInstance = new DAGApi();
            var proIds = proIds_example;  // string | PRO ID(s). Space separated values accepted up to 100.
            var showPROName = true;  // bool? |  (optional)  (default to true)
            var showPROTermDefinition = true;  // bool? |  (optional)  (default to true)
            var showCategory = true;  // bool? |  (optional)  (default to true)
            var showParent = true;  // bool? |  (optional)  (default to true)
            var showAnnotation = true;  // bool? |  (optional)  (default to false)
            var showAnyRelationship = true;  // bool? |  (optional)  (default to false)
            var showChild = true;  // bool? |  (optional)  (default to false)
            var showComment = true;  // bool? |  (optional)  (default to false)
            var showEcoCycID = true;  // bool? |  (optional)  (default to false)
            var showGeneName = true;  // bool? |  (optional)  (default to false)
            var showHGNCID = true;  // bool? |  (optional)  (default to false)
            var showMGIID = true;  // bool? |  (optional)  (default to false)
            var showOrthoIsoform = true;  // bool? |  (optional)  (default to false)
            var showOrthoModifiedForm = true;  // bool? |  (optional)  (default to false)
            var showPANTHERID = true;  // bool? |  (optional)  (default to false)
            var showPIRSFID = true;  // bool? |  (optional)  (default to false)
            var showPMID = true;  // bool? |  (optional)  (default to false)
            var showReactomeID = true;  // bool? |  (optional)  (default to false)
            var showUniProtKBID = true;  // bool? |  (optional)  (default to false)
            var offset = 56;  // int? | The number of items to skip before starting to collect the result set. (optional)  (default to 0)
            var limit = 56;  // int? | The numbers of items to return. (optional)  (default to 50)

            try
            {
                // Returns direct and indirect parent PRO terms by the given PRO ID(s).
                List&lt;PROTerm&gt; result = apiInstance.GetAncestorByProIDs(proIds, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showUniProtKBID, offset, limit);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DAGApi.GetAncestorByProIDs: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **proIds** | **string**| PRO ID(s). Space separated values accepted up to 100. | 
 **showPROName** | **bool?**|  | [optional] [default to true]
 **showPROTermDefinition** | **bool?**|  | [optional] [default to true]
 **showCategory** | **bool?**|  | [optional] [default to true]
 **showParent** | **bool?**|  | [optional] [default to true]
 **showAnnotation** | **bool?**|  | [optional] [default to false]
 **showAnyRelationship** | **bool?**|  | [optional] [default to false]
 **showChild** | **bool?**|  | [optional] [default to false]
 **showComment** | **bool?**|  | [optional] [default to false]
 **showEcoCycID** | **bool?**|  | [optional] [default to false]
 **showGeneName** | **bool?**|  | [optional] [default to false]
 **showHGNCID** | **bool?**|  | [optional] [default to false]
 **showMGIID** | **bool?**|  | [optional] [default to false]
 **showOrthoIsoform** | **bool?**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **bool?**|  | [optional] [default to false]
 **showPANTHERID** | **bool?**|  | [optional] [default to false]
 **showPIRSFID** | **bool?**|  | [optional] [default to false]
 **showPMID** | **bool?**|  | [optional] [default to false]
 **showReactomeID** | **bool?**|  | [optional] [default to false]
 **showUniProtKBID** | **bool?**|  | [optional] [default to false]
 **offset** | **int?**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int?**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**List<PROTerm>**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="getchildrenbyproids"></a>
# **GetChildrenByProIDs**
> List<PROTerm> GetChildrenByProIDs (string proIds, bool? showPROName = null, bool? showPROTermDefinition = null, bool? showCategory = null, bool? showParent = null, bool? showAnnotation = null, bool? showAnyRelationship = null, bool? showChild = null, bool? showComment = null, bool? showEcoCycID = null, bool? showGeneName = null, bool? showHGNCID = null, bool? showMGIID = null, bool? showOrthoIsoform = null, bool? showOrthoModifiedForm = null, bool? showPANTHERID = null, bool? showPIRSFID = null, bool? showPMID = null, bool? showReactomeID = null, bool? showUniProtKBID = null, int? offset = null, int? limit = null)

Returns direct children PRO terms by the given PRO ID(s).

Gets direct children PRO terms by the given PRO ID(s) and associated information.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetChildrenByProIDsExample
    {
        public void main()
        {
            var apiInstance = new DAGApi();
            var proIds = proIds_example;  // string | PRO ID(s). Space separated values accepted up to 100.
            var showPROName = true;  // bool? |  (optional)  (default to true)
            var showPROTermDefinition = true;  // bool? |  (optional)  (default to true)
            var showCategory = true;  // bool? |  (optional)  (default to true)
            var showParent = true;  // bool? |  (optional)  (default to true)
            var showAnnotation = true;  // bool? |  (optional)  (default to false)
            var showAnyRelationship = true;  // bool? |  (optional)  (default to false)
            var showChild = true;  // bool? |  (optional)  (default to false)
            var showComment = true;  // bool? |  (optional)  (default to false)
            var showEcoCycID = true;  // bool? |  (optional)  (default to false)
            var showGeneName = true;  // bool? |  (optional)  (default to false)
            var showHGNCID = true;  // bool? |  (optional)  (default to false)
            var showMGIID = true;  // bool? |  (optional)  (default to false)
            var showOrthoIsoform = true;  // bool? |  (optional)  (default to false)
            var showOrthoModifiedForm = true;  // bool? |  (optional)  (default to false)
            var showPANTHERID = true;  // bool? |  (optional)  (default to false)
            var showPIRSFID = true;  // bool? |  (optional)  (default to false)
            var showPMID = true;  // bool? |  (optional)  (default to false)
            var showReactomeID = true;  // bool? |  (optional)  (default to false)
            var showUniProtKBID = true;  // bool? |  (optional)  (default to false)
            var offset = 56;  // int? | The number of items to skip before starting to collect the result set. (optional)  (default to 0)
            var limit = 56;  // int? | The numbers of items to return. (optional)  (default to 50)

            try
            {
                // Returns direct children PRO terms by the given PRO ID(s).
                List&lt;PROTerm&gt; result = apiInstance.GetChildrenByProIDs(proIds, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showUniProtKBID, offset, limit);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DAGApi.GetChildrenByProIDs: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **proIds** | **string**| PRO ID(s). Space separated values accepted up to 100. | 
 **showPROName** | **bool?**|  | [optional] [default to true]
 **showPROTermDefinition** | **bool?**|  | [optional] [default to true]
 **showCategory** | **bool?**|  | [optional] [default to true]
 **showParent** | **bool?**|  | [optional] [default to true]
 **showAnnotation** | **bool?**|  | [optional] [default to false]
 **showAnyRelationship** | **bool?**|  | [optional] [default to false]
 **showChild** | **bool?**|  | [optional] [default to false]
 **showComment** | **bool?**|  | [optional] [default to false]
 **showEcoCycID** | **bool?**|  | [optional] [default to false]
 **showGeneName** | **bool?**|  | [optional] [default to false]
 **showHGNCID** | **bool?**|  | [optional] [default to false]
 **showMGIID** | **bool?**|  | [optional] [default to false]
 **showOrthoIsoform** | **bool?**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **bool?**|  | [optional] [default to false]
 **showPANTHERID** | **bool?**|  | [optional] [default to false]
 **showPIRSFID** | **bool?**|  | [optional] [default to false]
 **showPMID** | **bool?**|  | [optional] [default to false]
 **showReactomeID** | **bool?**|  | [optional] [default to false]
 **showUniProtKBID** | **bool?**|  | [optional] [default to false]
 **offset** | **int?**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int?**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**List<PROTerm>**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="getdescendantbyproids"></a>
# **GetDescendantByProIDs**
> List<PROTerm> GetDescendantByProIDs (string proIds, bool? showPROName = null, bool? showPROTermDefinition = null, bool? showCategory = null, bool? showParent = null, bool? showAnnotation = null, bool? showAnyRelationship = null, bool? showChild = null, bool? showComment = null, bool? showEcoCycID = null, bool? showGeneName = null, bool? showHGNCID = null, bool? showMGIID = null, bool? showOrthoIsoform = null, bool? showOrthoModifiedForm = null, bool? showPANTHERID = null, bool? showPIRSFID = null, bool? showPMID = null, bool? showReactomeID = null, bool? showUniProtKBID = null, int? offset = null, int? limit = null)

Returns direct and indirect children PRO terms by the given PRO ID(s).

Gets direct and indirect children PRO terms by the given PRO ID(s) and associated information.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetDescendantByProIDsExample
    {
        public void main()
        {
            var apiInstance = new DAGApi();
            var proIds = proIds_example;  // string | PRO ID(s). Space separated values accepted up to 100.
            var showPROName = true;  // bool? |  (optional)  (default to true)
            var showPROTermDefinition = true;  // bool? |  (optional)  (default to true)
            var showCategory = true;  // bool? |  (optional)  (default to true)
            var showParent = true;  // bool? |  (optional)  (default to true)
            var showAnnotation = true;  // bool? |  (optional)  (default to false)
            var showAnyRelationship = true;  // bool? |  (optional)  (default to false)
            var showChild = true;  // bool? |  (optional)  (default to false)
            var showComment = true;  // bool? |  (optional)  (default to false)
            var showEcoCycID = true;  // bool? |  (optional)  (default to false)
            var showGeneName = true;  // bool? |  (optional)  (default to false)
            var showHGNCID = true;  // bool? |  (optional)  (default to false)
            var showMGIID = true;  // bool? |  (optional)  (default to false)
            var showOrthoIsoform = true;  // bool? |  (optional)  (default to false)
            var showOrthoModifiedForm = true;  // bool? |  (optional)  (default to false)
            var showPANTHERID = true;  // bool? |  (optional)  (default to false)
            var showPIRSFID = true;  // bool? |  (optional)  (default to false)
            var showPMID = true;  // bool? |  (optional)  (default to false)
            var showReactomeID = true;  // bool? |  (optional)  (default to false)
            var showUniProtKBID = true;  // bool? |  (optional)  (default to false)
            var offset = 56;  // int? | The number of items to skip before starting to collect the result set. (optional)  (default to 0)
            var limit = 56;  // int? | The numbers of items to return. (optional)  (default to 50)

            try
            {
                // Returns direct and indirect children PRO terms by the given PRO ID(s).
                List&lt;PROTerm&gt; result = apiInstance.GetDescendantByProIDs(proIds, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showUniProtKBID, offset, limit);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DAGApi.GetDescendantByProIDs: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **proIds** | **string**| PRO ID(s). Space separated values accepted up to 100. | 
 **showPROName** | **bool?**|  | [optional] [default to true]
 **showPROTermDefinition** | **bool?**|  | [optional] [default to true]
 **showCategory** | **bool?**|  | [optional] [default to true]
 **showParent** | **bool?**|  | [optional] [default to true]
 **showAnnotation** | **bool?**|  | [optional] [default to false]
 **showAnyRelationship** | **bool?**|  | [optional] [default to false]
 **showChild** | **bool?**|  | [optional] [default to false]
 **showComment** | **bool?**|  | [optional] [default to false]
 **showEcoCycID** | **bool?**|  | [optional] [default to false]
 **showGeneName** | **bool?**|  | [optional] [default to false]
 **showHGNCID** | **bool?**|  | [optional] [default to false]
 **showMGIID** | **bool?**|  | [optional] [default to false]
 **showOrthoIsoform** | **bool?**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **bool?**|  | [optional] [default to false]
 **showPANTHERID** | **bool?**|  | [optional] [default to false]
 **showPIRSFID** | **bool?**|  | [optional] [default to false]
 **showPMID** | **bool?**|  | [optional] [default to false]
 **showReactomeID** | **bool?**|  | [optional] [default to false]
 **showUniProtKBID** | **bool?**|  | [optional] [default to false]
 **offset** | **int?**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int?**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**List<PROTerm>**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="gethierarchybyproid"></a>
# **GetHierarchyByProID**
> List<ChildParentPair> GetHierarchyByProID (string proId, bool? showPROName = null, bool? showPROTermDefinition = null, bool? showCategory = null, bool? showAnnotation = null, bool? showAnyRelationship = null, bool? showComment = null, bool? showEcoCycID = null, bool? showGeneName = null, bool? showHGNCID = null, bool? showMGIID = null, bool? showOrthoIsoform = null, bool? showOrthoModifiedForm = null, bool? showPANTHERID = null, bool? showPIRSFID = null, bool? showPMID = null, bool? showReactomeID = null, bool? showSynonym = null, bool? showTaxonID = null, bool? showUniProtKBID = null)

Returns hierarchy of PRO terms by the given PRO ID.

Gets hierarchy of PRO terms by the given PRO ID.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetHierarchyByProIDExample
    {
        public void main()
        {
            var apiInstance = new DAGApi();
            var proId = proId_example;  // string | Space separated PRO ID(s).
            var showPROName = true;  // bool? |  (optional)  (default to true)
            var showPROTermDefinition = true;  // bool? |  (optional)  (default to true)
            var showCategory = true;  // bool? |  (optional)  (default to true)
            var showAnnotation = true;  // bool? |  (optional)  (default to false)
            var showAnyRelationship = true;  // bool? |  (optional)  (default to false)
            var showComment = true;  // bool? |  (optional)  (default to false)
            var showEcoCycID = true;  // bool? |  (optional)  (default to false)
            var showGeneName = true;  // bool? |  (optional)  (default to false)
            var showHGNCID = true;  // bool? |  (optional)  (default to false)
            var showMGIID = true;  // bool? |  (optional)  (default to false)
            var showOrthoIsoform = true;  // bool? |  (optional)  (default to false)
            var showOrthoModifiedForm = true;  // bool? |  (optional)  (default to false)
            var showPANTHERID = true;  // bool? |  (optional)  (default to false)
            var showPIRSFID = true;  // bool? |  (optional)  (default to false)
            var showPMID = true;  // bool? |  (optional)  (default to false)
            var showReactomeID = true;  // bool? |  (optional)  (default to false)
            var showSynonym = true;  // bool? |  (optional)  (default to false)
            var showTaxonID = true;  // bool? |  (optional)  (default to false)
            var showUniProtKBID = true;  // bool? |  (optional)  (default to false)

            try
            {
                // Returns hierarchy of PRO terms by the given PRO ID.
                List&lt;ChildParentPair&gt; result = apiInstance.GetHierarchyByProID(proId, showPROName, showPROTermDefinition, showCategory, showAnnotation, showAnyRelationship, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showTaxonID, showUniProtKBID);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DAGApi.GetHierarchyByProID: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **proId** | **string**| Space separated PRO ID(s). | 
 **showPROName** | **bool?**|  | [optional] [default to true]
 **showPROTermDefinition** | **bool?**|  | [optional] [default to true]
 **showCategory** | **bool?**|  | [optional] [default to true]
 **showAnnotation** | **bool?**|  | [optional] [default to false]
 **showAnyRelationship** | **bool?**|  | [optional] [default to false]
 **showComment** | **bool?**|  | [optional] [default to false]
 **showEcoCycID** | **bool?**|  | [optional] [default to false]
 **showGeneName** | **bool?**|  | [optional] [default to false]
 **showHGNCID** | **bool?**|  | [optional] [default to false]
 **showMGIID** | **bool?**|  | [optional] [default to false]
 **showOrthoIsoform** | **bool?**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **bool?**|  | [optional] [default to false]
 **showPANTHERID** | **bool?**|  | [optional] [default to false]
 **showPIRSFID** | **bool?**|  | [optional] [default to false]
 **showPMID** | **bool?**|  | [optional] [default to false]
 **showReactomeID** | **bool?**|  | [optional] [default to false]
 **showSynonym** | **bool?**|  | [optional] [default to false]
 **showTaxonID** | **bool?**|  | [optional] [default to false]
 **showUniProtKBID** | **bool?**|  | [optional] [default to false]

### Return type

[**List<ChildParentPair>**](ChildParentPair.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="getparentbyproids"></a>
# **GetParentByProIDs**
> List<PROTerm> GetParentByProIDs (string proIds, bool? showPROName = null, bool? showPROTermDefinition = null, bool? showCategory = null, bool? showParent = null, bool? showAnnotation = null, bool? showAnyRelationship = null, bool? showChild = null, bool? showComment = null, bool? showEcoCycID = null, bool? showGeneName = null, bool? showHGNCID = null, bool? showMGIID = null, bool? showOrthoIsoform = null, bool? showOrthoModifiedForm = null, bool? showPANTHERID = null, bool? showPIRSFID = null, bool? showPMID = null, bool? showReactomeID = null, bool? showUniProtKBID = null, int? offset = null, int? limit = null)

Returns direct parent PRO terms by the given PRO ID(s).

Gets direct parent PRO terms by the given PRO ID(s) and associated information.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetParentByProIDsExample
    {
        public void main()
        {
            var apiInstance = new DAGApi();
            var proIds = proIds_example;  // string | PRO ID(s). Space separated values accepted up to 100.
            var showPROName = true;  // bool? |  (optional)  (default to true)
            var showPROTermDefinition = true;  // bool? |  (optional)  (default to true)
            var showCategory = true;  // bool? |  (optional)  (default to true)
            var showParent = true;  // bool? |  (optional)  (default to true)
            var showAnnotation = true;  // bool? |  (optional)  (default to false)
            var showAnyRelationship = true;  // bool? |  (optional)  (default to false)
            var showChild = true;  // bool? |  (optional)  (default to false)
            var showComment = true;  // bool? |  (optional)  (default to false)
            var showEcoCycID = true;  // bool? |  (optional)  (default to false)
            var showGeneName = true;  // bool? |  (optional)  (default to false)
            var showHGNCID = true;  // bool? |  (optional)  (default to false)
            var showMGIID = true;  // bool? |  (optional)  (default to false)
            var showOrthoIsoform = true;  // bool? |  (optional)  (default to false)
            var showOrthoModifiedForm = true;  // bool? |  (optional)  (default to false)
            var showPANTHERID = true;  // bool? |  (optional)  (default to false)
            var showPIRSFID = true;  // bool? |  (optional)  (default to false)
            var showPMID = true;  // bool? |  (optional)  (default to false)
            var showReactomeID = true;  // bool? |  (optional)  (default to false)
            var showUniProtKBID = true;  // bool? |  (optional)  (default to false)
            var offset = 56;  // int? | The number of items to skip before starting to collect the result set. (optional)  (default to 0)
            var limit = 56;  // int? | The numbers of items to return. (optional)  (default to 50)

            try
            {
                // Returns direct parent PRO terms by the given PRO ID(s).
                List&lt;PROTerm&gt; result = apiInstance.GetParentByProIDs(proIds, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showUniProtKBID, offset, limit);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DAGApi.GetParentByProIDs: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **proIds** | **string**| PRO ID(s). Space separated values accepted up to 100. | 
 **showPROName** | **bool?**|  | [optional] [default to true]
 **showPROTermDefinition** | **bool?**|  | [optional] [default to true]
 **showCategory** | **bool?**|  | [optional] [default to true]
 **showParent** | **bool?**|  | [optional] [default to true]
 **showAnnotation** | **bool?**|  | [optional] [default to false]
 **showAnyRelationship** | **bool?**|  | [optional] [default to false]
 **showChild** | **bool?**|  | [optional] [default to false]
 **showComment** | **bool?**|  | [optional] [default to false]
 **showEcoCycID** | **bool?**|  | [optional] [default to false]
 **showGeneName** | **bool?**|  | [optional] [default to false]
 **showHGNCID** | **bool?**|  | [optional] [default to false]
 **showMGIID** | **bool?**|  | [optional] [default to false]
 **showOrthoIsoform** | **bool?**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **bool?**|  | [optional] [default to false]
 **showPANTHERID** | **bool?**|  | [optional] [default to false]
 **showPIRSFID** | **bool?**|  | [optional] [default to false]
 **showPMID** | **bool?**|  | [optional] [default to false]
 **showReactomeID** | **bool?**|  | [optional] [default to false]
 **showUniProtKBID** | **bool?**|  | [optional] [default to false]
 **offset** | **int?**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int?**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**List<PROTerm>**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
