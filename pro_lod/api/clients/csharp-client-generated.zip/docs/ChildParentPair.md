# IO.Swagger.Model.ChildParentPair
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Pro** | [**PROTerm**](PROTerm.md) |  | [optional] 
**ProParent** | [**PROTerm**](PROTerm.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

