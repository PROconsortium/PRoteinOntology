# Protein_matchRange

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**start** | **integer** |  | [optional] [default to null]
**end** | **integer** |  | [optional] [default to null]
**replacedLocs** | **array[integer]** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


