# Report_searchParameters

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**taxonids** | **string** |  | [optional] [default to null]
**swissprot** | **boolean** |  | [optional] [default to null]
**isoform** | **boolean** |  | [optional] [default to null]
**uniref100** | **boolean** |  | [optional] [default to null]
**leqi** | **boolean** |  | [optional] [default to null]
**offset** | **integer** |  | [optional] [default to null]
**size** | **integer** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


