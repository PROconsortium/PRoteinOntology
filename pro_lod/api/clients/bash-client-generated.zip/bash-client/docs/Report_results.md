# Report_results

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**queryPeptide** | **string** |  | [optional] [default to null]
**proteins** | [**array[Protein]**](Protein.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


