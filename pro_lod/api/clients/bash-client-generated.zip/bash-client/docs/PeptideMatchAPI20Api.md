# PeptideMatchAPI20Api

All URIs are relative to */peptidematchapi2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**matchGetGet**](PeptideMatchAPI20Api.md#matchGetGet) | **GET** /match_get | Do peptide match using GET method.
[**matchPostPost**](PeptideMatchAPI20Api.md#matchPostPost) | **POST** /match_post | Do peptide match using POST method.


## **matchGetGet**

Do peptide match using GET method.

Retrieve UniProtKB protein sequences that would exactly match to the query peptides using GET method.

### Example
```bash
 matchGetGet  peptides=value  taxonids=value  swissprot=value  isoform=value  uniref100=value  leqi=value  offset=value  size=value
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **peptides** | **string** | A list of comma-separated peptide sequences (up to 100). Each sequence consists of 3 or more amino acids. | [default to AAVEEGIVLGGGCALLR,SVQYDDVPEYK]
 **taxonids** | **string** | A list fo comma-separated NCBI taxonomy IDs. | [optional] [default to 9606,10090]
 **swissprot** | **boolean** | Only search SwissProt protein sequences. | [optional] [default to true]
 **isoform** | **boolean** | Include isforms. | [optional] [default to true]
 **uniref100** | **boolean** | Only search UniRef100 protein sequences. | [optional] [default to false]
 **leqi** | **boolean** | Treat Leucine (L) and Isoleucine (I) equivalent. | [optional] [default to false]
 **offset** | **integer** | Off set, page starting point, with default value 0. | [optional] [default to 0]
 **size** | **integer** | Page size with default value 100. When page size is -1, it returns all records and offset will be ignored. | [optional] [default to 100]

### Return type

[**Report**](Report.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not Applicable
 - **Accept**: application/json, application/xml, text/x-fasta, text/tab-separated-values

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

## **matchPostPost**

Do peptide match using POST method.

Retrieve UniProtKB protein sequences that would exactly match to the query peptides using POST method.

### Example
```bash
 matchPostPost
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **peptides** | **string** | A list of comma-separated peptide sequences (up to 100). Each sequence consists of 3 or more amino acids. | [default to AAVEEGIVLGGGCALLR,SVQYDDVPEYK]
 **taxonids** | **string** | A list fo comma-separated NCBI taxonomy IDs. | [optional] [default to 9606,10090]
 **swissprot** | **boolean** | Only search SwissProt protein sequences. | [optional] [default to true]
 **isoform** | **boolean** | Include isoforms. | [optional] [default to true]
 **uniref100** | **boolean** | Only search UniRef100 protein sequences. | [optional] [default to false]
 **leqi** | **boolean** | Treat Leucine (L) and Isoleucine (I) equivalent. | [optional] [default to false]
 **offset** | **integer** | Off set, page starting point, with default value 0. | [optional] [default to 0]
 **size** | **integer** | Page size with default value 100. When page size is -1, it returns all records and offset will be ignored. | [optional] [default to 100]

### Return type

[**Report**](Report.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded
 - **Accept**: application/json, application/xml, text/x-fasta, text/tab-separated-values

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

