# Protein

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**reviewStatus** | **string** |  | [optional] [default to null]
**ac** | **string** |  | [optional] [default to null]
**id** | **string** |  | [optional] [default to null]
**name** | **string** |  | [optional] [default to null]
**orgName** | **string** |  | [optional] [default to null]
**orgTaxonId** | **integer** |  | [optional] [default to null]
**orgTaxonGroupName** | **string** |  | [optional] [default to null]
**orgTaxonGroupId** | **integer** |  | [optional] [default to null]
**sequence** | **string** |  | [optional] [default to null]
**matchingPeptides** | [**array[Protein_matchingPeptides]**](Protein_matchingPeptides.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


