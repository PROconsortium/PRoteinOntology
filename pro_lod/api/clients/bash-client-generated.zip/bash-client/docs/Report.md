# Report

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**numberFound** | **integer** |  | [optional] [default to null]
**qtime** | **integer** |  | [optional] [default to null]
**status** | **integer** |  | [optional] [default to null]
**searchParameters** | [**Report_searchParameters**](Report_searchParameters.md) |  | [optional] [default to null]
**results** | [**array[Report_results]**](Report_results.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


