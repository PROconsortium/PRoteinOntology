# WWW::SwaggerClient::Object::ReportSearchParameters

## Load the model package
```perl
use WWW::SwaggerClient::Object::ReportSearchParameters;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**taxonids** | **string** | NCBI taxonomy IDs. | [optional] 
**swissprot** | **boolean** | Only search SwissProt protein sequences. | [optional] 
**isoform** | **boolean** | Include isoforms. | [optional] 
**uniref100** | **boolean** | Only search UniRef100 protein sequences. | [optional] 
**leqi** | **boolean** | Treat Leucine (L) and Isoleucine (I) equivalent. | [optional] 
**offset** | **int** | Off set, page starting point, with default value 0. | [optional] 
**size** | **int** | Page size with default value 100. When page size is -1, it returns all records and offset will be ignored. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


