# WWW::SwaggerClient::PeptideMatchAPI20Api

## Load the API package
```perl
use WWW::SwaggerClient::Object::PeptideMatchAPI20Api;
```

All URIs are relative to *http://ibm-cloud1.proteininformationresource.org/peptidematchapi2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**match_get_get**](PeptideMatchAPI20Api.md#match_get_get) | **GET** /match_get | Do peptide match using GET method.
[**match_post_post**](PeptideMatchAPI20Api.md#match_post_post) | **POST** /match_post | Do peptide match using POST method.


# **match_get_get**
> Report match_get_get(peptides => $peptides, taxonids => $taxonids, swissprot => $swissprot, isoform => $isoform, uniref100 => $uniref100, leqi => $leqi, offset => $offset, size => $size)

Do peptide match using GET method.

Retrieve UniProtKB protein sequences that would exactly match to the query peptides using GET method.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::PeptideMatchAPI20Api;
my $api_instance = WWW::SwaggerClient::PeptideMatchAPI20Api->new(
);

my $peptides = 'peptides_example'; # string | A list of comma-separated peptide sequences (up to 100). Each sequence consists of 3 or more amino acids.
my $taxonids = 'taxonids_example'; # string | A list fo comma-separated NCBI taxonomy IDs.
my $swissprot = 1; # boolean | Only search SwissProt protein sequences.
my $isoform = 1; # boolean | Include isforms.
my $uniref100 = 1; # boolean | Only search UniRef100 protein sequences.
my $leqi = 1; # boolean | Treat Leucine (L) and Isoleucine (I) equivalent.
my $offset = 56; # int | Off set, page starting point, with default value 0.
my $size = 56; # int | Page size with default value 100. When page size is -1, it returns all records and offset will be ignored.

eval { 
    my $result = $api_instance->match_get_get(peptides => $peptides, taxonids => $taxonids, swissprot => $swissprot, isoform => $isoform, uniref100 => $uniref100, leqi => $leqi, offset => $offset, size => $size);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling PeptideMatchAPI20Api->match_get_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **peptides** | **string**| A list of comma-separated peptide sequences (up to 100). Each sequence consists of 3 or more amino acids. | [default to AAVEEGIVLGGGCALLR,SVQYDDVPEYK]
 **taxonids** | **string**| A list fo comma-separated NCBI taxonomy IDs. | [optional] [default to 9606,10090]
 **swissprot** | **boolean**| Only search SwissProt protein sequences. | [optional] [default to true]
 **isoform** | **boolean**| Include isforms. | [optional] [default to true]
 **uniref100** | **boolean**| Only search UniRef100 protein sequences. | [optional] [default to false]
 **leqi** | **boolean**| Treat Leucine (L) and Isoleucine (I) equivalent. | [optional] [default to false]
 **offset** | **int**| Off set, page starting point, with default value 0. | [optional] [default to 0]
 **size** | **int**| Page size with default value 100. When page size is -1, it returns all records and offset will be ignored. | [optional] [default to 100]

### Return type

[**Report**](Report.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml, text/x-fasta, text/tab-separated-values

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **match_post_post**
> Report match_post_post(peptides => $peptides, taxonids => $taxonids, swissprot => $swissprot, isoform => $isoform, uniref100 => $uniref100, leqi => $leqi, offset => $offset, size => $size)

Do peptide match using POST method.

Retrieve UniProtKB protein sequences that would exactly match to the query peptides using POST method.

### Example 
```perl
use Data::Dumper;
use WWW::SwaggerClient::PeptideMatchAPI20Api;
my $api_instance = WWW::SwaggerClient::PeptideMatchAPI20Api->new(
);

my $peptides = 'peptides_example'; # string | A list of comma-separated peptide sequences (up to 100). Each sequence consists of 3 or more amino acids.
my $taxonids = 'taxonids_example'; # string | A list fo comma-separated NCBI taxonomy IDs.
my $swissprot = 1; # boolean | Only search SwissProt protein sequences.
my $isoform = 1; # boolean | Include isoforms.
my $uniref100 = 1; # boolean | Only search UniRef100 protein sequences.
my $leqi = 1; # boolean | Treat Leucine (L) and Isoleucine (I) equivalent.
my $offset = 56; # int | Off set, page starting point, with default value 0.
my $size = 56; # int | Page size with default value 100. When page size is -1, it returns all records and offset will be ignored.

eval { 
    my $result = $api_instance->match_post_post(peptides => $peptides, taxonids => $taxonids, swissprot => $swissprot, isoform => $isoform, uniref100 => $uniref100, leqi => $leqi, offset => $offset, size => $size);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling PeptideMatchAPI20Api->match_post_post: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **peptides** | **string**| A list of comma-separated peptide sequences (up to 100). Each sequence consists of 3 or more amino acids. | [default to AAVEEGIVLGGGCALLR,SVQYDDVPEYK]
 **taxonids** | **string**| A list fo comma-separated NCBI taxonomy IDs. | [optional] [default to 9606,10090]
 **swissprot** | **boolean**| Only search SwissProt protein sequences. | [optional] [default to true]
 **isoform** | **boolean**| Include isoforms. | [optional] [default to true]
 **uniref100** | **boolean**| Only search UniRef100 protein sequences. | [optional] [default to false]
 **leqi** | **boolean**| Treat Leucine (L) and Isoleucine (I) equivalent. | [optional] [default to false]
 **offset** | **int**| Off set, page starting point, with default value 0. | [optional] [default to 0]
 **size** | **int**| Page size with default value 100. When page size is -1, it returns all records and offset will be ignored. | [optional] [default to 100]

### Return type

[**Report**](Report.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded
 - **Accept**: application/json, application/xml, text/x-fasta, text/tab-separated-values

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

