# WWW::SwaggerClient::Object::ProteinMatchingPeptides

## Load the model package
```perl
use WWW::SwaggerClient::Object::ProteinMatchingPeptides;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**peptide** | **string** | Query peptide. | [optional] 
**match_range** | [**ARRAY[ProteinMatchRange]**](ProteinMatchRange.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


