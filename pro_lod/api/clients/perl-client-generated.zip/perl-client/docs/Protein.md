# WWW::SwaggerClient::Object::Protein

## Load the model package
```perl
use WWW::SwaggerClient::Object::Protein;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**review_status** | **string** | SwissProt or TrEMBL entry. | [optional] 
**ac** | **string** | Protein accession number. | [optional] 
**id** | **string** | Protein ID. | [optional] 
**name** | **string** | Protein name. | [optional] 
**org_name** | **string** | Organism name. | [optional] 
**org_taxon_id** | **int** | Organism taxonomy ID. | [optional] 
**org_taxon_group_name** | **string** | Organism taxonomy group name. | [optional] 
**org_taxon_group_id** | **int** | Organism taxonomy group ID. | [optional] 
**sequence** | **string** | Protein sequence. | [optional] 
**matching_peptides** | [**ARRAY[ProteinMatchingPeptides]**](ProteinMatchingPeptides.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


