# WWW::SwaggerClient::Object::ReportResults

## Load the model package
```perl
use WWW::SwaggerClient::Object::ReportResults;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**query_peptide** | **string** | Query peptide sequence. | [optional] 
**proteins** | [**ARRAY[Protein]**](Protein.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


