# ProResTfulApIs.ProteinComplexTermsApi

All URIs are relative to *https://research.bioinformatics.udel.edu/PRO_API/V1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getSpeciesNonSpecificComplexTerms**](ProteinComplexTermsApi.md#getSpeciesNonSpecificComplexTerms) | **GET** /procomps/ | Returns a list of organism non-specific protein complex terms.
[**getSpeciesSpecificComplexTerms**](ProteinComplexTermsApi.md#getSpeciesSpecificComplexTerms) | **GET** /procomps/organism-specific | Returns a list of organism specific protein complex terms.

<a name="getSpeciesNonSpecificComplexTerms"></a>
# **getSpeciesNonSpecificComplexTerms**
> [PROTerm] getSpeciesNonSpecificComplexTerms(opts)

Returns a list of organism non-specific protein complex terms.

Gets a list of organism non-specific protein complex terms and associated information.

### Example
```javascript
import ProResTfulApIs from 'pro_res_tful_ap_is';

let apiInstance = new ProResTfulApIs.ProteinComplexTermsApi();
let opts = { 
  'searchField': "searchField_example", // String | Search field that needs to be considered for filter
  'searchValue': "searchValue_example", // String | any string or \"null\" or \"not null\" or a list of space separated ids
  'showPROName': true, // Boolean | 
  'showPROTermDefinition': true, // Boolean | 
  'showCategory': true, // Boolean | 
  'showParent': true, // Boolean | 
  'showAnnotation': false, // Boolean | 
  'showAnyRelationship': false, // Boolean | 
  'showChild': false, // Boolean | 
  'showComment': false, // Boolean | 
  'showEcoCycID': false, // Boolean | 
  'showGeneName': false, // Boolean | 
  'showHGNCID': false, // Boolean | 
  'showMGIID': false, // Boolean | 
  'showOrthoIsoform': false, // Boolean | 
  'showOrthoModifiedForm': false, // Boolean | 
  'showPANTHERID': false, // Boolean | 
  'showPIRSFID': false, // Boolean | 
  'showPMID': false, // Boolean | 
  'showReactomeID': false, // Boolean | 
  'showSynonym': false, // Boolean | 
  'showUniProtKBID': false, // Boolean | 
  'offset': 0, // Number | The number of items to skip before starting to collect the result set.
  'limit': 50 // Number | The numbers of items to return.
};
apiInstance.getSpeciesNonSpecificComplexTerms(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] 
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Number**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **Number**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getSpeciesSpecificComplexTerms"></a>
# **getSpeciesSpecificComplexTerms**
> [PROTerm] getSpeciesSpecificComplexTerms(opts)

Returns a list of organism specific protein complex terms.

Gets a list of organism specific protein complex terms and associated information.

### Example
```javascript
import ProResTfulApIs from 'pro_res_tful_ap_is';

let apiInstance = new ProResTfulApIs.ProteinComplexTermsApi();
let opts = { 
  'searchField': "searchField_example", // String | Search field that needs to be considered for filter
  'searchValue': "searchValue_example", // String | any string or \"null\" or \"not null\" or a list of space separated ids
  'showPROName': true, // Boolean | 
  'showPROTermDefinition': true, // Boolean | 
  'showCategory': true, // Boolean | 
  'showParent': true, // Boolean | 
  'showAnnotation': false, // Boolean | 
  'showAnyRelationship': false, // Boolean | 
  'showChild': false, // Boolean | 
  'showComment': false, // Boolean | 
  'showEcoCycID': false, // Boolean | 
  'showGeneName': false, // Boolean | 
  'showHGNCID': false, // Boolean | 
  'showMGIID': false, // Boolean | 
  'showOrthoIsoform': false, // Boolean | 
  'showOrthoModifiedForm': false, // Boolean | 
  'showPANTHERID': false, // Boolean | 
  'showPIRSFID': false, // Boolean | 
  'showPMID': false, // Boolean | 
  'showReactomeID': false, // Boolean | 
  'showSynonym': false, // Boolean | 
  'showUniProtKBID': false, // Boolean | 
  'offset': 0, // Number | The number of items to skip before starting to collect the result set.
  'limit': 50 // Number | The numbers of items to return.
};
apiInstance.getSpeciesSpecificComplexTerms(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] 
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Number**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **Number**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

