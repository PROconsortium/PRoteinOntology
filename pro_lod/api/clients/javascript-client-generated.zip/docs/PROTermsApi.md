# ProResTfulApIs.PROTermsApi

All URIs are relative to *https://research.bioinformatics.udel.edu/PRO_API/V1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getPROTermByIDs**](PROTermsApi.md#getPROTermByIDs) | **GET** /pros/{proIds} | Return PRO terms by IDs.
[**getPROTerms**](PROTermsApi.md#getPROTerms) | **GET** /pros | Search PRO terms.

<a name="getPROTermByIDs"></a>
# **getPROTermByIDs**
> PROTerm getPROTermByIDs(proIds, opts)

Return PRO terms by IDs.

Gets PRO terms and associated information.

### Example
```javascript
import ProResTfulApIs from 'pro_res_tful_ap_is';

let apiInstance = new ProResTfulApIs.PROTermsApi();
let proIds = "proIds_example"; // String | PRO ID(s). Space separated values accepted up to 100.
let opts = { 
  'showPROName': true, // Boolean | 
  'showPROTermDefinition': true, // Boolean | 
  'showCategory': true, // Boolean | 
  'showParent': true, // Boolean | 
  'showAnnotation': false, // Boolean | 
  'showAnyRelationship': false, // Boolean | 
  'showChild': false, // Boolean | 
  'showComment': false, // Boolean | 
  'showEcoCycID': false, // Boolean | 
  'showGeneName': false, // Boolean | 
  'showHGNCID': false, // Boolean | 
  'showMGIID': false, // Boolean | 
  'showOrthoIsoform': false, // Boolean | 
  'showOrthoModifiedForm': false, // Boolean | 
  'showPANTHERID': false, // Boolean | 
  'showPIRSFID': false, // Boolean | 
  'showPMID': false, // Boolean | 
  'showReactomeID': false, // Boolean | 
  'showSynonym': false, // Boolean | 
  'showUniProtKBID': false // Boolean | 
};
apiInstance.getPROTermByIDs(proIds, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **proIds** | **String**| PRO ID(s). Space separated values accepted up to 100. | 
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]

### Return type

[**PROTerm**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getPROTerms"></a>
# **getPROTerms**
> [PROTerm] getPROTerms(opts)

Search PRO terms.

Gets a list of PRO terms and associated information.

### Example
```javascript
import ProResTfulApIs from 'pro_res_tful_ap_is';

let apiInstance = new ProResTfulApIs.PROTermsApi();
let opts = { 
  'searchField': "searchField_example", // String | Search field that needs to be considered for filter
  'searchValue': "searchValue_example", // String | any string or \"null\" or \"not null\" or a list of space separated ids
  'showPROName': true, // Boolean | 
  'showPROTermDefinition': true, // Boolean | 
  'showCategory': true, // Boolean | 
  'showParent': true, // Boolean | 
  'showAnnotation': false, // Boolean | 
  'showAnyRelationship': false, // Boolean | 
  'showChild': false, // Boolean | 
  'showComment': false, // Boolean | 
  'showEcoCycID': false, // Boolean | 
  'showGeneName': false, // Boolean | 
  'showHGNCID': false, // Boolean | 
  'showMGIID': false, // Boolean | 
  'showOrthoIsoform': false, // Boolean | 
  'showOrthoModifiedForm': false, // Boolean | 
  'showPANTHERID': false, // Boolean | 
  'showPIRSFID': false, // Boolean | 
  'showPMID': false, // Boolean | 
  'showReactomeID': false, // Boolean | 
  'showSynonym': false, // Boolean | 
  'showUniProtKBID': false, // Boolean | 
  'offset': 0, // Number | The number of items to skip before starting to collect the result set.
  'limit': 50 // Number | The numbers of items to return.
};
apiInstance.getPROTerms(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] 
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Number**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **Number**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

