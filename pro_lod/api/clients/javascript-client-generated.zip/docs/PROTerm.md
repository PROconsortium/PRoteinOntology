# ProResTfulApIs.PROTerm

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | The PRO ID. | [optional] 
**name** | **String** | The PRO name. | [optional] 
**termDef** | **String** | The PRO term definition. | [optional] 
**category** | **String** | The PRO term category. | [optional] 
**annotation** | [**[Annotation]**](Annotation.md) |  | [optional] 
**anyRelationship** | **String** |  | [optional] 
**child** | **[String]** |  | [optional] 
**ecoCycID** | **String** |  | [optional] 
**geneName** | **String** |  | [optional] 
**hgncID** | **[String]** |  | [optional] 
**mgiID** | **[String]** |  | [optional] 
**orthoIsoform** | **[String]** |  | [optional] 
**orthoModifiedForm** | **[String]** |  | [optional] 
**pantherID** | **String** |  | [optional] 
**paraent** | **[String]** |  | [optional] 
**pirsfID** | **String** |  | [optional] 
**pmID** | **String** |  | [optional] 
**synonym** | **[String]** |  | [optional] 
**reactomeID** | **[String]** |  | [optional] 
**uniprotKBID** | **[String]** |  | [optional] 
