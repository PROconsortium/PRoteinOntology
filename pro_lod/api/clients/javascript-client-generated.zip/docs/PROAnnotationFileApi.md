# ProResTfulApIs.PROAnnotationFileApi

All URIs are relative to *https://research.bioinformatics.udel.edu/PRO_API/V1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getPROAnnotationsByPROIDs**](PROAnnotationFileApi.md#getPROAnnotationsByPROIDs) | **GET** /paf/{proIds} | Returns annotations for the given PRO ID(s).

<a name="getPROAnnotationsByPROIDs"></a>
# **getPROAnnotationsByPROIDs**
> [Annotation] getPROAnnotationsByPROIDs(proIds)

Returns annotations for the given PRO ID(s).

Gets annotations for the given PRO ID(s).

### Example
```javascript
import ProResTfulApIs from 'pro_res_tful_ap_is';

let apiInstance = new ProResTfulApIs.PROAnnotationFileApi();
let proIds = "proIds_example"; // String | PRO ID(s). Space separated values accepted up to 100.

apiInstance.getPROAnnotationsByPROIDs(proIds, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **proIds** | **String**| PRO ID(s). Space separated values accepted up to 100. | 

### Return type

[**[Annotation]**](Annotation.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml, text/tab-separated-values

