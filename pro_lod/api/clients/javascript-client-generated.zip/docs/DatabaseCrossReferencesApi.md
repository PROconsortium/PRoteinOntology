# ProResTfulApIs.DatabaseCrossReferencesApi

All URIs are relative to *https://research.bioinformatics.udel.edu/PRO_API/V1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getPROTermsWithEcoCyCId**](DatabaseCrossReferencesApi.md#getPROTermsWithEcoCyCId) | **GET** /dbxrefs/EcoCyc_ID | Returns a list of PRO terms with EcoCyC ID as cross-reference.
[**getPROTermsWithHGNCId**](DatabaseCrossReferencesApi.md#getPROTermsWithHGNCId) | **GET** /dbxrefs/HGNC_ID | Returns a list of PRO terms with HGNC ID as cross-reference.
[**getPROTermsWithMGIId**](DatabaseCrossReferencesApi.md#getPROTermsWithMGIId) | **GET** /dbxrefs/MGI_ID | Returns a list of PRO terms with MGI ID as cross-reference.
[**getPROTermsWithNCBITaxonID**](DatabaseCrossReferencesApi.md#getPROTermsWithNCBITaxonID) | **GET** /dbxrefs/NCBITaxon_ID | Returns a list of PRO terms with NCBI Taxon ID as cross-reference.
[**getPROTermsWithOntologyId**](DatabaseCrossReferencesApi.md#getPROTermsWithOntologyId) | **GET** /dbxrefs/Ontology_ID | Returns a list of PRO terms with Ontology ID as cross-reference.
[**getPROTermsWithPANTHERId**](DatabaseCrossReferencesApi.md#getPROTermsWithPANTHERId) | **GET** /dbxrefs/PANTHER_ID | Returns a list of PRO terms with PANTHER ID as cross-reference.
[**getPROTermsWithPIRSFId**](DatabaseCrossReferencesApi.md#getPROTermsWithPIRSFId) | **GET** /dbxrefs/PIRSF_ID | Returns a list of PRO terms with PIRSF ID as cross-reference.
[**getPROTermsWithPMID**](DatabaseCrossReferencesApi.md#getPROTermsWithPMID) | **GET** /dbxrefs/PMID | Returns a list of PRO terms with PMID as cross-reference.
[**getPROTermsWithReactomeID**](DatabaseCrossReferencesApi.md#getPROTermsWithReactomeID) | **GET** /dbxrefs/Reactome_ID | Returns a list of PRO terms with Reactome ID as cross-reference.
[**getPROTermsWithUniProtKBID**](DatabaseCrossReferencesApi.md#getPROTermsWithUniProtKBID) | **GET** /dbxrefs/UniProtKB_ID | Returns a list of PRO terms with UniProtKB ID as cross-reference.

<a name="getPROTermsWithEcoCyCId"></a>
# **getPROTermsWithEcoCyCId**
> [PROTerm] getPROTermsWithEcoCyCId(opts)

Returns a list of PRO terms with EcoCyC ID as cross-reference.

Gets a list of PRO terms with EcoCyC ID as cross-reference and associated information.

### Example
```javascript
import ProResTfulApIs from 'pro_res_tful_ap_is';

let apiInstance = new ProResTfulApIs.DatabaseCrossReferencesApi();
let opts = { 
  'searchField': "searchField_example", // String | Search field that needs to be considered for filter
  'searchValue': "searchValue_example", // String | any string or \"null\" or \"not null\" or a list of space separated ids
  'showPROName': true, // Boolean | 
  'showPROTermDefinition': true, // Boolean | 
  'showCategory': true, // Boolean | 
  'showEcoCycID': true, // Boolean | 
  'showAnnotation': false, // Boolean | 
  'showAnyRelationship': false, // Boolean | 
  'showChild': false, // Boolean | 
  'showComment': false, // Boolean | 
  'showGeneName': false, // Boolean | 
  'showHGNCID': false, // Boolean | 
  'showMGIID': false, // Boolean | 
  'showOrthoIsoform': false, // Boolean | 
  'showOrthoModifiedForm': false, // Boolean | 
  'showPANTHERID': false, // Boolean | 
  'showPIRSFID': false, // Boolean | 
  'showPMID': false, // Boolean | 
  'showReactomeID': false, // Boolean | 
  'showSynonym': false, // Boolean | 
  'showUniProtKBID': false, // Boolean | 
  'offset': 0, // Number | The number of items to skip before starting to collect the result set.
  'limit': 50 // Number | The numbers of items to return.
};
apiInstance.getPROTermsWithEcoCyCId(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] 
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showEcoCycID** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Number**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **Number**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getPROTermsWithHGNCId"></a>
# **getPROTermsWithHGNCId**
> [PROTerm] getPROTermsWithHGNCId(opts)

Returns a list of PRO terms with HGNC ID as cross-reference.

Gets a list of PRO terms with HGNC ID as cross-reference and associated information.

### Example
```javascript
import ProResTfulApIs from 'pro_res_tful_ap_is';

let apiInstance = new ProResTfulApIs.DatabaseCrossReferencesApi();
let opts = { 
  'searchField': "searchField_example", // String | Search field that needs to be considered for filter
  'searchValue': "searchValue_example", // String | any string or \"null\" or \"not null\" or a list of space separated ids
  'showPROName': true, // Boolean | 
  'showPROTermDefinition': true, // Boolean | 
  'showCategory': true, // Boolean | 
  'showParent': true, // Boolean | 
  'showHGNCID': true, // Boolean | 
  'showAnnotation': false, // Boolean | 
  'showAnyRelationship': false, // Boolean | 
  'showChild': false, // Boolean | 
  'showComment': false, // Boolean | 
  'showEcoCycID': false, // Boolean | 
  'showGeneName': false, // Boolean | 
  'showMGIID': false, // Boolean | 
  'showOrthoIsoform': false, // Boolean | 
  'showOrthoModifiedForm': false, // Boolean | 
  'showPANTHERID': false, // Boolean | 
  'showPIRSFID': false, // Boolean | 
  'showPMID': false, // Boolean | 
  'showReactomeID': false, // Boolean | 
  'showSynonym': false, // Boolean | 
  'showUniProtKBID': false, // Boolean | 
  'offset': 0, // Number | The number of items to skip before starting to collect the result set.
  'limit': 50 // Number | The numbers of items to return.
};
apiInstance.getPROTermsWithHGNCId(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] 
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showHGNCID** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Number**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **Number**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getPROTermsWithMGIId"></a>
# **getPROTermsWithMGIId**
> [PROTerm] getPROTermsWithMGIId(opts)

Returns a list of PRO terms with MGI ID as cross-reference.

Gets a list of PRO terms with MGI ID as cross-reference and associated information.

### Example
```javascript
import ProResTfulApIs from 'pro_res_tful_ap_is';

let apiInstance = new ProResTfulApIs.DatabaseCrossReferencesApi();
let opts = { 
  'searchField': "searchField_example", // String | Search field that needs to be considered for filter
  'searchValue': "searchValue_example", // String | any string or \"null\" or \"not null\" or a list of space separated ids
  'showPROName': true, // Boolean | 
  'showPROTermDefinition': true, // Boolean | 
  'showCategory': true, // Boolean | 
  'showParent': true, // Boolean | 
  'showMGIID': true, // Boolean | 
  'showAnnotation': false, // Boolean | 
  'showAnyRelationship': false, // Boolean | 
  'showChild': false, // Boolean | 
  'showComment': false, // Boolean | 
  'showEcoCycID': false, // Boolean | 
  'showGeneName': false, // Boolean | 
  'showHGNCID': false, // Boolean | 
  'showOrthoIsoform': false, // Boolean | 
  'showOrthoModifiedForm': false, // Boolean | 
  'showPANTHERID': false, // Boolean | 
  'showPIRSFID': false, // Boolean | 
  'showPMID': false, // Boolean | 
  'showReactomeID': false, // Boolean | 
  'showSynonym': false, // Boolean | 
  'showUniProtKBID': false, // Boolean | 
  'offset': 0, // Number | The number of items to skip before starting to collect the result set.
  'limit': 50 // Number | The numbers of items to return.
};
apiInstance.getPROTermsWithMGIId(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] 
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showMGIID** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Number**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **Number**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getPROTermsWithNCBITaxonID"></a>
# **getPROTermsWithNCBITaxonID**
> [PROTerm] getPROTermsWithNCBITaxonID(opts)

Returns a list of PRO terms with NCBI Taxon ID as cross-reference.

Gets a list of PRO terms with NCBI Taxon ID as cross-reference and associated information.

### Example
```javascript
import ProResTfulApIs from 'pro_res_tful_ap_is';

let apiInstance = new ProResTfulApIs.DatabaseCrossReferencesApi();
let opts = { 
  'searchField': "searchField_example", // String | Search field that needs to be considered for filter
  'searchValue': "searchValue_example", // String | any string or \"null\" or \"not null\" or a list of space separated ids
  'showPROName': true, // Boolean | 
  'showPROTermDefinition': true, // Boolean | 
  'showCategory': true, // Boolean | 
  'showParent': true, // Boolean | 
  'showAnnotation': true, // Boolean | 
  'showAnyRelationship': false, // Boolean | 
  'showChild': false, // Boolean | 
  'showComment': false, // Boolean | 
  'showEcoCycID': false, // Boolean | 
  'showGeneName': false, // Boolean | 
  'showHGNCID': false, // Boolean | 
  'showMGIID': false, // Boolean | 
  'showOrthoIsoform': false, // Boolean | 
  'showOrthoModifiedForm': false, // Boolean | 
  'showPANTHERID': false, // Boolean | 
  'showPIRSFID': false, // Boolean | 
  'showPMID': false, // Boolean | 
  'showReactomeID': false, // Boolean | 
  'showUniProtKBID': false, // Boolean | 
  'offset': 0, // Number | The number of items to skip before starting to collect the result set.
  'limit': 50 // Number | The numbers of items to return.
};
apiInstance.getPROTermsWithNCBITaxonID(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] 
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to true]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Number**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **Number**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getPROTermsWithOntologyId"></a>
# **getPROTermsWithOntologyId**
> [PROTerm] getPROTermsWithOntologyId(opts)

Returns a list of PRO terms with Ontology ID as cross-reference.

Gets a list of PRO terms with Ontology ID as cross-reference and associated information.

### Example
```javascript
import ProResTfulApIs from 'pro_res_tful_ap_is';

let apiInstance = new ProResTfulApIs.DatabaseCrossReferencesApi();
let opts = { 
  'searchField': "searchField_example", // String | Search field that needs to be considered for filter
  'searchValue': "searchValue_example", // String | any string or \"null\" or \"not null\" or a list of space separated ids
  'showPROName': true, // Boolean | 
  'showPROTermDefinition': true, // Boolean | 
  'showCategory': true, // Boolean | 
  'showParent': true, // Boolean | 
  'showAnnotation': true, // Boolean | 
  'showAnyRelationship': false, // Boolean | 
  'showChild': false, // Boolean | 
  'showComment': false, // Boolean | 
  'showEcoCycID': false, // Boolean | 
  'showGeneName': false, // Boolean | 
  'showHGNCID': false, // Boolean | 
  'showMGIID': false, // Boolean | 
  'showOrthoIsoform': false, // Boolean | 
  'showOrthoModifiedForm': false, // Boolean | 
  'showPANTHERID': false, // Boolean | 
  'showPIRSFID': false, // Boolean | 
  'showPMID': false, // Boolean | 
  'showReactomeID': false, // Boolean | 
  'showSynonym': false, // Boolean | 
  'showUniProtKBID': false, // Boolean | 
  'offset': 0, // Number | The number of items to skip before starting to collect the result set.
  'limit': 50 // Number | The numbers of items to return.
};
apiInstance.getPROTermsWithOntologyId(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] 
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to true]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Number**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **Number**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getPROTermsWithPANTHERId"></a>
# **getPROTermsWithPANTHERId**
> [PROTerm] getPROTermsWithPANTHERId(opts)

Returns a list of PRO terms with PANTHER ID as cross-reference.

Gets a list of PRO terms with PANTHER ID as cross-reference and associated information.

### Example
```javascript
import ProResTfulApIs from 'pro_res_tful_ap_is';

let apiInstance = new ProResTfulApIs.DatabaseCrossReferencesApi();
let opts = { 
  'searchField': "searchField_example", // String | Search field that needs to be considered for filter
  'searchValue': "searchValue_example", // String | any string or \"null\" or \"not null\" or a list of space separated ids
  'showPROName': true, // Boolean | 
  'showPROTermDefinition': true, // Boolean | 
  'showCategory': true, // Boolean | 
  'showParent': true, // Boolean | 
  'showPANTHERID': true, // Boolean | 
  'showAnnotation': false, // Boolean | 
  'showAnyRelationship': false, // Boolean | 
  'showChild': false, // Boolean | 
  'showComment': false, // Boolean | 
  'showEcoCycID': false, // Boolean | 
  'showGeneName': false, // Boolean | 
  'showHGNCID': false, // Boolean | 
  'showMGIID': false, // Boolean | 
  'showOrthoIsoform': false, // Boolean | 
  'showOrthoModifiedForm': false, // Boolean | 
  'showPIRSFID': false, // Boolean | 
  'showPMID': false, // Boolean | 
  'showReactomeID': false, // Boolean | 
  'showSynonym': false, // Boolean | 
  'showUniProtKBID': false, // Boolean | 
  'offset': 0, // Number | The number of items to skip before starting to collect the result set.
  'limit': 50 // Number | The numbers of items to return.
};
apiInstance.getPROTermsWithPANTHERId(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] 
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showPANTHERID** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Number**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **Number**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getPROTermsWithPIRSFId"></a>
# **getPROTermsWithPIRSFId**
> [PROTerm] getPROTermsWithPIRSFId(opts)

Returns a list of PRO terms with PIRSF ID as cross-reference.

Gets a list of PRO terms with PIRSF ID as cross-reference and associated information.

### Example
```javascript
import ProResTfulApIs from 'pro_res_tful_ap_is';

let apiInstance = new ProResTfulApIs.DatabaseCrossReferencesApi();
let opts = { 
  'searchField': "searchField_example", // String | Search field that needs to be considered for filter
  'searchValue': "searchValue_example", // String | any string or \"null\" or \"not null\" or a list of space separated ids
  'showPROName': true, // Boolean | 
  'showPROTermDefinition': true, // Boolean | 
  'showCategory': true, // Boolean | 
  'showParent': true, // Boolean | 
  'showPIRSFID': true, // Boolean | 
  'showAnnotation': false, // Boolean | 
  'showAnyRelationship': false, // Boolean | 
  'showChild': false, // Boolean | 
  'showComment': false, // Boolean | 
  'showEcoCycID': false, // Boolean | 
  'showGeneName': false, // Boolean | 
  'showHGNCID': false, // Boolean | 
  'showMGIID': false, // Boolean | 
  'showOrthoIsoform': false, // Boolean | 
  'showOrthoModifiedForm': false, // Boolean | 
  'showPANTHERID': false, // Boolean | 
  'showPMID': false, // Boolean | 
  'showReactomeID': false, // Boolean | 
  'showSynonym': false, // Boolean | 
  'showUniProtKBID': false, // Boolean | 
  'offset': 0, // Number | The number of items to skip before starting to collect the result set.
  'limit': 50 // Number | The numbers of items to return.
};
apiInstance.getPROTermsWithPIRSFId(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] 
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showPIRSFID** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Number**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **Number**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getPROTermsWithPMID"></a>
# **getPROTermsWithPMID**
> [PROTerm] getPROTermsWithPMID(opts)

Returns a list of PRO terms with PMID as cross-reference.

Gets a list of PRO terms with PMID as cross-reference and associated information.

### Example
```javascript
import ProResTfulApIs from 'pro_res_tful_ap_is';

let apiInstance = new ProResTfulApIs.DatabaseCrossReferencesApi();
let opts = { 
  'searchField': "searchField_example", // String | Search field that needs to be considered for filter
  'searchValue': "searchValue_example", // String | any string or \"null\" or \"not null\" or a list of space separated ids
  'showPROName': true, // Boolean | 
  'showPROTermDefinition': true, // Boolean | 
  'showCategory': true, // Boolean | 
  'showParent': true, // Boolean | 
  'showPMID': true, // Boolean | 
  'showAnnotation': false, // Boolean | 
  'showAnyRelationship': false, // Boolean | 
  'showChild': false, // Boolean | 
  'showComment': false, // Boolean | 
  'showEcoCycID': false, // Boolean | 
  'showGeneName': false, // Boolean | 
  'showHGNCID': false, // Boolean | 
  'showMGIID': false, // Boolean | 
  'showOrthoIsoform': false, // Boolean | 
  'showOrthoModifiedForm': false, // Boolean | 
  'showPANTHERID': false, // Boolean | 
  'showPIRSFID': false, // Boolean | 
  'showReactomeID': false, // Boolean | 
  'showSynonym': false, // Boolean | 
  'showUniProtKBID': false, // Boolean | 
  'offset': 0, // Number | The number of items to skip before starting to collect the result set.
  'limit': 50 // Number | The numbers of items to return.
};
apiInstance.getPROTermsWithPMID(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] 
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showPMID** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Number**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **Number**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getPROTermsWithReactomeID"></a>
# **getPROTermsWithReactomeID**
> [PROTerm] getPROTermsWithReactomeID(opts)

Returns a list of PRO terms with Reactome ID as cross-reference.

Gets a list of PRO terms with Reactome ID as cross-reference and associated information.

### Example
```javascript
import ProResTfulApIs from 'pro_res_tful_ap_is';

let apiInstance = new ProResTfulApIs.DatabaseCrossReferencesApi();
let opts = { 
  'searchField': "searchField_example", // String | Search field that needs to be considered for filter
  'searchValue': "searchValue_example", // String | any string or \"null\" or \"not null\" or a list of space separated ids
  'showPROName': true, // Boolean | 
  'showPROTermDefinition': true, // Boolean | 
  'showCategory': true, // Boolean | 
  'showParent': true, // Boolean | 
  'showReactomeID': true, // Boolean | 
  'showAnnotation': false, // Boolean | 
  'showAnyRelationship': false, // Boolean | 
  'showChild': false, // Boolean | 
  'showComment': false, // Boolean | 
  'showEcoCycID': false, // Boolean | 
  'showGeneName': false, // Boolean | 
  'showHGNCID': false, // Boolean | 
  'showMGIID': false, // Boolean | 
  'showOrthoIsoform': false, // Boolean | 
  'showOrthoModifiedForm': false, // Boolean | 
  'showPANTHERID': false, // Boolean | 
  'showPIRSFID': false, // Boolean | 
  'showPMID': false, // Boolean | 
  'showUniProtKBID': false, // Boolean | 
  'offset': 0, // Number | The number of items to skip before starting to collect the result set.
  'limit': 50 // Number | The numbers of items to return.
};
apiInstance.getPROTermsWithReactomeID(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] 
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showReactomeID** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Number**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **Number**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getPROTermsWithUniProtKBID"></a>
# **getPROTermsWithUniProtKBID**
> [PROTerm] getPROTermsWithUniProtKBID(opts)

Returns a list of PRO terms with UniProtKB ID as cross-reference.

Gets a list of PRO terms with UniProtKB ID as cross-reference and associated information.

### Example
```javascript
import ProResTfulApIs from 'pro_res_tful_ap_is';

let apiInstance = new ProResTfulApIs.DatabaseCrossReferencesApi();
let opts = { 
  'searchField': "searchField_example", // String | Search field that needs to be considered for filter
  'searchValue': "searchValue_example", // String | any string or \"null\" or \"not null\" or a list of space separated ids
  'showPROName': true, // Boolean | 
  'showPROTermDefinition': true, // Boolean | 
  'showCategory': true, // Boolean | 
  'showParent': true, // Boolean | 
  'showUniProtKBID': true, // Boolean | 
  'showAnnotation': false, // Boolean | 
  'showAnyRelationship': false, // Boolean | 
  'showChild': false, // Boolean | 
  'showComment': false, // Boolean | 
  'showEcoCycID': false, // Boolean | 
  'showGeneName': false, // Boolean | 
  'showHGNCID': false, // Boolean | 
  'showMGIID': false, // Boolean | 
  'showOrthoIsoform': false, // Boolean | 
  'showOrthoModifiedForm': false, // Boolean | 
  'showPANTHERID': false, // Boolean | 
  'showPIRSFID': false, // Boolean | 
  'showPMID': false, // Boolean | 
  'showReactomeID': false, // Boolean | 
  'offset': 0, // Number | The number of items to skip before starting to collect the result set.
  'limit': 50 // Number | The numbers of items to return.
};
apiInstance.getPROTermsWithUniProtKBID(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] 
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Number**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **Number**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

