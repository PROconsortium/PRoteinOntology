# ProResTfulApIs.Annotation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**modifier** | **String** |  | [optional] 
**relation** | **String** |  | [optional] 
**ontologyID** | **String** |  | [optional] 
**ontologyTerm** | **String** |  | [optional] 
**relativeTo** | **String** |  | [optional] 
**interactionWith** | **String** |  | [optional] 
**evidence** | [**Evidence**](Evidence.md) |  | [optional] 
**ncbiTaxonId** | **Number** |  | [optional] 
**inferredFrom** | **[String]** |  | [optional] 
