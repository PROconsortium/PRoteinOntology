# ProResTfulApIs.DAGApi

All URIs are relative to *https://research.bioinformatics.udel.edu/PRO_API/V1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getAncestorByProIDs**](DAGApi.md#getAncestorByProIDs) | **GET** /dag/ancestor/{proIds} | Returns direct and indirect parent PRO terms by the given PRO ID(s).
[**getChildrenByProIDs**](DAGApi.md#getChildrenByProIDs) | **GET** /dag/children/{proIds} | Returns direct children PRO terms by the given PRO ID(s).
[**getDescendantByProIDs**](DAGApi.md#getDescendantByProIDs) | **GET** /dag/descendant/{proIds} | Returns direct and indirect children PRO terms by the given PRO ID(s).
[**getHierarchyByProID**](DAGApi.md#getHierarchyByProID) | **GET** /dag/hierarchy/{proId} | Returns hierarchy of PRO terms by the given PRO ID.
[**getParentByProIDs**](DAGApi.md#getParentByProIDs) | **GET** /dag/parent/{proIds} | Returns direct parent PRO terms by the given PRO ID(s).

<a name="getAncestorByProIDs"></a>
# **getAncestorByProIDs**
> [PROTerm] getAncestorByProIDs(proIds, opts)

Returns direct and indirect parent PRO terms by the given PRO ID(s).

Gets direct and indirect parent PRO terms by the given PRO ID(s) and associated information.

### Example
```javascript
import ProResTfulApIs from 'pro_res_tful_ap_is';

let apiInstance = new ProResTfulApIs.DAGApi();
let proIds = "proIds_example"; // String | PRO ID(s). Space separated values accepted up to 100.
let opts = { 
  'showPROName': true, // Boolean | 
  'showPROTermDefinition': true, // Boolean | 
  'showCategory': true, // Boolean | 
  'showParent': true, // Boolean | 
  'showAnnotation': false, // Boolean | 
  'showAnyRelationship': false, // Boolean | 
  'showChild': false, // Boolean | 
  'showComment': false, // Boolean | 
  'showEcoCycID': false, // Boolean | 
  'showGeneName': false, // Boolean | 
  'showHGNCID': false, // Boolean | 
  'showMGIID': false, // Boolean | 
  'showOrthoIsoform': false, // Boolean | 
  'showOrthoModifiedForm': false, // Boolean | 
  'showPANTHERID': false, // Boolean | 
  'showPIRSFID': false, // Boolean | 
  'showPMID': false, // Boolean | 
  'showReactomeID': false, // Boolean | 
  'showUniProtKBID': false, // Boolean | 
  'offset': 0, // Number | The number of items to skip before starting to collect the result set.
  'limit': 50 // Number | The numbers of items to return.
};
apiInstance.getAncestorByProIDs(proIds, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **proIds** | **String**| PRO ID(s). Space separated values accepted up to 100. | 
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Number**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **Number**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getChildrenByProIDs"></a>
# **getChildrenByProIDs**
> [PROTerm] getChildrenByProIDs(proIds, opts)

Returns direct children PRO terms by the given PRO ID(s).

Gets direct children PRO terms by the given PRO ID(s) and associated information.

### Example
```javascript
import ProResTfulApIs from 'pro_res_tful_ap_is';

let apiInstance = new ProResTfulApIs.DAGApi();
let proIds = "proIds_example"; // String | PRO ID(s). Space separated values accepted up to 100.
let opts = { 
  'showPROName': true, // Boolean | 
  'showPROTermDefinition': true, // Boolean | 
  'showCategory': true, // Boolean | 
  'showParent': true, // Boolean | 
  'showAnnotation': false, // Boolean | 
  'showAnyRelationship': false, // Boolean | 
  'showChild': false, // Boolean | 
  'showComment': false, // Boolean | 
  'showEcoCycID': false, // Boolean | 
  'showGeneName': false, // Boolean | 
  'showHGNCID': false, // Boolean | 
  'showMGIID': false, // Boolean | 
  'showOrthoIsoform': false, // Boolean | 
  'showOrthoModifiedForm': false, // Boolean | 
  'showPANTHERID': false, // Boolean | 
  'showPIRSFID': false, // Boolean | 
  'showPMID': false, // Boolean | 
  'showReactomeID': false, // Boolean | 
  'showUniProtKBID': false, // Boolean | 
  'offset': 0, // Number | The number of items to skip before starting to collect the result set.
  'limit': 50 // Number | The numbers of items to return.
};
apiInstance.getChildrenByProIDs(proIds, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **proIds** | **String**| PRO ID(s). Space separated values accepted up to 100. | 
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Number**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **Number**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getDescendantByProIDs"></a>
# **getDescendantByProIDs**
> [PROTerm] getDescendantByProIDs(proIds, opts)

Returns direct and indirect children PRO terms by the given PRO ID(s).

Gets direct and indirect children PRO terms by the given PRO ID(s) and associated information.

### Example
```javascript
import ProResTfulApIs from 'pro_res_tful_ap_is';

let apiInstance = new ProResTfulApIs.DAGApi();
let proIds = "proIds_example"; // String | PRO ID(s). Space separated values accepted up to 100.
let opts = { 
  'showPROName': true, // Boolean | 
  'showPROTermDefinition': true, // Boolean | 
  'showCategory': true, // Boolean | 
  'showParent': true, // Boolean | 
  'showAnnotation': false, // Boolean | 
  'showAnyRelationship': false, // Boolean | 
  'showChild': false, // Boolean | 
  'showComment': false, // Boolean | 
  'showEcoCycID': false, // Boolean | 
  'showGeneName': false, // Boolean | 
  'showHGNCID': false, // Boolean | 
  'showMGIID': false, // Boolean | 
  'showOrthoIsoform': false, // Boolean | 
  'showOrthoModifiedForm': false, // Boolean | 
  'showPANTHERID': false, // Boolean | 
  'showPIRSFID': false, // Boolean | 
  'showPMID': false, // Boolean | 
  'showReactomeID': false, // Boolean | 
  'showUniProtKBID': false, // Boolean | 
  'offset': 0, // Number | The number of items to skip before starting to collect the result set.
  'limit': 50 // Number | The numbers of items to return.
};
apiInstance.getDescendantByProIDs(proIds, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **proIds** | **String**| PRO ID(s). Space separated values accepted up to 100. | 
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Number**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **Number**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getHierarchyByProID"></a>
# **getHierarchyByProID**
> [ChildParentPair] getHierarchyByProID(proId, opts)

Returns hierarchy of PRO terms by the given PRO ID.

Gets hierarchy of PRO terms by the given PRO ID.

### Example
```javascript
import ProResTfulApIs from 'pro_res_tful_ap_is';

let apiInstance = new ProResTfulApIs.DAGApi();
let proId = "proId_example"; // String | Space separated PRO ID(s).
let opts = { 
  'showPROName': true, // Boolean | 
  'showPROTermDefinition': true, // Boolean | 
  'showCategory': true, // Boolean | 
  'showAnnotation': false, // Boolean | 
  'showAnyRelationship': false, // Boolean | 
  'showComment': false, // Boolean | 
  'showEcoCycID': false, // Boolean | 
  'showGeneName': false, // Boolean | 
  'showHGNCID': false, // Boolean | 
  'showMGIID': false, // Boolean | 
  'showOrthoIsoform': false, // Boolean | 
  'showOrthoModifiedForm': false, // Boolean | 
  'showPANTHERID': false, // Boolean | 
  'showPIRSFID': false, // Boolean | 
  'showPMID': false, // Boolean | 
  'showReactomeID': false, // Boolean | 
  'showSynonym': false, // Boolean | 
  'showTaxonID': false, // Boolean | 
  'showUniProtKBID': false // Boolean | 
};
apiInstance.getHierarchyByProID(proId, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **proId** | **String**| Space separated PRO ID(s). | 
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showTaxonID** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]

### Return type

[**[ChildParentPair]**](ChildParentPair.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getParentByProIDs"></a>
# **getParentByProIDs**
> [PROTerm] getParentByProIDs(proIds, opts)

Returns direct parent PRO terms by the given PRO ID(s).

Gets direct parent PRO terms by the given PRO ID(s) and associated information.

### Example
```javascript
import ProResTfulApIs from 'pro_res_tful_ap_is';

let apiInstance = new ProResTfulApIs.DAGApi();
let proIds = "proIds_example"; // String | PRO ID(s). Space separated values accepted up to 100.
let opts = { 
  'showPROName': true, // Boolean | 
  'showPROTermDefinition': true, // Boolean | 
  'showCategory': true, // Boolean | 
  'showParent': true, // Boolean | 
  'showAnnotation': false, // Boolean | 
  'showAnyRelationship': false, // Boolean | 
  'showChild': false, // Boolean | 
  'showComment': false, // Boolean | 
  'showEcoCycID': false, // Boolean | 
  'showGeneName': false, // Boolean | 
  'showHGNCID': false, // Boolean | 
  'showMGIID': false, // Boolean | 
  'showOrthoIsoform': false, // Boolean | 
  'showOrthoModifiedForm': false, // Boolean | 
  'showPANTHERID': false, // Boolean | 
  'showPIRSFID': false, // Boolean | 
  'showPMID': false, // Boolean | 
  'showReactomeID': false, // Boolean | 
  'showUniProtKBID': false, // Boolean | 
  'offset': 0, // Number | The number of items to skip before starting to collect the result set.
  'limit': 50 // Number | The numbers of items to return.
};
apiInstance.getParentByProIDs(proIds, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **proIds** | **String**| PRO ID(s). Space separated values accepted up to 100. | 
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Number**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **Number**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

