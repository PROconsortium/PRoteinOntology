# ProResTfulApIs.Evidence

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**evidenceSource** | **[String]** |  | [optional] 
**evidenceCode** | **String** |  | [optional] 
