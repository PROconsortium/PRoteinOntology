# ProResTfulApIs.OBOFileApi

All URIs are relative to *https://research.bioinformatics.udel.edu/PRO_API/V1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getOBOByPROIDs**](OBOFileApi.md#getOBOByPROIDs) | **GET** /obo/{proIds} | Returns PRO term in OBO format for the given PRO ID(s).

<a name="getOBOByPROIDs"></a>
# **getOBOByPROIDs**
> &#x27;String&#x27; getOBOByPROIDs(proIds)

Returns PRO term in OBO format for the given PRO ID(s).

Gets PRO term in OBO format for the given PRO ID(s).

### Example
```javascript
import ProResTfulApIs from 'pro_res_tful_ap_is';

let apiInstance = new ProResTfulApIs.OBOFileApi();
let proIds = "proIds_example"; // String | PRO ID(s). Space separated values accepted up to 100.

apiInstance.getOBOByPROIDs(proIds, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **proIds** | **String**| PRO ID(s). Space separated values accepted up to 100. | 

### Return type

**&#x27;String&#x27;**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json

