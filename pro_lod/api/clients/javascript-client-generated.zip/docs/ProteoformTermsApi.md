# ProResTfulApIs.ProteoformTermsApi

All URIs are relative to *https://research.bioinformatics.udel.edu/PRO_API/V1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getAcetylatedForms**](ProteoformTermsApi.md#getAcetylatedForms) | **GET** /proforms/modification/acetylated | Returns a list of acetylated protein forms.
[**getGlycosylatedForms**](ProteoformTermsApi.md#getGlycosylatedForms) | **GET** /proforms/modification/glycosylated | Returns a list of glycosylated protein forms.
[**getMethylatedForms**](ProteoformTermsApi.md#getMethylatedForms) | **GET** /proforms/modification/methylated | Returns a list of methylated protein forms.
[**getModifiedForms**](ProteoformTermsApi.md#getModifiedForms) | **GET** /proforms/modification | Returns a list of modified protein forms.
[**getOrganismSequenceLevelProteoforms**](ProteoformTermsApi.md#getOrganismSequenceLevelProteoforms) | **GET** /proforms/organism-sequence | Returns a list of organism-sequence level protein forms.
[**getOrthoIsoForms**](ProteoformTermsApi.md#getOrthoIsoForms) | **GET** /proforms/orthoisoform | Returns a list of ortho-isoform protein forms.
[**getOrthoModForms**](ProteoformTermsApi.md#getOrthoModForms) | **GET** /proforms/orthomodform | Returns a list of ortho-modform protein forms.
[**getPhosphorylatedForms**](ProteoformTermsApi.md#getPhosphorylatedForms) | **GET** /proforms/modification/phosphorylated | Returns a list of phosphorylated protein forms.
[**getSequenceLevelProteoforms**](ProteoformTermsApi.md#getSequenceLevelProteoforms) | **GET** /proforms/sequence | Returns a list of sequence level protein forms.
[**getUbiquitinatedForms**](ProteoformTermsApi.md#getUbiquitinatedForms) | **GET** /proforms/modification/ubiquitinated | Returns a list of ubiquitinated protein forms.

<a name="getAcetylatedForms"></a>
# **getAcetylatedForms**
> [PROTerm] getAcetylatedForms(opts)

Returns a list of acetylated protein forms.

Gets a list of acetylated protein forms and associated information.

### Example
```javascript
import ProResTfulApIs from 'pro_res_tful_ap_is';

let apiInstance = new ProResTfulApIs.ProteoformTermsApi();
let opts = { 
  'searchField': "searchField_example", // String | Search field that needs to be considered for filter
  'searchValue': "searchValue_example", // String | any string or \"null\" or \"not null\" or a list of space separated ids
  'showPROName': true, // Boolean | 
  'showPROTermDefinition': true, // Boolean | 
  'showCategory': true, // Boolean | 
  'showParent': true, // Boolean | 
  'showAnnotation': false, // Boolean | 
  'showAnyRelationship': false, // Boolean | 
  'showChild': false, // Boolean | 
  'showComment': false, // Boolean | 
  'showEcoCycID': false, // Boolean | 
  'showGeneName': false, // Boolean | 
  'showHGNCID': false, // Boolean | 
  'showMGIID': false, // Boolean | 
  'showOrthoIsoform': false, // Boolean | 
  'showOrthoModifiedForm': false, // Boolean | 
  'showPANTHERID': false, // Boolean | 
  'showPIRSFID': false, // Boolean | 
  'showPMID': false, // Boolean | 
  'showReactomeID': false, // Boolean | 
  'showSynonym': false, // Boolean | 
  'showUniProtKBID': false, // Boolean | 
  'offset': 0, // Number | The number of items to skip before starting to collect the result set.
  'limit': 50 // Number | The numbers of items to return.
};
apiInstance.getAcetylatedForms(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] 
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Number**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **Number**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getGlycosylatedForms"></a>
# **getGlycosylatedForms**
> [PROTerm] getGlycosylatedForms(opts)

Returns a list of glycosylated protein forms.

Gets a list of glycosylated protein forms and associated information.

### Example
```javascript
import ProResTfulApIs from 'pro_res_tful_ap_is';

let apiInstance = new ProResTfulApIs.ProteoformTermsApi();
let opts = { 
  'searchField': "searchField_example", // String | Search field that needs to be considered for filter
  'searchValue': "searchValue_example", // String | any string or \"null\" or \"not null\" or a list of space separated ids
  'showPROName': true, // Boolean | 
  'showPROTermDefinition': true, // Boolean | 
  'showCategory': true, // Boolean | 
  'showParent': true, // Boolean | 
  'showAnnotation': false, // Boolean | 
  'showAnyRelationship': false, // Boolean | 
  'showChild': false, // Boolean | 
  'showComment': false, // Boolean | 
  'showEcoCycID': false, // Boolean | 
  'showGeneName': false, // Boolean | 
  'showHGNCID': false, // Boolean | 
  'showMGIID': false, // Boolean | 
  'showOrthoIsoform': false, // Boolean | 
  'showOrthoModifiedForm': false, // Boolean | 
  'showPANTHERID': false, // Boolean | 
  'showPIRSFID': false, // Boolean | 
  'showPMID': false, // Boolean | 
  'showReactomeID': false, // Boolean | 
  'showSynonym': false, // Boolean | 
  'showUniProtKBID': false, // Boolean | 
  'offset': 0, // Number | The number of items to skip before starting to collect the result set.
  'limit': 50 // Number | The numbers of items to return.
};
apiInstance.getGlycosylatedForms(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] 
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Number**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **Number**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getMethylatedForms"></a>
# **getMethylatedForms**
> [PROTerm] getMethylatedForms(opts)

Returns a list of methylated protein forms.

Gets a list of methylated protein forms and associated information.

### Example
```javascript
import ProResTfulApIs from 'pro_res_tful_ap_is';

let apiInstance = new ProResTfulApIs.ProteoformTermsApi();
let opts = { 
  'searchField': "searchField_example", // String | Search field that needs to be considered for filter
  'searchValue': "searchValue_example", // String | any string or \"null\" or \"not null\" or a list of space separated ids
  'showPROName': true, // Boolean | 
  'showPROTermDefinition': true, // Boolean | 
  'showCategory': true, // Boolean | 
  'showParent': true, // Boolean | 
  'showAnnotation': false, // Boolean | 
  'showAnyRelationship': false, // Boolean | 
  'showChild': false, // Boolean | 
  'showComment': false, // Boolean | 
  'showEcoCycID': false, // Boolean | 
  'showGeneName': false, // Boolean | 
  'showHGNCID': false, // Boolean | 
  'showMGIID': false, // Boolean | 
  'showOrthoIsoform': false, // Boolean | 
  'showOrthoModifiedForm': false, // Boolean | 
  'showPANTHERID': false, // Boolean | 
  'showPIRSFID': false, // Boolean | 
  'showPMID': false, // Boolean | 
  'showReactomeID': false, // Boolean | 
  'showSynonym': false, // Boolean | 
  'showUniProtKBID': false, // Boolean | 
  'offset': 0, // Number | The number of items to skip before starting to collect the result set.
  'limit': 50 // Number | The numbers of items to return.
};
apiInstance.getMethylatedForms(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] 
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Number**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **Number**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getModifiedForms"></a>
# **getModifiedForms**
> [PROTerm] getModifiedForms(opts)

Returns a list of modified protein forms.

Gets a list of modified protein forms and associated information.

### Example
```javascript
import ProResTfulApIs from 'pro_res_tful_ap_is';

let apiInstance = new ProResTfulApIs.ProteoformTermsApi();
let opts = { 
  'searchField': "searchField_example", // String | Search field that needs to be considered for filter
  'searchValue': "searchValue_example", // String | any string or \"null\" or \"not null\" or a list of space separated ids
  'showPROName': true, // Boolean | 
  'showPROTermDefinition': true, // Boolean | 
  'showCategory': true, // Boolean | 
  'showParent': true, // Boolean | 
  'showAnnotation': false, // Boolean | 
  'showAnyRelationship': false, // Boolean | 
  'showChild': false, // Boolean | 
  'showComment': false, // Boolean | 
  'showEcoCycID': false, // Boolean | 
  'showGeneName': false, // Boolean | 
  'showHGNCID': false, // Boolean | 
  'showMGIID': false, // Boolean | 
  'showOrthoIsoform': false, // Boolean | 
  'showOrthoModifiedForm': false, // Boolean | 
  'showPANTHERID': false, // Boolean | 
  'showPIRSFID': false, // Boolean | 
  'showPMID': false, // Boolean | 
  'showReactomeID': false, // Boolean | 
  'showSynonym': false, // Boolean | 
  'showUniProtKBID': false, // Boolean | 
  'offset': 0, // Number | The number of items to skip before starting to collect the result set.
  'limit': 50 // Number | The numbers of items to return.
};
apiInstance.getModifiedForms(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] 
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Number**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **Number**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getOrganismSequenceLevelProteoforms"></a>
# **getOrganismSequenceLevelProteoforms**
> [PROTerm] getOrganismSequenceLevelProteoforms(opts)

Returns a list of organism-sequence level protein forms.

Gets a list of organism-sequence level protein forms and associated information.

### Example
```javascript
import ProResTfulApIs from 'pro_res_tful_ap_is';

let apiInstance = new ProResTfulApIs.ProteoformTermsApi();
let opts = { 
  'searchField': "searchField_example", // String | Search field that needs to be considered for filter
  'searchValue': "searchValue_example", // String | any string or \"null\" or \"not null\" or a list of space separated ids
  'showPROName': true, // Boolean | 
  'showPROTermDefinition': true, // Boolean | 
  'showCategory': true, // Boolean | 
  'showParent': true, // Boolean | 
  'showAnnotation': false, // Boolean | 
  'showAnyRelationship': false, // Boolean | 
  'showChild': false, // Boolean | 
  'showComment': false, // Boolean | 
  'showEcoCycID': false, // Boolean | 
  'showGeneName': false, // Boolean | 
  'showHGNCID': false, // Boolean | 
  'showMGIID': false, // Boolean | 
  'showOrthoIsoform': false, // Boolean | 
  'showOrthoModifiedForm': false, // Boolean | 
  'showPANTHERID': false, // Boolean | 
  'showPIRSFID': false, // Boolean | 
  'showPMID': false, // Boolean | 
  'showReactomeID': false, // Boolean | 
  'showSynonym': false, // Boolean | 
  'showUniProtKBID': false, // Boolean | 
  'offset': 0, // Number | The number of items to skip before starting to collect the result set.
  'limit': 50 // Number | The numbers of items to return.
};
apiInstance.getOrganismSequenceLevelProteoforms(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] 
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Number**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **Number**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getOrthoIsoForms"></a>
# **getOrthoIsoForms**
> [PROTerm] getOrthoIsoForms(opts)

Returns a list of ortho-isoform protein forms.

Gets a list of ortho-isoform protien forms and associated information.

### Example
```javascript
import ProResTfulApIs from 'pro_res_tful_ap_is';

let apiInstance = new ProResTfulApIs.ProteoformTermsApi();
let opts = { 
  'searchField': "searchField_example", // String | Search field that needs to be considered for filter
  'searchValue': "searchValue_example", // String | any string or \"null\" or \"not null\" or a list of space separated ids
  'showPROName': true, // Boolean | 
  'showPROTermDefinition': true, // Boolean | 
  'showCategory': true, // Boolean | 
  'showParent': true, // Boolean | 
  'showAnnotation': false, // Boolean | 
  'showAnyRelationship': false, // Boolean | 
  'showChild': false, // Boolean | 
  'showComment': false, // Boolean | 
  'showEcoCycID': false, // Boolean | 
  'showGeneName': false, // Boolean | 
  'showHGNCID': false, // Boolean | 
  'showMGIID': false, // Boolean | 
  'showOrthoIsoform': false, // Boolean | 
  'showOrthoModifiedForm': false, // Boolean | 
  'showPANTHERID': false, // Boolean | 
  'showPIRSFID': false, // Boolean | 
  'showPMID': false, // Boolean | 
  'showReactomeID': false, // Boolean | 
  'showSynonym': false, // Boolean | 
  'showUniProtKBID': false, // Boolean | 
  'offset': 0, // Number | The number of items to skip before starting to collect the result set.
  'limit': 50 // Number | The numbers of items to return.
};
apiInstance.getOrthoIsoForms(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] 
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Number**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **Number**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getOrthoModForms"></a>
# **getOrthoModForms**
> [PROTerm] getOrthoModForms(opts)

Returns a list of ortho-modform protein forms.

Gets a list of ortho-modform protein forms and associated information.

### Example
```javascript
import ProResTfulApIs from 'pro_res_tful_ap_is';

let apiInstance = new ProResTfulApIs.ProteoformTermsApi();
let opts = { 
  'searchField': "searchField_example", // String | Search field that needs to be considered for filter
  'searchValue': "searchValue_example", // String | any string or \"null\" or \"not null\" or a list of space separated ids
  'showPROName': true, // Boolean | 
  'showPROTermDefinition': true, // Boolean | 
  'showCategory': true, // Boolean | 
  'showParent': true, // Boolean | 
  'showAnnotation': false, // Boolean | 
  'showAnyRelationship': false, // Boolean | 
  'showChild': false, // Boolean | 
  'showComment': false, // Boolean | 
  'showEcoCycID': false, // Boolean | 
  'showGeneName': false, // Boolean | 
  'showHGNCID': false, // Boolean | 
  'showMGIID': false, // Boolean | 
  'showOrthoIsoform': false, // Boolean | 
  'showOrthoModifiedForm': false, // Boolean | 
  'showPANTHERID': false, // Boolean | 
  'showPIRSFID': false, // Boolean | 
  'showPMID': false, // Boolean | 
  'showReactomeID': false, // Boolean | 
  'showSynonym': false, // Boolean | 
  'showUniProtKBID': false, // Boolean | 
  'offset': 0, // Number | The number of items to skip before starting to collect the result set.
  'limit': 50 // Number | The numbers of items to return.
};
apiInstance.getOrthoModForms(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] 
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Number**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **Number**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getPhosphorylatedForms"></a>
# **getPhosphorylatedForms**
> [PROTerm] getPhosphorylatedForms(opts)

Returns a list of phosphorylated protein forms.

Gets a list of phosphorylated protein forms and associated information.

### Example
```javascript
import ProResTfulApIs from 'pro_res_tful_ap_is';

let apiInstance = new ProResTfulApIs.ProteoformTermsApi();
let opts = { 
  'searchField': "searchField_example", // String | Search field that needs to be considered for filter
  'searchValue': "searchValue_example", // String | any string or \"null\" or \"not null\" or a list of space separated ids
  'showPROName': true, // Boolean | 
  'showPROTermDefinition': true, // Boolean | 
  'showCategory': true, // Boolean | 
  'showParent': true, // Boolean | 
  'showAnnotation': false, // Boolean | 
  'showAnyRelationship': false, // Boolean | 
  'showChild': false, // Boolean | 
  'showComment': false, // Boolean | 
  'showEcoCycID': false, // Boolean | 
  'showGeneName': false, // Boolean | 
  'showHGNCID': false, // Boolean | 
  'showMGIID': false, // Boolean | 
  'showOrthoIsoform': false, // Boolean | 
  'showOrthoModifiedForm': false, // Boolean | 
  'showPANTHERID': false, // Boolean | 
  'showPIRSFID': false, // Boolean | 
  'showPMID': false, // Boolean | 
  'showReactomeID': false, // Boolean | 
  'showSynonym': false, // Boolean | 
  'showUniProtKBID': false, // Boolean | 
  'offset': 0, // Number | The number of items to skip before starting to collect the result set.
  'limit': 50 // Number | The numbers of items to return.
};
apiInstance.getPhosphorylatedForms(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] 
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Number**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **Number**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getSequenceLevelProteoforms"></a>
# **getSequenceLevelProteoforms**
> [PROTerm] getSequenceLevelProteoforms(opts)

Returns a list of sequence level protein forms.

Gets a list of sequence level protein forms and associated information.

### Example
```javascript
import ProResTfulApIs from 'pro_res_tful_ap_is';

let apiInstance = new ProResTfulApIs.ProteoformTermsApi();
let opts = { 
  'searchField': "searchField_example", // String | Search field that needs to be considered for filter
  'searchValue': "searchValue_example", // String | any string or \"null\" or \"not null\" or a list of space separated ids
  'showPROName': true, // Boolean | 
  'showPROTermDefinition': true, // Boolean | 
  'showCategory': true, // Boolean | 
  'showParent': true, // Boolean | 
  'showAnnotation': false, // Boolean | 
  'showAnyRelationship': false, // Boolean | 
  'showChild': false, // Boolean | 
  'showComment': false, // Boolean | 
  'showEcoCycID': false, // Boolean | 
  'showGeneName': false, // Boolean | 
  'showHGNCID': false, // Boolean | 
  'showMGIID': false, // Boolean | 
  'showOrthoIsoform': false, // Boolean | 
  'showOrthoModifiedForm': false, // Boolean | 
  'showPANTHERID': false, // Boolean | 
  'showPIRSFID': false, // Boolean | 
  'showPMID': false, // Boolean | 
  'showReactomeID': false, // Boolean | 
  'showSynonym': false, // Boolean | 
  'showUniProtKBID': false, // Boolean | 
  'offset': 0, // Number | The number of items to skip before starting to collect the result set.
  'limit': 50 // Number | The numbers of items to return.
};
apiInstance.getSequenceLevelProteoforms(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] 
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Number**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **Number**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getUbiquitinatedForms"></a>
# **getUbiquitinatedForms**
> [PROTerm] getUbiquitinatedForms(opts)

Returns a list of ubiquitinated protein forms.

Gets a list of ubiquitinated protein forms and associated information.

### Example
```javascript
import ProResTfulApIs from 'pro_res_tful_ap_is';

let apiInstance = new ProResTfulApIs.ProteoformTermsApi();
let opts = { 
  'searchField': "searchField_example", // String | Search field that needs to be considered for filter
  'searchValue': "searchValue_example", // String | any string or \"null\" or \"not null\" or a list of space separated ids
  'showPROName': true, // Boolean | 
  'showPROTermDefinition': true, // Boolean | 
  'showCategory': true, // Boolean | 
  'showParent': true, // Boolean | 
  'showAnnotation': false, // Boolean | 
  'showAnyRelationship': false, // Boolean | 
  'showChild': false, // Boolean | 
  'showComment': false, // Boolean | 
  'showEcoCycID': false, // Boolean | 
  'showGeneName': false, // Boolean | 
  'showHGNCID': false, // Boolean | 
  'showMGIID': false, // Boolean | 
  'showOrthoIsoform': false, // Boolean | 
  'showOrthoModifiedForm': false, // Boolean | 
  'showPANTHERID': false, // Boolean | 
  'showPIRSFID': false, // Boolean | 
  'showPMID': false, // Boolean | 
  'showReactomeID': false, // Boolean | 
  'showSynonym': false, // Boolean | 
  'showUniProtKBID': false, // Boolean | 
  'offset': 0, // Number | The number of items to skip before starting to collect the result set.
  'limit': 50 // Number | The numbers of items to return.
};
apiInstance.getUbiquitinatedForms(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] 
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Number**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **Number**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

