# ProteoformTermsApi

All URIs are relative to *https://research.bioinformatics.udel.edu/PRO_API/V1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getAcetylatedForms**](ProteoformTermsApi.md#getAcetylatedForms) | **GET** /proforms/modification/acetylated | Returns a list of acetylated protein forms.
[**getGlycosylatedForms**](ProteoformTermsApi.md#getGlycosylatedForms) | **GET** /proforms/modification/glycosylated | Returns a list of glycosylated protein forms.
[**getMethylatedForms**](ProteoformTermsApi.md#getMethylatedForms) | **GET** /proforms/modification/methylated | Returns a list of methylated protein forms.
[**getModifiedForms**](ProteoformTermsApi.md#getModifiedForms) | **GET** /proforms/modification | Returns a list of modified protein forms.
[**getOrganismSequenceLevelProteoforms**](ProteoformTermsApi.md#getOrganismSequenceLevelProteoforms) | **GET** /proforms/organism-sequence | Returns a list of organism-sequence level protein forms.
[**getOrthoIsoForms**](ProteoformTermsApi.md#getOrthoIsoForms) | **GET** /proforms/orthoisoform | Returns a list of ortho-isoform protein forms.
[**getOrthoModForms**](ProteoformTermsApi.md#getOrthoModForms) | **GET** /proforms/orthomodform | Returns a list of ortho-modform protein forms.
[**getPhosphorylatedForms**](ProteoformTermsApi.md#getPhosphorylatedForms) | **GET** /proforms/modification/phosphorylated | Returns a list of phosphorylated protein forms.
[**getSequenceLevelProteoforms**](ProteoformTermsApi.md#getSequenceLevelProteoforms) | **GET** /proforms/sequence | Returns a list of sequence level protein forms.
[**getUbiquitinatedForms**](ProteoformTermsApi.md#getUbiquitinatedForms) | **GET** /proforms/modification/ubiquitinated | Returns a list of ubiquitinated protein forms.

<a name="getAcetylatedForms"></a>
# **getAcetylatedForms**
> List&lt;PROTerm&gt; getAcetylatedForms(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit)

Returns a list of acetylated protein forms.

Gets a list of acetylated protein forms and associated information.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ProteoformTermsApi;


ProteoformTermsApi apiInstance = new ProteoformTermsApi();
String searchField = "searchField_example"; // String | Search field that needs to be considered for filter
String searchValue = "searchValue_example"; // String | any string or \"null\" or \"not null\" or a list of space separated ids
Boolean showPROName = true; // Boolean | 
Boolean showPROTermDefinition = true; // Boolean | 
Boolean showCategory = true; // Boolean | 
Boolean showParent = true; // Boolean | 
Boolean showAnnotation = false; // Boolean | 
Boolean showAnyRelationship = false; // Boolean | 
Boolean showChild = false; // Boolean | 
Boolean showComment = false; // Boolean | 
Boolean showEcoCycID = false; // Boolean | 
Boolean showGeneName = false; // Boolean | 
Boolean showHGNCID = false; // Boolean | 
Boolean showMGIID = false; // Boolean | 
Boolean showOrthoIsoform = false; // Boolean | 
Boolean showOrthoModifiedForm = false; // Boolean | 
Boolean showPANTHERID = false; // Boolean | 
Boolean showPIRSFID = false; // Boolean | 
Boolean showPMID = false; // Boolean | 
Boolean showReactomeID = false; // Boolean | 
Boolean showSynonym = false; // Boolean | 
Boolean showUniProtKBID = false; // Boolean | 
Integer offset = 0; // Integer | The number of items to skip before starting to collect the result set.
Integer limit = 50; // Integer | The numbers of items to return.
try {
    List<PROTerm> result = apiInstance.getAcetylatedForms(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProteoformTermsApi#getAcetylatedForms");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] [enum: Any_field, Any_relationship, Category, Child, Comment, EcoCyc_ID, Gene_Name, HGNC_ID, PRO_ID, Interaction_with, MGI_ID, Modifier, Ontology_ID, Ontology_term, Ortho-isoform, Ortho-modform, Panther_ID, Parent, PIRSF_ID, PMID, PRO_term_definition, PRO_name, PRO_name_synonyms, Reactiome_ID, Relation, Taxon_ID, UniProtKB_ID]
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional]
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Integer**| The number of items to skip before starting to collect the result set. | [optional] [default to 0] [enum: ]
 **limit** | **Integer**| The numbers of items to return. | [optional] [default to 50] [enum: ]

### Return type

[**List&lt;PROTerm&gt;**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getGlycosylatedForms"></a>
# **getGlycosylatedForms**
> List&lt;PROTerm&gt; getGlycosylatedForms(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit)

Returns a list of glycosylated protein forms.

Gets a list of glycosylated protein forms and associated information.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ProteoformTermsApi;


ProteoformTermsApi apiInstance = new ProteoformTermsApi();
String searchField = "searchField_example"; // String | Search field that needs to be considered for filter
String searchValue = "searchValue_example"; // String | any string or \"null\" or \"not null\" or a list of space separated ids
Boolean showPROName = true; // Boolean | 
Boolean showPROTermDefinition = true; // Boolean | 
Boolean showCategory = true; // Boolean | 
Boolean showParent = true; // Boolean | 
Boolean showAnnotation = false; // Boolean | 
Boolean showAnyRelationship = false; // Boolean | 
Boolean showChild = false; // Boolean | 
Boolean showComment = false; // Boolean | 
Boolean showEcoCycID = false; // Boolean | 
Boolean showGeneName = false; // Boolean | 
Boolean showHGNCID = false; // Boolean | 
Boolean showMGIID = false; // Boolean | 
Boolean showOrthoIsoform = false; // Boolean | 
Boolean showOrthoModifiedForm = false; // Boolean | 
Boolean showPANTHERID = false; // Boolean | 
Boolean showPIRSFID = false; // Boolean | 
Boolean showPMID = false; // Boolean | 
Boolean showReactomeID = false; // Boolean | 
Boolean showSynonym = false; // Boolean | 
Boolean showUniProtKBID = false; // Boolean | 
Integer offset = 0; // Integer | The number of items to skip before starting to collect the result set.
Integer limit = 50; // Integer | The numbers of items to return.
try {
    List<PROTerm> result = apiInstance.getGlycosylatedForms(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProteoformTermsApi#getGlycosylatedForms");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] [enum: Any_field, Any_relationship, Category, Child, Comment, EcoCyc_ID, Gene_Name, HGNC_ID, PRO_ID, Interaction_with, MGI_ID, Modifier, Ontology_ID, Ontology_term, Ortho-isoform, Ortho-modform, Panther_ID, Parent, PIRSF_ID, PMID, PRO_term_definition, PRO_name, PRO_name_synonyms, Reactiome_ID, Relation, Taxon_ID, UniProtKB_ID]
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional]
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Integer**| The number of items to skip before starting to collect the result set. | [optional] [default to 0] [enum: ]
 **limit** | **Integer**| The numbers of items to return. | [optional] [default to 50] [enum: ]

### Return type

[**List&lt;PROTerm&gt;**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getMethylatedForms"></a>
# **getMethylatedForms**
> List&lt;PROTerm&gt; getMethylatedForms(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit)

Returns a list of methylated protein forms.

Gets a list of methylated protein forms and associated information.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ProteoformTermsApi;


ProteoformTermsApi apiInstance = new ProteoformTermsApi();
String searchField = "searchField_example"; // String | Search field that needs to be considered for filter
String searchValue = "searchValue_example"; // String | any string or \"null\" or \"not null\" or a list of space separated ids
Boolean showPROName = true; // Boolean | 
Boolean showPROTermDefinition = true; // Boolean | 
Boolean showCategory = true; // Boolean | 
Boolean showParent = true; // Boolean | 
Boolean showAnnotation = false; // Boolean | 
Boolean showAnyRelationship = false; // Boolean | 
Boolean showChild = false; // Boolean | 
Boolean showComment = false; // Boolean | 
Boolean showEcoCycID = false; // Boolean | 
Boolean showGeneName = false; // Boolean | 
Boolean showHGNCID = false; // Boolean | 
Boolean showMGIID = false; // Boolean | 
Boolean showOrthoIsoform = false; // Boolean | 
Boolean showOrthoModifiedForm = false; // Boolean | 
Boolean showPANTHERID = false; // Boolean | 
Boolean showPIRSFID = false; // Boolean | 
Boolean showPMID = false; // Boolean | 
Boolean showReactomeID = false; // Boolean | 
Boolean showSynonym = false; // Boolean | 
Boolean showUniProtKBID = false; // Boolean | 
Integer offset = 0; // Integer | The number of items to skip before starting to collect the result set.
Integer limit = 50; // Integer | The numbers of items to return.
try {
    List<PROTerm> result = apiInstance.getMethylatedForms(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProteoformTermsApi#getMethylatedForms");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] [enum: Any_field, Any_relationship, Category, Child, Comment, EcoCyc_ID, Gene_Name, HGNC_ID, PRO_ID, Interaction_with, MGI_ID, Modifier, Ontology_ID, Ontology_term, Ortho-isoform, Ortho-modform, Panther_ID, Parent, PIRSF_ID, PMID, PRO_term_definition, PRO_name, PRO_name_synonyms, Reactiome_ID, Relation, Taxon_ID, UniProtKB_ID]
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional]
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Integer**| The number of items to skip before starting to collect the result set. | [optional] [default to 0] [enum: ]
 **limit** | **Integer**| The numbers of items to return. | [optional] [default to 50] [enum: ]

### Return type

[**List&lt;PROTerm&gt;**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getModifiedForms"></a>
# **getModifiedForms**
> List&lt;PROTerm&gt; getModifiedForms(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit)

Returns a list of modified protein forms.

Gets a list of modified protein forms and associated information.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ProteoformTermsApi;


ProteoformTermsApi apiInstance = new ProteoformTermsApi();
String searchField = "searchField_example"; // String | Search field that needs to be considered for filter
String searchValue = "searchValue_example"; // String | any string or \"null\" or \"not null\" or a list of space separated ids
Boolean showPROName = true; // Boolean | 
Boolean showPROTermDefinition = true; // Boolean | 
Boolean showCategory = true; // Boolean | 
Boolean showParent = true; // Boolean | 
Boolean showAnnotation = false; // Boolean | 
Boolean showAnyRelationship = false; // Boolean | 
Boolean showChild = false; // Boolean | 
Boolean showComment = false; // Boolean | 
Boolean showEcoCycID = false; // Boolean | 
Boolean showGeneName = false; // Boolean | 
Boolean showHGNCID = false; // Boolean | 
Boolean showMGIID = false; // Boolean | 
Boolean showOrthoIsoform = false; // Boolean | 
Boolean showOrthoModifiedForm = false; // Boolean | 
Boolean showPANTHERID = false; // Boolean | 
Boolean showPIRSFID = false; // Boolean | 
Boolean showPMID = false; // Boolean | 
Boolean showReactomeID = false; // Boolean | 
Boolean showSynonym = false; // Boolean | 
Boolean showUniProtKBID = false; // Boolean | 
Integer offset = 0; // Integer | The number of items to skip before starting to collect the result set.
Integer limit = 50; // Integer | The numbers of items to return.
try {
    List<PROTerm> result = apiInstance.getModifiedForms(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProteoformTermsApi#getModifiedForms");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] [enum: Any_field, Any_relationship, Category, Child, Comment, EcoCyc_ID, Gene_Name, HGNC_ID, PRO_ID, Interaction_with, MGI_ID, Modifier, Ontology_ID, Ontology_term, Ortho-isoform, Ortho-modform, Panther_ID, Parent, PIRSF_ID, PMID, PRO_term_definition, PRO_name, PRO_name_synonyms, Reactiome_ID, Relation, Taxon_ID, UniProtKB_ID]
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional]
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Integer**| The number of items to skip before starting to collect the result set. | [optional] [default to 0] [enum: ]
 **limit** | **Integer**| The numbers of items to return. | [optional] [default to 50] [enum: ]

### Return type

[**List&lt;PROTerm&gt;**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getOrganismSequenceLevelProteoforms"></a>
# **getOrganismSequenceLevelProteoforms**
> List&lt;PROTerm&gt; getOrganismSequenceLevelProteoforms(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit)

Returns a list of organism-sequence level protein forms.

Gets a list of organism-sequence level protein forms and associated information.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ProteoformTermsApi;


ProteoformTermsApi apiInstance = new ProteoformTermsApi();
String searchField = "searchField_example"; // String | Search field that needs to be considered for filter
String searchValue = "searchValue_example"; // String | any string or \"null\" or \"not null\" or a list of space separated ids
Boolean showPROName = true; // Boolean | 
Boolean showPROTermDefinition = true; // Boolean | 
Boolean showCategory = true; // Boolean | 
Boolean showParent = true; // Boolean | 
Boolean showAnnotation = false; // Boolean | 
Boolean showAnyRelationship = false; // Boolean | 
Boolean showChild = false; // Boolean | 
Boolean showComment = false; // Boolean | 
Boolean showEcoCycID = false; // Boolean | 
Boolean showGeneName = false; // Boolean | 
Boolean showHGNCID = false; // Boolean | 
Boolean showMGIID = false; // Boolean | 
Boolean showOrthoIsoform = false; // Boolean | 
Boolean showOrthoModifiedForm = false; // Boolean | 
Boolean showPANTHERID = false; // Boolean | 
Boolean showPIRSFID = false; // Boolean | 
Boolean showPMID = false; // Boolean | 
Boolean showReactomeID = false; // Boolean | 
Boolean showSynonym = false; // Boolean | 
Boolean showUniProtKBID = false; // Boolean | 
Integer offset = 0; // Integer | The number of items to skip before starting to collect the result set.
Integer limit = 50; // Integer | The numbers of items to return.
try {
    List<PROTerm> result = apiInstance.getOrganismSequenceLevelProteoforms(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProteoformTermsApi#getOrganismSequenceLevelProteoforms");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] [enum: Any_field, Any_relationship, Category, Child, Comment, EcoCyc_ID, Gene_Name, HGNC_ID, PRO_ID, Interaction_with, MGI_ID, Modifier, Ontology_ID, Ontology_term, Ortho-isoform, Ortho-modform, Panther_ID, Parent, PIRSF_ID, PMID, PRO_term_definition, PRO_name, PRO_name_synonyms, Reactiome_ID, Relation, Taxon_ID, UniProtKB_ID]
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional]
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Integer**| The number of items to skip before starting to collect the result set. | [optional] [default to 0] [enum: ]
 **limit** | **Integer**| The numbers of items to return. | [optional] [default to 50] [enum: ]

### Return type

[**List&lt;PROTerm&gt;**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getOrthoIsoForms"></a>
# **getOrthoIsoForms**
> List&lt;PROTerm&gt; getOrthoIsoForms(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit)

Returns a list of ortho-isoform protein forms.

Gets a list of ortho-isoform protien forms and associated information.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ProteoformTermsApi;


ProteoformTermsApi apiInstance = new ProteoformTermsApi();
String searchField = "searchField_example"; // String | Search field that needs to be considered for filter
String searchValue = "searchValue_example"; // String | any string or \"null\" or \"not null\" or a list of space separated ids
Boolean showPROName = true; // Boolean | 
Boolean showPROTermDefinition = true; // Boolean | 
Boolean showCategory = true; // Boolean | 
Boolean showParent = true; // Boolean | 
Boolean showAnnotation = false; // Boolean | 
Boolean showAnyRelationship = false; // Boolean | 
Boolean showChild = false; // Boolean | 
Boolean showComment = false; // Boolean | 
Boolean showEcoCycID = false; // Boolean | 
Boolean showGeneName = false; // Boolean | 
Boolean showHGNCID = false; // Boolean | 
Boolean showMGIID = false; // Boolean | 
Boolean showOrthoIsoform = false; // Boolean | 
Boolean showOrthoModifiedForm = false; // Boolean | 
Boolean showPANTHERID = false; // Boolean | 
Boolean showPIRSFID = false; // Boolean | 
Boolean showPMID = false; // Boolean | 
Boolean showReactomeID = false; // Boolean | 
Boolean showSynonym = false; // Boolean | 
Boolean showUniProtKBID = false; // Boolean | 
Integer offset = 0; // Integer | The number of items to skip before starting to collect the result set.
Integer limit = 50; // Integer | The numbers of items to return.
try {
    List<PROTerm> result = apiInstance.getOrthoIsoForms(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProteoformTermsApi#getOrthoIsoForms");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] [enum: Any_field, Any_relationship, Category, Child, Comment, EcoCyc_ID, Gene_Name, HGNC_ID, PRO_ID, Interaction_with, MGI_ID, Modifier, Ontology_ID, Ontology_term, Ortho-isoform, Ortho-modform, Panther_ID, Parent, PIRSF_ID, PMID, PRO_term_definition, PRO_name, PRO_name_synonyms, Reactiome_ID, Relation, Taxon_ID, UniProtKB_ID]
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional]
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Integer**| The number of items to skip before starting to collect the result set. | [optional] [default to 0] [enum: ]
 **limit** | **Integer**| The numbers of items to return. | [optional] [default to 50] [enum: ]

### Return type

[**List&lt;PROTerm&gt;**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getOrthoModForms"></a>
# **getOrthoModForms**
> List&lt;PROTerm&gt; getOrthoModForms(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit)

Returns a list of ortho-modform protein forms.

Gets a list of ortho-modform protein forms and associated information.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ProteoformTermsApi;


ProteoformTermsApi apiInstance = new ProteoformTermsApi();
String searchField = "searchField_example"; // String | Search field that needs to be considered for filter
String searchValue = "searchValue_example"; // String | any string or \"null\" or \"not null\" or a list of space separated ids
Boolean showPROName = true; // Boolean | 
Boolean showPROTermDefinition = true; // Boolean | 
Boolean showCategory = true; // Boolean | 
Boolean showParent = true; // Boolean | 
Boolean showAnnotation = false; // Boolean | 
Boolean showAnyRelationship = false; // Boolean | 
Boolean showChild = false; // Boolean | 
Boolean showComment = false; // Boolean | 
Boolean showEcoCycID = false; // Boolean | 
Boolean showGeneName = false; // Boolean | 
Boolean showHGNCID = false; // Boolean | 
Boolean showMGIID = false; // Boolean | 
Boolean showOrthoIsoform = false; // Boolean | 
Boolean showOrthoModifiedForm = false; // Boolean | 
Boolean showPANTHERID = false; // Boolean | 
Boolean showPIRSFID = false; // Boolean | 
Boolean showPMID = false; // Boolean | 
Boolean showReactomeID = false; // Boolean | 
Boolean showSynonym = false; // Boolean | 
Boolean showUniProtKBID = false; // Boolean | 
Integer offset = 0; // Integer | The number of items to skip before starting to collect the result set.
Integer limit = 50; // Integer | The numbers of items to return.
try {
    List<PROTerm> result = apiInstance.getOrthoModForms(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProteoformTermsApi#getOrthoModForms");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] [enum: Any_field, Any_relationship, Category, Child, Comment, EcoCyc_ID, Gene_Name, HGNC_ID, PRO_ID, Interaction_with, MGI_ID, Modifier, Ontology_ID, Ontology_term, Ortho-isoform, Ortho-modform, Panther_ID, Parent, PIRSF_ID, PMID, PRO_term_definition, PRO_name, PRO_name_synonyms, Reactiome_ID, Relation, Taxon_ID, UniProtKB_ID]
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional]
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Integer**| The number of items to skip before starting to collect the result set. | [optional] [default to 0] [enum: ]
 **limit** | **Integer**| The numbers of items to return. | [optional] [default to 50] [enum: ]

### Return type

[**List&lt;PROTerm&gt;**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getPhosphorylatedForms"></a>
# **getPhosphorylatedForms**
> List&lt;PROTerm&gt; getPhosphorylatedForms(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit)

Returns a list of phosphorylated protein forms.

Gets a list of phosphorylated protein forms and associated information.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ProteoformTermsApi;


ProteoformTermsApi apiInstance = new ProteoformTermsApi();
String searchField = "searchField_example"; // String | Search field that needs to be considered for filter
String searchValue = "searchValue_example"; // String | any string or \"null\" or \"not null\" or a list of space separated ids
Boolean showPROName = true; // Boolean | 
Boolean showPROTermDefinition = true; // Boolean | 
Boolean showCategory = true; // Boolean | 
Boolean showParent = true; // Boolean | 
Boolean showAnnotation = false; // Boolean | 
Boolean showAnyRelationship = false; // Boolean | 
Boolean showChild = false; // Boolean | 
Boolean showComment = false; // Boolean | 
Boolean showEcoCycID = false; // Boolean | 
Boolean showGeneName = false; // Boolean | 
Boolean showHGNCID = false; // Boolean | 
Boolean showMGIID = false; // Boolean | 
Boolean showOrthoIsoform = false; // Boolean | 
Boolean showOrthoModifiedForm = false; // Boolean | 
Boolean showPANTHERID = false; // Boolean | 
Boolean showPIRSFID = false; // Boolean | 
Boolean showPMID = false; // Boolean | 
Boolean showReactomeID = false; // Boolean | 
Boolean showSynonym = false; // Boolean | 
Boolean showUniProtKBID = false; // Boolean | 
Integer offset = 0; // Integer | The number of items to skip before starting to collect the result set.
Integer limit = 50; // Integer | The numbers of items to return.
try {
    List<PROTerm> result = apiInstance.getPhosphorylatedForms(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProteoformTermsApi#getPhosphorylatedForms");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] [enum: Any_field, Any_relationship, Category, Child, Comment, EcoCyc_ID, Gene_Name, HGNC_ID, PRO_ID, Interaction_with, MGI_ID, Modifier, Ontology_ID, Ontology_term, Ortho-isoform, Ortho-modform, Panther_ID, Parent, PIRSF_ID, PMID, PRO_term_definition, PRO_name, PRO_name_synonyms, Reactiome_ID, Relation, Taxon_ID, UniProtKB_ID]
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional]
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Integer**| The number of items to skip before starting to collect the result set. | [optional] [default to 0] [enum: ]
 **limit** | **Integer**| The numbers of items to return. | [optional] [default to 50] [enum: ]

### Return type

[**List&lt;PROTerm&gt;**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getSequenceLevelProteoforms"></a>
# **getSequenceLevelProteoforms**
> List&lt;PROTerm&gt; getSequenceLevelProteoforms(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit)

Returns a list of sequence level protein forms.

Gets a list of sequence level protein forms and associated information.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ProteoformTermsApi;


ProteoformTermsApi apiInstance = new ProteoformTermsApi();
String searchField = "searchField_example"; // String | Search field that needs to be considered for filter
String searchValue = "searchValue_example"; // String | any string or \"null\" or \"not null\" or a list of space separated ids
Boolean showPROName = true; // Boolean | 
Boolean showPROTermDefinition = true; // Boolean | 
Boolean showCategory = true; // Boolean | 
Boolean showParent = true; // Boolean | 
Boolean showAnnotation = false; // Boolean | 
Boolean showAnyRelationship = false; // Boolean | 
Boolean showChild = false; // Boolean | 
Boolean showComment = false; // Boolean | 
Boolean showEcoCycID = false; // Boolean | 
Boolean showGeneName = false; // Boolean | 
Boolean showHGNCID = false; // Boolean | 
Boolean showMGIID = false; // Boolean | 
Boolean showOrthoIsoform = false; // Boolean | 
Boolean showOrthoModifiedForm = false; // Boolean | 
Boolean showPANTHERID = false; // Boolean | 
Boolean showPIRSFID = false; // Boolean | 
Boolean showPMID = false; // Boolean | 
Boolean showReactomeID = false; // Boolean | 
Boolean showSynonym = false; // Boolean | 
Boolean showUniProtKBID = false; // Boolean | 
Integer offset = 0; // Integer | The number of items to skip before starting to collect the result set.
Integer limit = 50; // Integer | The numbers of items to return.
try {
    List<PROTerm> result = apiInstance.getSequenceLevelProteoforms(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProteoformTermsApi#getSequenceLevelProteoforms");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] [enum: Any_field, Any_relationship, Category, Child, Comment, EcoCyc_ID, Gene_Name, HGNC_ID, PRO_ID, Interaction_with, MGI_ID, Modifier, Ontology_ID, Ontology_term, Ortho-isoform, Ortho-modform, Panther_ID, Parent, PIRSF_ID, PMID, PRO_term_definition, PRO_name, PRO_name_synonyms, Reactiome_ID, Relation, Taxon_ID, UniProtKB_ID]
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional]
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Integer**| The number of items to skip before starting to collect the result set. | [optional] [default to 0] [enum: ]
 **limit** | **Integer**| The numbers of items to return. | [optional] [default to 50] [enum: ]

### Return type

[**List&lt;PROTerm&gt;**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getUbiquitinatedForms"></a>
# **getUbiquitinatedForms**
> List&lt;PROTerm&gt; getUbiquitinatedForms(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit)

Returns a list of ubiquitinated protein forms.

Gets a list of ubiquitinated protein forms and associated information.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ProteoformTermsApi;


ProteoformTermsApi apiInstance = new ProteoformTermsApi();
String searchField = "searchField_example"; // String | Search field that needs to be considered for filter
String searchValue = "searchValue_example"; // String | any string or \"null\" or \"not null\" or a list of space separated ids
Boolean showPROName = true; // Boolean | 
Boolean showPROTermDefinition = true; // Boolean | 
Boolean showCategory = true; // Boolean | 
Boolean showParent = true; // Boolean | 
Boolean showAnnotation = false; // Boolean | 
Boolean showAnyRelationship = false; // Boolean | 
Boolean showChild = false; // Boolean | 
Boolean showComment = false; // Boolean | 
Boolean showEcoCycID = false; // Boolean | 
Boolean showGeneName = false; // Boolean | 
Boolean showHGNCID = false; // Boolean | 
Boolean showMGIID = false; // Boolean | 
Boolean showOrthoIsoform = false; // Boolean | 
Boolean showOrthoModifiedForm = false; // Boolean | 
Boolean showPANTHERID = false; // Boolean | 
Boolean showPIRSFID = false; // Boolean | 
Boolean showPMID = false; // Boolean | 
Boolean showReactomeID = false; // Boolean | 
Boolean showSynonym = false; // Boolean | 
Boolean showUniProtKBID = false; // Boolean | 
Integer offset = 0; // Integer | The number of items to skip before starting to collect the result set.
Integer limit = 50; // Integer | The numbers of items to return.
try {
    List<PROTerm> result = apiInstance.getUbiquitinatedForms(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProteoformTermsApi#getUbiquitinatedForms");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] [enum: Any_field, Any_relationship, Category, Child, Comment, EcoCyc_ID, Gene_Name, HGNC_ID, PRO_ID, Interaction_with, MGI_ID, Modifier, Ontology_ID, Ontology_term, Ortho-isoform, Ortho-modform, Panther_ID, Parent, PIRSF_ID, PMID, PRO_term_definition, PRO_name, PRO_name_synonyms, Reactiome_ID, Relation, Taxon_ID, UniProtKB_ID]
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional]
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Integer**| The number of items to skip before starting to collect the result set. | [optional] [default to 0] [enum: ]
 **limit** | **Integer**| The numbers of items to return. | [optional] [default to 50] [enum: ]

### Return type

[**List&lt;PROTerm&gt;**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

