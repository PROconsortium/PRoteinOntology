# PROTerm

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | The PRO ID. |  [optional]
**name** | **String** | The PRO name. |  [optional]
**termDef** | **String** | The PRO term definition. |  [optional]
**category** | **String** | The PRO term category. |  [optional]
**annotation** | [**List&lt;Annotation&gt;**](Annotation.md) |  |  [optional]
**anyRelationship** | **String** |  |  [optional]
**child** | **List&lt;String&gt;** |  |  [optional]
**ecoCycID** | **String** |  |  [optional]
**geneName** | **String** |  |  [optional]
**hgncID** | **List&lt;String&gt;** |  |  [optional]
**mgiID** | **List&lt;String&gt;** |  |  [optional]
**orthoIsoform** | **List&lt;String&gt;** |  |  [optional]
**orthoModifiedForm** | **List&lt;String&gt;** |  |  [optional]
**pantherID** | **String** |  |  [optional]
**paraent** | **List&lt;String&gt;** |  |  [optional]
**pirsfID** | **String** |  |  [optional]
**pmID** | **String** |  |  [optional]
**synonym** | **List&lt;String&gt;** |  |  [optional]
**reactomeID** | **List&lt;String&gt;** |  |  [optional]
**uniprotKBID** | **List&lt;String&gt;** |  |  [optional]
