# ProteinEvolutionaryTermsApi

All URIs are relative to *https://research.bioinformatics.udel.edu/PRO_API/V1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getFamilyLevelEvolutionaryTerms**](ProteinEvolutionaryTermsApi.md#getFamilyLevelEvolutionaryTerms) | **GET** /proevos/family | Returns a list of family level protein terms.
[**getGeneLevelEvolutionaryTerms**](ProteinEvolutionaryTermsApi.md#getGeneLevelEvolutionaryTerms) | **GET** /proevos/gene | Returns a list of gene level protein terms.
[**getOrganismGeneLevelEvolutionaryTerms**](ProteinEvolutionaryTermsApi.md#getOrganismGeneLevelEvolutionaryTerms) | **GET** /proevos/organism-gene | Returns a list of organism-gene level protein terms.

<a name="getFamilyLevelEvolutionaryTerms"></a>
# **getFamilyLevelEvolutionaryTerms**
> List&lt;PROTerm&gt; getFamilyLevelEvolutionaryTerms(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit)

Returns a list of family level protein terms.

Gets a list of family level protein terms and associated information.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ProteinEvolutionaryTermsApi;


ProteinEvolutionaryTermsApi apiInstance = new ProteinEvolutionaryTermsApi();
String searchField = "searchField_example"; // String | Search field that needs to be considered for filter
String searchValue = "searchValue_example"; // String | any string or \"null\" or \"not null\" or a list of space separated ids
Boolean showPROName = true; // Boolean | 
Boolean showPROTermDefinition = true; // Boolean | 
Boolean showCategory = true; // Boolean | 
Boolean showParent = true; // Boolean | 
Boolean showAnnotation = false; // Boolean | 
Boolean showAnyRelationship = false; // Boolean | 
Boolean showChild = false; // Boolean | 
Boolean showComment = false; // Boolean | 
Boolean showEcoCycID = false; // Boolean | 
Boolean showGeneName = false; // Boolean | 
Boolean showHGNCID = false; // Boolean | 
Boolean showMGIID = false; // Boolean | 
Boolean showOrthoIsoform = false; // Boolean | 
Boolean showOrthoModifiedForm = false; // Boolean | 
Boolean showPANTHERID = false; // Boolean | 
Boolean showPIRSFID = false; // Boolean | 
Boolean showPMID = false; // Boolean | 
Boolean showReactomeID = false; // Boolean | 
Boolean showSynonym = false; // Boolean | 
Boolean showUniProtKBID = false; // Boolean | 
Integer offset = 0; // Integer | The number of items to skip before starting to collect the result set.
Integer limit = 50; // Integer | The numbers of items to return.
try {
    List<PROTerm> result = apiInstance.getFamilyLevelEvolutionaryTerms(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProteinEvolutionaryTermsApi#getFamilyLevelEvolutionaryTerms");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] [enum: Any_field, Any_relationship, Category, Child, Comment, EcoCyc_ID, Gene_Name, HGNC_ID, PRO_ID, Interaction_with, MGI_ID, Modifier, Ontology_ID, Ontology_term, Ortho-isoform, Ortho-modform, Panther_ID, Parent, PIRSF_ID, PMID, PRO_term_definition, PRO_name, PRO_name_synonyms, Reactiome_ID, Relation, Taxon_ID, UniProtKB_ID]
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional]
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Integer**| The number of items to skip before starting to collect the result set. | [optional] [default to 0] [enum: ]
 **limit** | **Integer**| The numbers of items to return. | [optional] [default to 50] [enum: ]

### Return type

[**List&lt;PROTerm&gt;**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getGeneLevelEvolutionaryTerms"></a>
# **getGeneLevelEvolutionaryTerms**
> List&lt;PROTerm&gt; getGeneLevelEvolutionaryTerms(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit)

Returns a list of gene level protein terms.

Gets a list of gene level protein terms and associated information.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ProteinEvolutionaryTermsApi;


ProteinEvolutionaryTermsApi apiInstance = new ProteinEvolutionaryTermsApi();
String searchField = "searchField_example"; // String | Search field that needs to be considered for filter
String searchValue = "searchValue_example"; // String | any string or \"null\" or \"not null\" or a list of space separated ids
Boolean showPROName = true; // Boolean | 
Boolean showPROTermDefinition = true; // Boolean | 
Boolean showCategory = true; // Boolean | 
Boolean showParent = true; // Boolean | 
Boolean showAnnotation = false; // Boolean | 
Boolean showAnyRelationship = false; // Boolean | 
Boolean showChild = false; // Boolean | 
Boolean showComment = false; // Boolean | 
Boolean showEcoCycID = false; // Boolean | 
Boolean showGeneName = false; // Boolean | 
Boolean showHGNCID = false; // Boolean | 
Boolean showMGIID = false; // Boolean | 
Boolean showOrthoIsoform = false; // Boolean | 
Boolean showOrthoModifiedForm = false; // Boolean | 
Boolean showPANTHERID = false; // Boolean | 
Boolean showPIRSFID = false; // Boolean | 
Boolean showPMID = false; // Boolean | 
Boolean showReactomeID = false; // Boolean | 
Boolean showSynonym = false; // Boolean | 
Boolean showUniProtKBID = false; // Boolean | 
Integer offset = 0; // Integer | The number of items to skip before starting to collect the result set.
Integer limit = 50; // Integer | The numbers of items to return.
try {
    List<PROTerm> result = apiInstance.getGeneLevelEvolutionaryTerms(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProteinEvolutionaryTermsApi#getGeneLevelEvolutionaryTerms");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] [enum: Any_field, Any_relationship, Category, Child, Comment, EcoCyc_ID, Gene_Name, HGNC_ID, PRO_ID, Interaction_with, MGI_ID, Modifier, Ontology_ID, Ontology_term, Ortho-isoform, Ortho-modform, Panther_ID, Parent, PIRSF_ID, PMID, PRO_term_definition, PRO_name, PRO_name_synonyms, Reactiome_ID, Relation, Taxon_ID, UniProtKB_ID]
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional]
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Integer**| The number of items to skip before starting to collect the result set. | [optional] [default to 0] [enum: ]
 **limit** | **Integer**| The numbers of items to return. | [optional] [default to 50] [enum: ]

### Return type

[**List&lt;PROTerm&gt;**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getOrganismGeneLevelEvolutionaryTerms"></a>
# **getOrganismGeneLevelEvolutionaryTerms**
> List&lt;PROTerm&gt; getOrganismGeneLevelEvolutionaryTerms(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit)

Returns a list of organism-gene level protein terms.

Gets a list of organism-gene level protein terms and associated information.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ProteinEvolutionaryTermsApi;


ProteinEvolutionaryTermsApi apiInstance = new ProteinEvolutionaryTermsApi();
String searchField = "searchField_example"; // String | Search field that needs to be considered for filter
String searchValue = "searchValue_example"; // String | any string or \"null\" or \"not null\" or a list of space separated ids
Boolean showPROName = true; // Boolean | 
Boolean showPROTermDefinition = true; // Boolean | 
Boolean showCategory = true; // Boolean | 
Boolean showParent = true; // Boolean | 
Boolean showAnnotation = false; // Boolean | 
Boolean showAnyRelationship = false; // Boolean | 
Boolean showChild = false; // Boolean | 
Boolean showComment = false; // Boolean | 
Boolean showEcoCycID = false; // Boolean | 
Boolean showGeneName = false; // Boolean | 
Boolean showHGNCID = false; // Boolean | 
Boolean showMGIID = false; // Boolean | 
Boolean showOrthoIsoform = false; // Boolean | 
Boolean showOrthoModifiedForm = false; // Boolean | 
Boolean showPANTHERID = false; // Boolean | 
Boolean showPIRSFID = false; // Boolean | 
Boolean showPMID = false; // Boolean | 
Boolean showReactomeID = false; // Boolean | 
Boolean showSynonym = false; // Boolean | 
Boolean showUniProtKBID = false; // Boolean | 
Integer offset = 0; // Integer | The number of items to skip before starting to collect the result set.
Integer limit = 50; // Integer | The numbers of items to return.
try {
    List<PROTerm> result = apiInstance.getOrganismGeneLevelEvolutionaryTerms(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProteinEvolutionaryTermsApi#getOrganismGeneLevelEvolutionaryTerms");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] [enum: Any_field, Any_relationship, Category, Child, Comment, EcoCyc_ID, Gene_Name, HGNC_ID, PRO_ID, Interaction_with, MGI_ID, Modifier, Ontology_ID, Ontology_term, Ortho-isoform, Ortho-modform, Panther_ID, Parent, PIRSF_ID, PMID, PRO_term_definition, PRO_name, PRO_name_synonyms, Reactiome_ID, Relation, Taxon_ID, UniProtKB_ID]
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional]
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Integer**| The number of items to skip before starting to collect the result set. | [optional] [default to 0] [enum: ]
 **limit** | **Integer**| The numbers of items to return. | [optional] [default to 50] [enum: ]

### Return type

[**List&lt;PROTerm&gt;**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

