# DatabaseCrossReferencesApi

All URIs are relative to *https://research.bioinformatics.udel.edu/PRO_API/V1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getPROTermsWithEcoCyCId**](DatabaseCrossReferencesApi.md#getPROTermsWithEcoCyCId) | **GET** /dbxrefs/EcoCyc_ID | Returns a list of PRO terms with EcoCyC ID as cross-reference.
[**getPROTermsWithHGNCId**](DatabaseCrossReferencesApi.md#getPROTermsWithHGNCId) | **GET** /dbxrefs/HGNC_ID | Returns a list of PRO terms with HGNC ID as cross-reference.
[**getPROTermsWithMGIId**](DatabaseCrossReferencesApi.md#getPROTermsWithMGIId) | **GET** /dbxrefs/MGI_ID | Returns a list of PRO terms with MGI ID as cross-reference.
[**getPROTermsWithNCBITaxonID**](DatabaseCrossReferencesApi.md#getPROTermsWithNCBITaxonID) | **GET** /dbxrefs/NCBITaxon_ID | Returns a list of PRO terms with NCBI Taxon ID as cross-reference.
[**getPROTermsWithOntologyId**](DatabaseCrossReferencesApi.md#getPROTermsWithOntologyId) | **GET** /dbxrefs/Ontology_ID | Returns a list of PRO terms with Ontology ID as cross-reference.
[**getPROTermsWithPANTHERId**](DatabaseCrossReferencesApi.md#getPROTermsWithPANTHERId) | **GET** /dbxrefs/PANTHER_ID | Returns a list of PRO terms with PANTHER ID as cross-reference.
[**getPROTermsWithPIRSFId**](DatabaseCrossReferencesApi.md#getPROTermsWithPIRSFId) | **GET** /dbxrefs/PIRSF_ID | Returns a list of PRO terms with PIRSF ID as cross-reference.
[**getPROTermsWithPMID**](DatabaseCrossReferencesApi.md#getPROTermsWithPMID) | **GET** /dbxrefs/PMID | Returns a list of PRO terms with PMID as cross-reference.
[**getPROTermsWithReactomeID**](DatabaseCrossReferencesApi.md#getPROTermsWithReactomeID) | **GET** /dbxrefs/Reactome_ID | Returns a list of PRO terms with Reactome ID as cross-reference.
[**getPROTermsWithUniProtKBID**](DatabaseCrossReferencesApi.md#getPROTermsWithUniProtKBID) | **GET** /dbxrefs/UniProtKB_ID | Returns a list of PRO terms with UniProtKB ID as cross-reference.

<a name="getPROTermsWithEcoCyCId"></a>
# **getPROTermsWithEcoCyCId**
> List&lt;PROTerm&gt; getPROTermsWithEcoCyCId(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showEcoCycID, showAnnotation, showAnyRelationship, showChild, showComment, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit)

Returns a list of PRO terms with EcoCyC ID as cross-reference.

Gets a list of PRO terms with EcoCyC ID as cross-reference and associated information.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DatabaseCrossReferencesApi;


DatabaseCrossReferencesApi apiInstance = new DatabaseCrossReferencesApi();
String searchField = "searchField_example"; // String | Search field that needs to be considered for filter
String searchValue = "searchValue_example"; // String | any string or \"null\" or \"not null\" or a list of space separated ids
Boolean showPROName = true; // Boolean | 
Boolean showPROTermDefinition = true; // Boolean | 
Boolean showCategory = true; // Boolean | 
Boolean showEcoCycID = true; // Boolean | 
Boolean showAnnotation = false; // Boolean | 
Boolean showAnyRelationship = false; // Boolean | 
Boolean showChild = false; // Boolean | 
Boolean showComment = false; // Boolean | 
Boolean showGeneName = false; // Boolean | 
Boolean showHGNCID = false; // Boolean | 
Boolean showMGIID = false; // Boolean | 
Boolean showOrthoIsoform = false; // Boolean | 
Boolean showOrthoModifiedForm = false; // Boolean | 
Boolean showPANTHERID = false; // Boolean | 
Boolean showPIRSFID = false; // Boolean | 
Boolean showPMID = false; // Boolean | 
Boolean showReactomeID = false; // Boolean | 
Boolean showSynonym = false; // Boolean | 
Boolean showUniProtKBID = false; // Boolean | 
Integer offset = 0; // Integer | The number of items to skip before starting to collect the result set.
Integer limit = 50; // Integer | The numbers of items to return.
try {
    List<PROTerm> result = apiInstance.getPROTermsWithEcoCyCId(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showEcoCycID, showAnnotation, showAnyRelationship, showChild, showComment, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DatabaseCrossReferencesApi#getPROTermsWithEcoCyCId");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] [enum: Any_field, Any_relationship, Category, Child, Comment, EcoCyc_ID, Gene_Name, HGNC_ID, PRO_ID, Interaction_with, MGI_ID, Modifier, Ontology_ID, Ontology_term, Ortho-isoform, Ortho-modform, Panther_ID, Parent, PIRSF_ID, PMID, PRO_term_definition, PRO_name, PRO_name_synonyms, Reactiome_ID, Relation, Taxon_ID, UniProtKB_ID]
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional]
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showEcoCycID** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Integer**| The number of items to skip before starting to collect the result set. | [optional] [default to 0] [enum: ]
 **limit** | **Integer**| The numbers of items to return. | [optional] [default to 50] [enum: ]

### Return type

[**List&lt;PROTerm&gt;**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getPROTermsWithHGNCId"></a>
# **getPROTermsWithHGNCId**
> List&lt;PROTerm&gt; getPROTermsWithHGNCId(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showHGNCID, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit)

Returns a list of PRO terms with HGNC ID as cross-reference.

Gets a list of PRO terms with HGNC ID as cross-reference and associated information.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DatabaseCrossReferencesApi;


DatabaseCrossReferencesApi apiInstance = new DatabaseCrossReferencesApi();
String searchField = "searchField_example"; // String | Search field that needs to be considered for filter
String searchValue = "searchValue_example"; // String | any string or \"null\" or \"not null\" or a list of space separated ids
Boolean showPROName = true; // Boolean | 
Boolean showPROTermDefinition = true; // Boolean | 
Boolean showCategory = true; // Boolean | 
Boolean showParent = true; // Boolean | 
Boolean showHGNCID = true; // Boolean | 
Boolean showAnnotation = false; // Boolean | 
Boolean showAnyRelationship = false; // Boolean | 
Boolean showChild = false; // Boolean | 
Boolean showComment = false; // Boolean | 
Boolean showEcoCycID = false; // Boolean | 
Boolean showGeneName = false; // Boolean | 
Boolean showMGIID = false; // Boolean | 
Boolean showOrthoIsoform = false; // Boolean | 
Boolean showOrthoModifiedForm = false; // Boolean | 
Boolean showPANTHERID = false; // Boolean | 
Boolean showPIRSFID = false; // Boolean | 
Boolean showPMID = false; // Boolean | 
Boolean showReactomeID = false; // Boolean | 
Boolean showSynonym = false; // Boolean | 
Boolean showUniProtKBID = false; // Boolean | 
Integer offset = 0; // Integer | The number of items to skip before starting to collect the result set.
Integer limit = 50; // Integer | The numbers of items to return.
try {
    List<PROTerm> result = apiInstance.getPROTermsWithHGNCId(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showHGNCID, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DatabaseCrossReferencesApi#getPROTermsWithHGNCId");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] [enum: Any_field, Any_relationship, Category, Child, Comment, EcoCyc_ID, Gene_Name, HGNC_ID, PRO_ID, Interaction_with, MGI_ID, Modifier, Ontology_ID, Ontology_term, Ortho-isoform, Ortho-modform, Panther_ID, Parent, PIRSF_ID, PMID, PRO_term_definition, PRO_name, PRO_name_synonyms, Reactiome_ID, Relation, Taxon_ID, UniProtKB_ID]
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional]
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showHGNCID** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Integer**| The number of items to skip before starting to collect the result set. | [optional] [default to 0] [enum: ]
 **limit** | **Integer**| The numbers of items to return. | [optional] [default to 50] [enum: ]

### Return type

[**List&lt;PROTerm&gt;**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getPROTermsWithMGIId"></a>
# **getPROTermsWithMGIId**
> List&lt;PROTerm&gt; getPROTermsWithMGIId(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showMGIID, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit)

Returns a list of PRO terms with MGI ID as cross-reference.

Gets a list of PRO terms with MGI ID as cross-reference and associated information.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DatabaseCrossReferencesApi;


DatabaseCrossReferencesApi apiInstance = new DatabaseCrossReferencesApi();
String searchField = "searchField_example"; // String | Search field that needs to be considered for filter
String searchValue = "searchValue_example"; // String | any string or \"null\" or \"not null\" or a list of space separated ids
Boolean showPROName = true; // Boolean | 
Boolean showPROTermDefinition = true; // Boolean | 
Boolean showCategory = true; // Boolean | 
Boolean showParent = true; // Boolean | 
Boolean showMGIID = true; // Boolean | 
Boolean showAnnotation = false; // Boolean | 
Boolean showAnyRelationship = false; // Boolean | 
Boolean showChild = false; // Boolean | 
Boolean showComment = false; // Boolean | 
Boolean showEcoCycID = false; // Boolean | 
Boolean showGeneName = false; // Boolean | 
Boolean showHGNCID = false; // Boolean | 
Boolean showOrthoIsoform = false; // Boolean | 
Boolean showOrthoModifiedForm = false; // Boolean | 
Boolean showPANTHERID = false; // Boolean | 
Boolean showPIRSFID = false; // Boolean | 
Boolean showPMID = false; // Boolean | 
Boolean showReactomeID = false; // Boolean | 
Boolean showSynonym = false; // Boolean | 
Boolean showUniProtKBID = false; // Boolean | 
Integer offset = 0; // Integer | The number of items to skip before starting to collect the result set.
Integer limit = 50; // Integer | The numbers of items to return.
try {
    List<PROTerm> result = apiInstance.getPROTermsWithMGIId(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showMGIID, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DatabaseCrossReferencesApi#getPROTermsWithMGIId");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] [enum: Any_field, Any_relationship, Category, Child, Comment, EcoCyc_ID, Gene_Name, HGNC_ID, PRO_ID, Interaction_with, MGI_ID, Modifier, Ontology_ID, Ontology_term, Ortho-isoform, Ortho-modform, Panther_ID, Parent, PIRSF_ID, PMID, PRO_term_definition, PRO_name, PRO_name_synonyms, Reactiome_ID, Relation, Taxon_ID, UniProtKB_ID]
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional]
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showMGIID** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Integer**| The number of items to skip before starting to collect the result set. | [optional] [default to 0] [enum: ]
 **limit** | **Integer**| The numbers of items to return. | [optional] [default to 50] [enum: ]

### Return type

[**List&lt;PROTerm&gt;**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getPROTermsWithNCBITaxonID"></a>
# **getPROTermsWithNCBITaxonID**
> List&lt;PROTerm&gt; getPROTermsWithNCBITaxonID(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showUniProtKBID, offset, limit)

Returns a list of PRO terms with NCBI Taxon ID as cross-reference.

Gets a list of PRO terms with NCBI Taxon ID as cross-reference and associated information.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DatabaseCrossReferencesApi;


DatabaseCrossReferencesApi apiInstance = new DatabaseCrossReferencesApi();
String searchField = "searchField_example"; // String | Search field that needs to be considered for filter
String searchValue = "searchValue_example"; // String | any string or \"null\" or \"not null\" or a list of space separated ids
Boolean showPROName = true; // Boolean | 
Boolean showPROTermDefinition = true; // Boolean | 
Boolean showCategory = true; // Boolean | 
Boolean showParent = true; // Boolean | 
Boolean showAnnotation = true; // Boolean | 
Boolean showAnyRelationship = false; // Boolean | 
Boolean showChild = false; // Boolean | 
Boolean showComment = false; // Boolean | 
Boolean showEcoCycID = false; // Boolean | 
Boolean showGeneName = false; // Boolean | 
Boolean showHGNCID = false; // Boolean | 
Boolean showMGIID = false; // Boolean | 
Boolean showOrthoIsoform = false; // Boolean | 
Boolean showOrthoModifiedForm = false; // Boolean | 
Boolean showPANTHERID = false; // Boolean | 
Boolean showPIRSFID = false; // Boolean | 
Boolean showPMID = false; // Boolean | 
Boolean showReactomeID = false; // Boolean | 
Boolean showUniProtKBID = false; // Boolean | 
Integer offset = 0; // Integer | The number of items to skip before starting to collect the result set.
Integer limit = 50; // Integer | The numbers of items to return.
try {
    List<PROTerm> result = apiInstance.getPROTermsWithNCBITaxonID(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showUniProtKBID, offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DatabaseCrossReferencesApi#getPROTermsWithNCBITaxonID");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] [enum: Any_field, Any_relationship, Category, Child, Comment, EcoCyc_ID, Gene_Name, HGNC_ID, PRO_ID, Interaction_with, MGI_ID, Modifier, Ontology_ID, Ontology_term, Ortho-isoform, Ortho-modform, Panther_ID, Parent, PIRSF_ID, PMID, PRO_term_definition, PRO_name, PRO_name_synonyms, Reactiome_ID, Relation, Taxon_ID, UniProtKB_ID]
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional]
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to true]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Integer**| The number of items to skip before starting to collect the result set. | [optional] [default to 0] [enum: ]
 **limit** | **Integer**| The numbers of items to return. | [optional] [default to 50] [enum: ]

### Return type

[**List&lt;PROTerm&gt;**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getPROTermsWithOntologyId"></a>
# **getPROTermsWithOntologyId**
> List&lt;PROTerm&gt; getPROTermsWithOntologyId(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit)

Returns a list of PRO terms with Ontology ID as cross-reference.

Gets a list of PRO terms with Ontology ID as cross-reference and associated information.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DatabaseCrossReferencesApi;


DatabaseCrossReferencesApi apiInstance = new DatabaseCrossReferencesApi();
String searchField = "searchField_example"; // String | Search field that needs to be considered for filter
String searchValue = "searchValue_example"; // String | any string or \"null\" or \"not null\" or a list of space separated ids
Boolean showPROName = true; // Boolean | 
Boolean showPROTermDefinition = true; // Boolean | 
Boolean showCategory = true; // Boolean | 
Boolean showParent = true; // Boolean | 
Boolean showAnnotation = true; // Boolean | 
Boolean showAnyRelationship = false; // Boolean | 
Boolean showChild = false; // Boolean | 
Boolean showComment = false; // Boolean | 
Boolean showEcoCycID = false; // Boolean | 
Boolean showGeneName = false; // Boolean | 
Boolean showHGNCID = false; // Boolean | 
Boolean showMGIID = false; // Boolean | 
Boolean showOrthoIsoform = false; // Boolean | 
Boolean showOrthoModifiedForm = false; // Boolean | 
Boolean showPANTHERID = false; // Boolean | 
Boolean showPIRSFID = false; // Boolean | 
Boolean showPMID = false; // Boolean | 
Boolean showReactomeID = false; // Boolean | 
Boolean showSynonym = false; // Boolean | 
Boolean showUniProtKBID = false; // Boolean | 
Integer offset = 0; // Integer | The number of items to skip before starting to collect the result set.
Integer limit = 50; // Integer | The numbers of items to return.
try {
    List<PROTerm> result = apiInstance.getPROTermsWithOntologyId(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DatabaseCrossReferencesApi#getPROTermsWithOntologyId");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] [enum: Any_field, Any_relationship, Category, Child, Comment, EcoCyc_ID, Gene_Name, HGNC_ID, PRO_ID, Interaction_with, MGI_ID, Modifier, Ontology_ID, Ontology_term, Ortho-isoform, Ortho-modform, Panther_ID, Parent, PIRSF_ID, PMID, PRO_term_definition, PRO_name, PRO_name_synonyms, Reactiome_ID, Relation, Taxon_ID, UniProtKB_ID]
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional]
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to true]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Integer**| The number of items to skip before starting to collect the result set. | [optional] [default to 0] [enum: ]
 **limit** | **Integer**| The numbers of items to return. | [optional] [default to 50] [enum: ]

### Return type

[**List&lt;PROTerm&gt;**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getPROTermsWithPANTHERId"></a>
# **getPROTermsWithPANTHERId**
> List&lt;PROTerm&gt; getPROTermsWithPANTHERId(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showPANTHERID, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit)

Returns a list of PRO terms with PANTHER ID as cross-reference.

Gets a list of PRO terms with PANTHER ID as cross-reference and associated information.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DatabaseCrossReferencesApi;


DatabaseCrossReferencesApi apiInstance = new DatabaseCrossReferencesApi();
String searchField = "searchField_example"; // String | Search field that needs to be considered for filter
String searchValue = "searchValue_example"; // String | any string or \"null\" or \"not null\" or a list of space separated ids
Boolean showPROName = true; // Boolean | 
Boolean showPROTermDefinition = true; // Boolean | 
Boolean showCategory = true; // Boolean | 
Boolean showParent = true; // Boolean | 
Boolean showPANTHERID = true; // Boolean | 
Boolean showAnnotation = false; // Boolean | 
Boolean showAnyRelationship = false; // Boolean | 
Boolean showChild = false; // Boolean | 
Boolean showComment = false; // Boolean | 
Boolean showEcoCycID = false; // Boolean | 
Boolean showGeneName = false; // Boolean | 
Boolean showHGNCID = false; // Boolean | 
Boolean showMGIID = false; // Boolean | 
Boolean showOrthoIsoform = false; // Boolean | 
Boolean showOrthoModifiedForm = false; // Boolean | 
Boolean showPIRSFID = false; // Boolean | 
Boolean showPMID = false; // Boolean | 
Boolean showReactomeID = false; // Boolean | 
Boolean showSynonym = false; // Boolean | 
Boolean showUniProtKBID = false; // Boolean | 
Integer offset = 0; // Integer | The number of items to skip before starting to collect the result set.
Integer limit = 50; // Integer | The numbers of items to return.
try {
    List<PROTerm> result = apiInstance.getPROTermsWithPANTHERId(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showPANTHERID, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPIRSFID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DatabaseCrossReferencesApi#getPROTermsWithPANTHERId");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] [enum: Any_field, Any_relationship, Category, Child, Comment, EcoCyc_ID, Gene_Name, HGNC_ID, PRO_ID, Interaction_with, MGI_ID, Modifier, Ontology_ID, Ontology_term, Ortho-isoform, Ortho-modform, Panther_ID, Parent, PIRSF_ID, PMID, PRO_term_definition, PRO_name, PRO_name_synonyms, Reactiome_ID, Relation, Taxon_ID, UniProtKB_ID]
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional]
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showPANTHERID** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Integer**| The number of items to skip before starting to collect the result set. | [optional] [default to 0] [enum: ]
 **limit** | **Integer**| The numbers of items to return. | [optional] [default to 50] [enum: ]

### Return type

[**List&lt;PROTerm&gt;**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getPROTermsWithPIRSFId"></a>
# **getPROTermsWithPIRSFId**
> List&lt;PROTerm&gt; getPROTermsWithPIRSFId(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showPIRSFID, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit)

Returns a list of PRO terms with PIRSF ID as cross-reference.

Gets a list of PRO terms with PIRSF ID as cross-reference and associated information.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DatabaseCrossReferencesApi;


DatabaseCrossReferencesApi apiInstance = new DatabaseCrossReferencesApi();
String searchField = "searchField_example"; // String | Search field that needs to be considered for filter
String searchValue = "searchValue_example"; // String | any string or \"null\" or \"not null\" or a list of space separated ids
Boolean showPROName = true; // Boolean | 
Boolean showPROTermDefinition = true; // Boolean | 
Boolean showCategory = true; // Boolean | 
Boolean showParent = true; // Boolean | 
Boolean showPIRSFID = true; // Boolean | 
Boolean showAnnotation = false; // Boolean | 
Boolean showAnyRelationship = false; // Boolean | 
Boolean showChild = false; // Boolean | 
Boolean showComment = false; // Boolean | 
Boolean showEcoCycID = false; // Boolean | 
Boolean showGeneName = false; // Boolean | 
Boolean showHGNCID = false; // Boolean | 
Boolean showMGIID = false; // Boolean | 
Boolean showOrthoIsoform = false; // Boolean | 
Boolean showOrthoModifiedForm = false; // Boolean | 
Boolean showPANTHERID = false; // Boolean | 
Boolean showPMID = false; // Boolean | 
Boolean showReactomeID = false; // Boolean | 
Boolean showSynonym = false; // Boolean | 
Boolean showUniProtKBID = false; // Boolean | 
Integer offset = 0; // Integer | The number of items to skip before starting to collect the result set.
Integer limit = 50; // Integer | The numbers of items to return.
try {
    List<PROTerm> result = apiInstance.getPROTermsWithPIRSFId(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showPIRSFID, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPMID, showReactomeID, showSynonym, showUniProtKBID, offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DatabaseCrossReferencesApi#getPROTermsWithPIRSFId");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] [enum: Any_field, Any_relationship, Category, Child, Comment, EcoCyc_ID, Gene_Name, HGNC_ID, PRO_ID, Interaction_with, MGI_ID, Modifier, Ontology_ID, Ontology_term, Ortho-isoform, Ortho-modform, Panther_ID, Parent, PIRSF_ID, PMID, PRO_term_definition, PRO_name, PRO_name_synonyms, Reactiome_ID, Relation, Taxon_ID, UniProtKB_ID]
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional]
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showPIRSFID** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Integer**| The number of items to skip before starting to collect the result set. | [optional] [default to 0] [enum: ]
 **limit** | **Integer**| The numbers of items to return. | [optional] [default to 50] [enum: ]

### Return type

[**List&lt;PROTerm&gt;**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getPROTermsWithPMID"></a>
# **getPROTermsWithPMID**
> List&lt;PROTerm&gt; getPROTermsWithPMID(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showPMID, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showReactomeID, showSynonym, showUniProtKBID, offset, limit)

Returns a list of PRO terms with PMID as cross-reference.

Gets a list of PRO terms with PMID as cross-reference and associated information.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DatabaseCrossReferencesApi;


DatabaseCrossReferencesApi apiInstance = new DatabaseCrossReferencesApi();
String searchField = "searchField_example"; // String | Search field that needs to be considered for filter
String searchValue = "searchValue_example"; // String | any string or \"null\" or \"not null\" or a list of space separated ids
Boolean showPROName = true; // Boolean | 
Boolean showPROTermDefinition = true; // Boolean | 
Boolean showCategory = true; // Boolean | 
Boolean showParent = true; // Boolean | 
Boolean showPMID = true; // Boolean | 
Boolean showAnnotation = false; // Boolean | 
Boolean showAnyRelationship = false; // Boolean | 
Boolean showChild = false; // Boolean | 
Boolean showComment = false; // Boolean | 
Boolean showEcoCycID = false; // Boolean | 
Boolean showGeneName = false; // Boolean | 
Boolean showHGNCID = false; // Boolean | 
Boolean showMGIID = false; // Boolean | 
Boolean showOrthoIsoform = false; // Boolean | 
Boolean showOrthoModifiedForm = false; // Boolean | 
Boolean showPANTHERID = false; // Boolean | 
Boolean showPIRSFID = false; // Boolean | 
Boolean showReactomeID = false; // Boolean | 
Boolean showSynonym = false; // Boolean | 
Boolean showUniProtKBID = false; // Boolean | 
Integer offset = 0; // Integer | The number of items to skip before starting to collect the result set.
Integer limit = 50; // Integer | The numbers of items to return.
try {
    List<PROTerm> result = apiInstance.getPROTermsWithPMID(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showPMID, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showReactomeID, showSynonym, showUniProtKBID, offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DatabaseCrossReferencesApi#getPROTermsWithPMID");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] [enum: Any_field, Any_relationship, Category, Child, Comment, EcoCyc_ID, Gene_Name, HGNC_ID, PRO_ID, Interaction_with, MGI_ID, Modifier, Ontology_ID, Ontology_term, Ortho-isoform, Ortho-modform, Panther_ID, Parent, PIRSF_ID, PMID, PRO_term_definition, PRO_name, PRO_name_synonyms, Reactiome_ID, Relation, Taxon_ID, UniProtKB_ID]
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional]
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showPMID** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Integer**| The number of items to skip before starting to collect the result set. | [optional] [default to 0] [enum: ]
 **limit** | **Integer**| The numbers of items to return. | [optional] [default to 50] [enum: ]

### Return type

[**List&lt;PROTerm&gt;**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getPROTermsWithReactomeID"></a>
# **getPROTermsWithReactomeID**
> List&lt;PROTerm&gt; getPROTermsWithReactomeID(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showReactomeID, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showUniProtKBID, offset, limit)

Returns a list of PRO terms with Reactome ID as cross-reference.

Gets a list of PRO terms with Reactome ID as cross-reference and associated information.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DatabaseCrossReferencesApi;


DatabaseCrossReferencesApi apiInstance = new DatabaseCrossReferencesApi();
String searchField = "searchField_example"; // String | Search field that needs to be considered for filter
String searchValue = "searchValue_example"; // String | any string or \"null\" or \"not null\" or a list of space separated ids
Boolean showPROName = true; // Boolean | 
Boolean showPROTermDefinition = true; // Boolean | 
Boolean showCategory = true; // Boolean | 
Boolean showParent = true; // Boolean | 
Boolean showReactomeID = true; // Boolean | 
Boolean showAnnotation = false; // Boolean | 
Boolean showAnyRelationship = false; // Boolean | 
Boolean showChild = false; // Boolean | 
Boolean showComment = false; // Boolean | 
Boolean showEcoCycID = false; // Boolean | 
Boolean showGeneName = false; // Boolean | 
Boolean showHGNCID = false; // Boolean | 
Boolean showMGIID = false; // Boolean | 
Boolean showOrthoIsoform = false; // Boolean | 
Boolean showOrthoModifiedForm = false; // Boolean | 
Boolean showPANTHERID = false; // Boolean | 
Boolean showPIRSFID = false; // Boolean | 
Boolean showPMID = false; // Boolean | 
Boolean showUniProtKBID = false; // Boolean | 
Integer offset = 0; // Integer | The number of items to skip before starting to collect the result set.
Integer limit = 50; // Integer | The numbers of items to return.
try {
    List<PROTerm> result = apiInstance.getPROTermsWithReactomeID(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showReactomeID, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showUniProtKBID, offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DatabaseCrossReferencesApi#getPROTermsWithReactomeID");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] [enum: Any_field, Any_relationship, Category, Child, Comment, EcoCyc_ID, Gene_Name, HGNC_ID, PRO_ID, Interaction_with, MGI_ID, Modifier, Ontology_ID, Ontology_term, Ortho-isoform, Ortho-modform, Panther_ID, Parent, PIRSF_ID, PMID, PRO_term_definition, PRO_name, PRO_name_synonyms, Reactiome_ID, Relation, Taxon_ID, UniProtKB_ID]
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional]
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showReactomeID** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Integer**| The number of items to skip before starting to collect the result set. | [optional] [default to 0] [enum: ]
 **limit** | **Integer**| The numbers of items to return. | [optional] [default to 50] [enum: ]

### Return type

[**List&lt;PROTerm&gt;**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getPROTermsWithUniProtKBID"></a>
# **getPROTermsWithUniProtKBID**
> List&lt;PROTerm&gt; getPROTermsWithUniProtKBID(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showUniProtKBID, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, offset, limit)

Returns a list of PRO terms with UniProtKB ID as cross-reference.

Gets a list of PRO terms with UniProtKB ID as cross-reference and associated information.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DatabaseCrossReferencesApi;


DatabaseCrossReferencesApi apiInstance = new DatabaseCrossReferencesApi();
String searchField = "searchField_example"; // String | Search field that needs to be considered for filter
String searchValue = "searchValue_example"; // String | any string or \"null\" or \"not null\" or a list of space separated ids
Boolean showPROName = true; // Boolean | 
Boolean showPROTermDefinition = true; // Boolean | 
Boolean showCategory = true; // Boolean | 
Boolean showParent = true; // Boolean | 
Boolean showUniProtKBID = true; // Boolean | 
Boolean showAnnotation = false; // Boolean | 
Boolean showAnyRelationship = false; // Boolean | 
Boolean showChild = false; // Boolean | 
Boolean showComment = false; // Boolean | 
Boolean showEcoCycID = false; // Boolean | 
Boolean showGeneName = false; // Boolean | 
Boolean showHGNCID = false; // Boolean | 
Boolean showMGIID = false; // Boolean | 
Boolean showOrthoIsoform = false; // Boolean | 
Boolean showOrthoModifiedForm = false; // Boolean | 
Boolean showPANTHERID = false; // Boolean | 
Boolean showPIRSFID = false; // Boolean | 
Boolean showPMID = false; // Boolean | 
Boolean showReactomeID = false; // Boolean | 
Integer offset = 0; // Integer | The number of items to skip before starting to collect the result set.
Integer limit = 50; // Integer | The numbers of items to return.
try {
    List<PROTerm> result = apiInstance.getPROTermsWithUniProtKBID(searchField, searchValue, showPROName, showPROTermDefinition, showCategory, showParent, showUniProtKBID, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DatabaseCrossReferencesApi#getPROTermsWithUniProtKBID");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **searchField** | **String**| Search field that needs to be considered for filter | [optional] [enum: Any_field, Any_relationship, Category, Child, Comment, EcoCyc_ID, Gene_Name, HGNC_ID, PRO_ID, Interaction_with, MGI_ID, Modifier, Ontology_ID, Ontology_term, Ortho-isoform, Ortho-modform, Panther_ID, Parent, PIRSF_ID, PMID, PRO_term_definition, PRO_name, PRO_name_synonyms, Reactiome_ID, Relation, Taxon_ID, UniProtKB_ID]
 **searchValue** | **String**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional]
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Integer**| The number of items to skip before starting to collect the result set. | [optional] [default to 0] [enum: ]
 **limit** | **Integer**| The numbers of items to return. | [optional] [default to 50] [enum: ]

### Return type

[**List&lt;PROTerm&gt;**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

