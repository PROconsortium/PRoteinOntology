# DagApi

All URIs are relative to *https://research.bioinformatics.udel.edu/PRO_API/V1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getAncestorByProIDs**](DagApi.md#getAncestorByProIDs) | **GET** /dag/ancestor/{proIds} | Returns direct and indirect parent PRO terms by the given PRO ID(s).
[**getChildrenByProIDs**](DagApi.md#getChildrenByProIDs) | **GET** /dag/children/{proIds} | Returns direct children PRO terms by the given PRO ID(s).
[**getDescendantByProIDs**](DagApi.md#getDescendantByProIDs) | **GET** /dag/descendant/{proIds} | Returns direct and indirect children PRO terms by the given PRO ID(s).
[**getHierarchyByProID**](DagApi.md#getHierarchyByProID) | **GET** /dag/hierarchy/{proId} | Returns hierarchy of PRO terms by the given PRO ID.
[**getParentByProIDs**](DagApi.md#getParentByProIDs) | **GET** /dag/parent/{proIds} | Returns direct parent PRO terms by the given PRO ID(s).

<a name="getAncestorByProIDs"></a>
# **getAncestorByProIDs**
> List&lt;PROTerm&gt; getAncestorByProIDs(proIds, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showUniProtKBID, offset, limit)

Returns direct and indirect parent PRO terms by the given PRO ID(s).

Gets direct and indirect parent PRO terms by the given PRO ID(s) and associated information.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DagApi;


DagApi apiInstance = new DagApi();
String proIds = "proIds_example"; // String | PRO ID(s). Space separated values accepted up to 100.
Boolean showPROName = true; // Boolean | 
Boolean showPROTermDefinition = true; // Boolean | 
Boolean showCategory = true; // Boolean | 
Boolean showParent = true; // Boolean | 
Boolean showAnnotation = false; // Boolean | 
Boolean showAnyRelationship = false; // Boolean | 
Boolean showChild = false; // Boolean | 
Boolean showComment = false; // Boolean | 
Boolean showEcoCycID = false; // Boolean | 
Boolean showGeneName = false; // Boolean | 
Boolean showHGNCID = false; // Boolean | 
Boolean showMGIID = false; // Boolean | 
Boolean showOrthoIsoform = false; // Boolean | 
Boolean showOrthoModifiedForm = false; // Boolean | 
Boolean showPANTHERID = false; // Boolean | 
Boolean showPIRSFID = false; // Boolean | 
Boolean showPMID = false; // Boolean | 
Boolean showReactomeID = false; // Boolean | 
Boolean showUniProtKBID = false; // Boolean | 
Integer offset = 0; // Integer | The number of items to skip before starting to collect the result set.
Integer limit = 50; // Integer | The numbers of items to return.
try {
    List<PROTerm> result = apiInstance.getAncestorByProIDs(proIds, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showUniProtKBID, offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DagApi#getAncestorByProIDs");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **proIds** | **String**| PRO ID(s). Space separated values accepted up to 100. |
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Integer**| The number of items to skip before starting to collect the result set. | [optional] [default to 0] [enum: ]
 **limit** | **Integer**| The numbers of items to return. | [optional] [default to 50] [enum: ]

### Return type

[**List&lt;PROTerm&gt;**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getChildrenByProIDs"></a>
# **getChildrenByProIDs**
> List&lt;PROTerm&gt; getChildrenByProIDs(proIds, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showUniProtKBID, offset, limit)

Returns direct children PRO terms by the given PRO ID(s).

Gets direct children PRO terms by the given PRO ID(s) and associated information.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DagApi;


DagApi apiInstance = new DagApi();
String proIds = "proIds_example"; // String | PRO ID(s). Space separated values accepted up to 100.
Boolean showPROName = true; // Boolean | 
Boolean showPROTermDefinition = true; // Boolean | 
Boolean showCategory = true; // Boolean | 
Boolean showParent = true; // Boolean | 
Boolean showAnnotation = false; // Boolean | 
Boolean showAnyRelationship = false; // Boolean | 
Boolean showChild = false; // Boolean | 
Boolean showComment = false; // Boolean | 
Boolean showEcoCycID = false; // Boolean | 
Boolean showGeneName = false; // Boolean | 
Boolean showHGNCID = false; // Boolean | 
Boolean showMGIID = false; // Boolean | 
Boolean showOrthoIsoform = false; // Boolean | 
Boolean showOrthoModifiedForm = false; // Boolean | 
Boolean showPANTHERID = false; // Boolean | 
Boolean showPIRSFID = false; // Boolean | 
Boolean showPMID = false; // Boolean | 
Boolean showReactomeID = false; // Boolean | 
Boolean showUniProtKBID = false; // Boolean | 
Integer offset = 0; // Integer | The number of items to skip before starting to collect the result set.
Integer limit = 50; // Integer | The numbers of items to return.
try {
    List<PROTerm> result = apiInstance.getChildrenByProIDs(proIds, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showUniProtKBID, offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DagApi#getChildrenByProIDs");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **proIds** | **String**| PRO ID(s). Space separated values accepted up to 100. |
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Integer**| The number of items to skip before starting to collect the result set. | [optional] [default to 0] [enum: ]
 **limit** | **Integer**| The numbers of items to return. | [optional] [default to 50] [enum: ]

### Return type

[**List&lt;PROTerm&gt;**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getDescendantByProIDs"></a>
# **getDescendantByProIDs**
> List&lt;PROTerm&gt; getDescendantByProIDs(proIds, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showUniProtKBID, offset, limit)

Returns direct and indirect children PRO terms by the given PRO ID(s).

Gets direct and indirect children PRO terms by the given PRO ID(s) and associated information.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DagApi;


DagApi apiInstance = new DagApi();
String proIds = "proIds_example"; // String | PRO ID(s). Space separated values accepted up to 100.
Boolean showPROName = true; // Boolean | 
Boolean showPROTermDefinition = true; // Boolean | 
Boolean showCategory = true; // Boolean | 
Boolean showParent = true; // Boolean | 
Boolean showAnnotation = false; // Boolean | 
Boolean showAnyRelationship = false; // Boolean | 
Boolean showChild = false; // Boolean | 
Boolean showComment = false; // Boolean | 
Boolean showEcoCycID = false; // Boolean | 
Boolean showGeneName = false; // Boolean | 
Boolean showHGNCID = false; // Boolean | 
Boolean showMGIID = false; // Boolean | 
Boolean showOrthoIsoform = false; // Boolean | 
Boolean showOrthoModifiedForm = false; // Boolean | 
Boolean showPANTHERID = false; // Boolean | 
Boolean showPIRSFID = false; // Boolean | 
Boolean showPMID = false; // Boolean | 
Boolean showReactomeID = false; // Boolean | 
Boolean showUniProtKBID = false; // Boolean | 
Integer offset = 0; // Integer | The number of items to skip before starting to collect the result set.
Integer limit = 50; // Integer | The numbers of items to return.
try {
    List<PROTerm> result = apiInstance.getDescendantByProIDs(proIds, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showUniProtKBID, offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DagApi#getDescendantByProIDs");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **proIds** | **String**| PRO ID(s). Space separated values accepted up to 100. |
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Integer**| The number of items to skip before starting to collect the result set. | [optional] [default to 0] [enum: ]
 **limit** | **Integer**| The numbers of items to return. | [optional] [default to 50] [enum: ]

### Return type

[**List&lt;PROTerm&gt;**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getHierarchyByProID"></a>
# **getHierarchyByProID**
> List&lt;ChildParentPair&gt; getHierarchyByProID(proId, showPROName, showPROTermDefinition, showCategory, showAnnotation, showAnyRelationship, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showTaxonID, showUniProtKBID)

Returns hierarchy of PRO terms by the given PRO ID.

Gets hierarchy of PRO terms by the given PRO ID.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DagApi;


DagApi apiInstance = new DagApi();
String proId = "proId_example"; // String | Space separated PRO ID(s).
Boolean showPROName = true; // Boolean | 
Boolean showPROTermDefinition = true; // Boolean | 
Boolean showCategory = true; // Boolean | 
Boolean showAnnotation = false; // Boolean | 
Boolean showAnyRelationship = false; // Boolean | 
Boolean showComment = false; // Boolean | 
Boolean showEcoCycID = false; // Boolean | 
Boolean showGeneName = false; // Boolean | 
Boolean showHGNCID = false; // Boolean | 
Boolean showMGIID = false; // Boolean | 
Boolean showOrthoIsoform = false; // Boolean | 
Boolean showOrthoModifiedForm = false; // Boolean | 
Boolean showPANTHERID = false; // Boolean | 
Boolean showPIRSFID = false; // Boolean | 
Boolean showPMID = false; // Boolean | 
Boolean showReactomeID = false; // Boolean | 
Boolean showSynonym = false; // Boolean | 
Boolean showTaxonID = false; // Boolean | 
Boolean showUniProtKBID = false; // Boolean | 
try {
    List<ChildParentPair> result = apiInstance.getHierarchyByProID(proId, showPROName, showPROTermDefinition, showCategory, showAnnotation, showAnyRelationship, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showSynonym, showTaxonID, showUniProtKBID);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DagApi#getHierarchyByProID");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **proId** | **String**| Space separated PRO ID(s). |
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showSynonym** | **Boolean**|  | [optional] [default to false]
 **showTaxonID** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]

### Return type

[**List&lt;ChildParentPair&gt;**](ChildParentPair.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getParentByProIDs"></a>
# **getParentByProIDs**
> List&lt;PROTerm&gt; getParentByProIDs(proIds, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showUniProtKBID, offset, limit)

Returns direct parent PRO terms by the given PRO ID(s).

Gets direct parent PRO terms by the given PRO ID(s) and associated information.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DagApi;


DagApi apiInstance = new DagApi();
String proIds = "proIds_example"; // String | PRO ID(s). Space separated values accepted up to 100.
Boolean showPROName = true; // Boolean | 
Boolean showPROTermDefinition = true; // Boolean | 
Boolean showCategory = true; // Boolean | 
Boolean showParent = true; // Boolean | 
Boolean showAnnotation = false; // Boolean | 
Boolean showAnyRelationship = false; // Boolean | 
Boolean showChild = false; // Boolean | 
Boolean showComment = false; // Boolean | 
Boolean showEcoCycID = false; // Boolean | 
Boolean showGeneName = false; // Boolean | 
Boolean showHGNCID = false; // Boolean | 
Boolean showMGIID = false; // Boolean | 
Boolean showOrthoIsoform = false; // Boolean | 
Boolean showOrthoModifiedForm = false; // Boolean | 
Boolean showPANTHERID = false; // Boolean | 
Boolean showPIRSFID = false; // Boolean | 
Boolean showPMID = false; // Boolean | 
Boolean showReactomeID = false; // Boolean | 
Boolean showUniProtKBID = false; // Boolean | 
Integer offset = 0; // Integer | The number of items to skip before starting to collect the result set.
Integer limit = 50; // Integer | The numbers of items to return.
try {
    List<PROTerm> result = apiInstance.getParentByProIDs(proIds, showPROName, showPROTermDefinition, showCategory, showParent, showAnnotation, showAnyRelationship, showChild, showComment, showEcoCycID, showGeneName, showHGNCID, showMGIID, showOrthoIsoform, showOrthoModifiedForm, showPANTHERID, showPIRSFID, showPMID, showReactomeID, showUniProtKBID, offset, limit);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DagApi#getParentByProIDs");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **proIds** | **String**| PRO ID(s). Space separated values accepted up to 100. |
 **showPROName** | **Boolean**|  | [optional] [default to true]
 **showPROTermDefinition** | **Boolean**|  | [optional] [default to true]
 **showCategory** | **Boolean**|  | [optional] [default to true]
 **showParent** | **Boolean**|  | [optional] [default to true]
 **showAnnotation** | **Boolean**|  | [optional] [default to false]
 **showAnyRelationship** | **Boolean**|  | [optional] [default to false]
 **showChild** | **Boolean**|  | [optional] [default to false]
 **showComment** | **Boolean**|  | [optional] [default to false]
 **showEcoCycID** | **Boolean**|  | [optional] [default to false]
 **showGeneName** | **Boolean**|  | [optional] [default to false]
 **showHGNCID** | **Boolean**|  | [optional] [default to false]
 **showMGIID** | **Boolean**|  | [optional] [default to false]
 **showOrthoIsoform** | **Boolean**|  | [optional] [default to false]
 **showOrthoModifiedForm** | **Boolean**|  | [optional] [default to false]
 **showPANTHERID** | **Boolean**|  | [optional] [default to false]
 **showPIRSFID** | **Boolean**|  | [optional] [default to false]
 **showPMID** | **Boolean**|  | [optional] [default to false]
 **showReactomeID** | **Boolean**|  | [optional] [default to false]
 **showUniProtKBID** | **Boolean**|  | [optional] [default to false]
 **offset** | **Integer**| The number of items to skip before starting to collect the result set. | [optional] [default to 0] [enum: ]
 **limit** | **Integer**| The numbers of items to return. | [optional] [default to 50] [enum: ]

### Return type

[**List&lt;PROTerm&gt;**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

