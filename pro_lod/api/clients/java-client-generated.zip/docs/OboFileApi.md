# OboFileApi

All URIs are relative to *https://research.bioinformatics.udel.edu/PRO_API/V1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getOBOByPROIDs**](OboFileApi.md#getOBOByPROIDs) | **GET** /obo/{proIds} | Returns PRO term in OBO format for the given PRO ID(s).

<a name="getOBOByPROIDs"></a>
# **getOBOByPROIDs**
> String getOBOByPROIDs(proIds)

Returns PRO term in OBO format for the given PRO ID(s).

Gets PRO term in OBO format for the given PRO ID(s).

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.OboFileApi;


OboFileApi apiInstance = new OboFileApi();
String proIds = "proIds_example"; // String | PRO ID(s). Space separated values accepted up to 100.
try {
    String result = apiInstance.getOBOByPROIDs(proIds);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling OboFileApi#getOBOByPROIDs");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **proIds** | **String**| PRO ID(s). Space separated values accepted up to 100. |

### Return type

**String**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json

