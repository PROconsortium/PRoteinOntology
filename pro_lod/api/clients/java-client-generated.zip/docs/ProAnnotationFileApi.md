# ProAnnotationFileApi

All URIs are relative to *https://research.bioinformatics.udel.edu/PRO_API/V1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getPROAnnotationsByPROIDs**](ProAnnotationFileApi.md#getPROAnnotationsByPROIDs) | **GET** /paf/{proIds} | Returns annotations for the given PRO ID(s).

<a name="getPROAnnotationsByPROIDs"></a>
# **getPROAnnotationsByPROIDs**
> List&lt;Annotation&gt; getPROAnnotationsByPROIDs(proIds)

Returns annotations for the given PRO ID(s).

Gets annotations for the given PRO ID(s).

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ProAnnotationFileApi;


ProAnnotationFileApi apiInstance = new ProAnnotationFileApi();
String proIds = "proIds_example"; // String | PRO ID(s). Space separated values accepted up to 100.
try {
    List<Annotation> result = apiInstance.getPROAnnotationsByPROIDs(proIds);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProAnnotationFileApi#getPROAnnotationsByPROIDs");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **proIds** | **String**| PRO ID(s). Space separated values accepted up to 100. |

### Return type

[**List&lt;Annotation&gt;**](Annotation.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml, text/tab-separated-values

