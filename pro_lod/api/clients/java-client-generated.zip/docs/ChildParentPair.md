# ChildParentPair

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pro** | [**PROTerm**](PROTerm.md) |  |  [optional]
**proParent** | [**PROTerm**](PROTerm.md) |  |  [optional]
