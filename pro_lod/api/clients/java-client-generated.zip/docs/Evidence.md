# Evidence

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**evidenceSource** | **List&lt;String&gt;** |  |  [optional]
**evidenceCode** | **String** |  |  [optional]
