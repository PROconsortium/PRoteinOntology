# swagger_client.PROTermsApi

All URIs are relative to *https://research.bioinformatics.udel.edu/PRO_API/V1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_pro_term_by_i_ds**](PROTermsApi.md#get_pro_term_by_i_ds) | **GET** /pros/{proIds} | Return PRO terms by IDs.
[**get_pro_terms**](PROTermsApi.md#get_pro_terms) | **GET** /pros | Search PRO terms.

# **get_pro_term_by_i_ds**
> PROTerm get_pro_term_by_i_ds(pro_ids, show_pro_name=show_pro_name, show_pro_term_definition=show_pro_term_definition, show_category=show_category, show_parent=show_parent, show_annotation=show_annotation, show_any_relationship=show_any_relationship, show_child=show_child, show_comment=show_comment, show_eco_cyc_id=show_eco_cyc_id, show_gene_name=show_gene_name, show_hgncid=show_hgncid, show_mgiid=show_mgiid, show_ortho_isoform=show_ortho_isoform, show_ortho_modified_form=show_ortho_modified_form, show_pantherid=show_pantherid, show_pirsfid=show_pirsfid, show_pmid=show_pmid, show_reactome_id=show_reactome_id, show_synonym=show_synonym, show_uni_prot_kbid=show_uni_prot_kbid)

Return PRO terms by IDs.

Gets PRO terms and associated information.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.PROTermsApi()
pro_ids = 'pro_ids_example' # str | PRO ID(s). Space separated values accepted up to 100.
show_pro_name = true # bool |  (optional) (default to true)
show_pro_term_definition = true # bool |  (optional) (default to true)
show_category = true # bool |  (optional) (default to true)
show_parent = true # bool |  (optional) (default to true)
show_annotation = false # bool |  (optional) (default to false)
show_any_relationship = false # bool |  (optional) (default to false)
show_child = false # bool |  (optional) (default to false)
show_comment = false # bool |  (optional) (default to false)
show_eco_cyc_id = false # bool |  (optional) (default to false)
show_gene_name = false # bool |  (optional) (default to false)
show_hgncid = false # bool |  (optional) (default to false)
show_mgiid = false # bool |  (optional) (default to false)
show_ortho_isoform = false # bool |  (optional) (default to false)
show_ortho_modified_form = false # bool |  (optional) (default to false)
show_pantherid = false # bool |  (optional) (default to false)
show_pirsfid = false # bool |  (optional) (default to false)
show_pmid = false # bool |  (optional) (default to false)
show_reactome_id = false # bool |  (optional) (default to false)
show_synonym = false # bool |  (optional) (default to false)
show_uni_prot_kbid = false # bool |  (optional) (default to false)

try:
    # Return PRO terms by IDs.
    api_response = api_instance.get_pro_term_by_i_ds(pro_ids, show_pro_name=show_pro_name, show_pro_term_definition=show_pro_term_definition, show_category=show_category, show_parent=show_parent, show_annotation=show_annotation, show_any_relationship=show_any_relationship, show_child=show_child, show_comment=show_comment, show_eco_cyc_id=show_eco_cyc_id, show_gene_name=show_gene_name, show_hgncid=show_hgncid, show_mgiid=show_mgiid, show_ortho_isoform=show_ortho_isoform, show_ortho_modified_form=show_ortho_modified_form, show_pantherid=show_pantherid, show_pirsfid=show_pirsfid, show_pmid=show_pmid, show_reactome_id=show_reactome_id, show_synonym=show_synonym, show_uni_prot_kbid=show_uni_prot_kbid)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling PROTermsApi->get_pro_term_by_i_ds: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pro_ids** | **str**| PRO ID(s). Space separated values accepted up to 100. | 
 **show_pro_name** | **bool**|  | [optional] [default to true]
 **show_pro_term_definition** | **bool**|  | [optional] [default to true]
 **show_category** | **bool**|  | [optional] [default to true]
 **show_parent** | **bool**|  | [optional] [default to true]
 **show_annotation** | **bool**|  | [optional] [default to false]
 **show_any_relationship** | **bool**|  | [optional] [default to false]
 **show_child** | **bool**|  | [optional] [default to false]
 **show_comment** | **bool**|  | [optional] [default to false]
 **show_eco_cyc_id** | **bool**|  | [optional] [default to false]
 **show_gene_name** | **bool**|  | [optional] [default to false]
 **show_hgncid** | **bool**|  | [optional] [default to false]
 **show_mgiid** | **bool**|  | [optional] [default to false]
 **show_ortho_isoform** | **bool**|  | [optional] [default to false]
 **show_ortho_modified_form** | **bool**|  | [optional] [default to false]
 **show_pantherid** | **bool**|  | [optional] [default to false]
 **show_pirsfid** | **bool**|  | [optional] [default to false]
 **show_pmid** | **bool**|  | [optional] [default to false]
 **show_reactome_id** | **bool**|  | [optional] [default to false]
 **show_synonym** | **bool**|  | [optional] [default to false]
 **show_uni_prot_kbid** | **bool**|  | [optional] [default to false]

### Return type

[**PROTerm**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_pro_terms**
> list[PROTerm] get_pro_terms(search_field=search_field, search_value=search_value, show_pro_name=show_pro_name, show_pro_term_definition=show_pro_term_definition, show_category=show_category, show_parent=show_parent, show_annotation=show_annotation, show_any_relationship=show_any_relationship, show_child=show_child, show_comment=show_comment, show_eco_cyc_id=show_eco_cyc_id, show_gene_name=show_gene_name, show_hgncid=show_hgncid, show_mgiid=show_mgiid, show_ortho_isoform=show_ortho_isoform, show_ortho_modified_form=show_ortho_modified_form, show_pantherid=show_pantherid, show_pirsfid=show_pirsfid, show_pmid=show_pmid, show_reactome_id=show_reactome_id, show_synonym=show_synonym, show_uni_prot_kbid=show_uni_prot_kbid, offset=offset, limit=limit)

Search PRO terms.

Gets a list of PRO terms and associated information.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.PROTermsApi()
search_field = 'search_field_example' # str | Search field that needs to be considered for filter (optional)
search_value = 'search_value_example' # str | any string or \"null\" or \"not null\" or a list of space separated ids (optional)
show_pro_name = true # bool |  (optional) (default to true)
show_pro_term_definition = true # bool |  (optional) (default to true)
show_category = true # bool |  (optional) (default to true)
show_parent = true # bool |  (optional) (default to true)
show_annotation = false # bool |  (optional) (default to false)
show_any_relationship = false # bool |  (optional) (default to false)
show_child = false # bool |  (optional) (default to false)
show_comment = false # bool |  (optional) (default to false)
show_eco_cyc_id = false # bool |  (optional) (default to false)
show_gene_name = false # bool |  (optional) (default to false)
show_hgncid = false # bool |  (optional) (default to false)
show_mgiid = false # bool |  (optional) (default to false)
show_ortho_isoform = false # bool |  (optional) (default to false)
show_ortho_modified_form = false # bool |  (optional) (default to false)
show_pantherid = false # bool |  (optional) (default to false)
show_pirsfid = false # bool |  (optional) (default to false)
show_pmid = false # bool |  (optional) (default to false)
show_reactome_id = false # bool |  (optional) (default to false)
show_synonym = false # bool |  (optional) (default to false)
show_uni_prot_kbid = false # bool |  (optional) (default to false)
offset = 0 # int | The number of items to skip before starting to collect the result set. (optional) (default to 0)
limit = 50 # int | The numbers of items to return. (optional) (default to 50)

try:
    # Search PRO terms.
    api_response = api_instance.get_pro_terms(search_field=search_field, search_value=search_value, show_pro_name=show_pro_name, show_pro_term_definition=show_pro_term_definition, show_category=show_category, show_parent=show_parent, show_annotation=show_annotation, show_any_relationship=show_any_relationship, show_child=show_child, show_comment=show_comment, show_eco_cyc_id=show_eco_cyc_id, show_gene_name=show_gene_name, show_hgncid=show_hgncid, show_mgiid=show_mgiid, show_ortho_isoform=show_ortho_isoform, show_ortho_modified_form=show_ortho_modified_form, show_pantherid=show_pantherid, show_pirsfid=show_pirsfid, show_pmid=show_pmid, show_reactome_id=show_reactome_id, show_synonym=show_synonym, show_uni_prot_kbid=show_uni_prot_kbid, offset=offset, limit=limit)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling PROTermsApi->get_pro_terms: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search_field** | **str**| Search field that needs to be considered for filter | [optional] 
 **search_value** | **str**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **show_pro_name** | **bool**|  | [optional] [default to true]
 **show_pro_term_definition** | **bool**|  | [optional] [default to true]
 **show_category** | **bool**|  | [optional] [default to true]
 **show_parent** | **bool**|  | [optional] [default to true]
 **show_annotation** | **bool**|  | [optional] [default to false]
 **show_any_relationship** | **bool**|  | [optional] [default to false]
 **show_child** | **bool**|  | [optional] [default to false]
 **show_comment** | **bool**|  | [optional] [default to false]
 **show_eco_cyc_id** | **bool**|  | [optional] [default to false]
 **show_gene_name** | **bool**|  | [optional] [default to false]
 **show_hgncid** | **bool**|  | [optional] [default to false]
 **show_mgiid** | **bool**|  | [optional] [default to false]
 **show_ortho_isoform** | **bool**|  | [optional] [default to false]
 **show_ortho_modified_form** | **bool**|  | [optional] [default to false]
 **show_pantherid** | **bool**|  | [optional] [default to false]
 **show_pirsfid** | **bool**|  | [optional] [default to false]
 **show_pmid** | **bool**|  | [optional] [default to false]
 **show_reactome_id** | **bool**|  | [optional] [default to false]
 **show_synonym** | **bool**|  | [optional] [default to false]
 **show_uni_prot_kbid** | **bool**|  | [optional] [default to false]
 **offset** | **int**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**list[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

