# swagger_client.DatabaseCrossReferencesApi

All URIs are relative to *https://research.bioinformatics.udel.edu/PRO_API/V1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_pro_terms_with_eco_cy_c_id**](DatabaseCrossReferencesApi.md#get_pro_terms_with_eco_cy_c_id) | **GET** /dbxrefs/EcoCyc_ID | Returns a list of PRO terms with EcoCyC ID as cross-reference.
[**get_pro_terms_with_hgnc_id**](DatabaseCrossReferencesApi.md#get_pro_terms_with_hgnc_id) | **GET** /dbxrefs/HGNC_ID | Returns a list of PRO terms with HGNC ID as cross-reference.
[**get_pro_terms_with_mgi_id**](DatabaseCrossReferencesApi.md#get_pro_terms_with_mgi_id) | **GET** /dbxrefs/MGI_ID | Returns a list of PRO terms with MGI ID as cross-reference.
[**get_pro_terms_with_ncbi_taxon_id**](DatabaseCrossReferencesApi.md#get_pro_terms_with_ncbi_taxon_id) | **GET** /dbxrefs/NCBITaxon_ID | Returns a list of PRO terms with NCBI Taxon ID as cross-reference.
[**get_pro_terms_with_ontology_id**](DatabaseCrossReferencesApi.md#get_pro_terms_with_ontology_id) | **GET** /dbxrefs/Ontology_ID | Returns a list of PRO terms with Ontology ID as cross-reference.
[**get_pro_terms_with_panther_id**](DatabaseCrossReferencesApi.md#get_pro_terms_with_panther_id) | **GET** /dbxrefs/PANTHER_ID | Returns a list of PRO terms with PANTHER ID as cross-reference.
[**get_pro_terms_with_pirsf_id**](DatabaseCrossReferencesApi.md#get_pro_terms_with_pirsf_id) | **GET** /dbxrefs/PIRSF_ID | Returns a list of PRO terms with PIRSF ID as cross-reference.
[**get_pro_terms_with_pmid**](DatabaseCrossReferencesApi.md#get_pro_terms_with_pmid) | **GET** /dbxrefs/PMID | Returns a list of PRO terms with PMID as cross-reference.
[**get_pro_terms_with_reactome_id**](DatabaseCrossReferencesApi.md#get_pro_terms_with_reactome_id) | **GET** /dbxrefs/Reactome_ID | Returns a list of PRO terms with Reactome ID as cross-reference.
[**get_pro_terms_with_uni_prot_kbid**](DatabaseCrossReferencesApi.md#get_pro_terms_with_uni_prot_kbid) | **GET** /dbxrefs/UniProtKB_ID | Returns a list of PRO terms with UniProtKB ID as cross-reference.

# **get_pro_terms_with_eco_cy_c_id**
> list[PROTerm] get_pro_terms_with_eco_cy_c_id(search_field=search_field, search_value=search_value, show_pro_name=show_pro_name, show_pro_term_definition=show_pro_term_definition, show_category=show_category, show_eco_cyc_id=show_eco_cyc_id, show_annotation=show_annotation, show_any_relationship=show_any_relationship, show_child=show_child, show_comment=show_comment, show_gene_name=show_gene_name, show_hgncid=show_hgncid, show_mgiid=show_mgiid, show_ortho_isoform=show_ortho_isoform, show_ortho_modified_form=show_ortho_modified_form, show_pantherid=show_pantherid, show_pirsfid=show_pirsfid, show_pmid=show_pmid, show_reactome_id=show_reactome_id, show_synonym=show_synonym, show_uni_prot_kbid=show_uni_prot_kbid, offset=offset, limit=limit)

Returns a list of PRO terms with EcoCyC ID as cross-reference.

Gets a list of PRO terms with EcoCyC ID as cross-reference and associated information.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DatabaseCrossReferencesApi()
search_field = 'search_field_example' # str | Search field that needs to be considered for filter (optional)
search_value = 'search_value_example' # str | any string or \"null\" or \"not null\" or a list of space separated ids (optional)
show_pro_name = true # bool |  (optional) (default to true)
show_pro_term_definition = true # bool |  (optional) (default to true)
show_category = true # bool |  (optional) (default to true)
show_eco_cyc_id = true # bool |  (optional) (default to true)
show_annotation = false # bool |  (optional) (default to false)
show_any_relationship = false # bool |  (optional) (default to false)
show_child = false # bool |  (optional) (default to false)
show_comment = false # bool |  (optional) (default to false)
show_gene_name = false # bool |  (optional) (default to false)
show_hgncid = false # bool |  (optional) (default to false)
show_mgiid = false # bool |  (optional) (default to false)
show_ortho_isoform = false # bool |  (optional) (default to false)
show_ortho_modified_form = false # bool |  (optional) (default to false)
show_pantherid = false # bool |  (optional) (default to false)
show_pirsfid = false # bool |  (optional) (default to false)
show_pmid = false # bool |  (optional) (default to false)
show_reactome_id = false # bool |  (optional) (default to false)
show_synonym = false # bool |  (optional) (default to false)
show_uni_prot_kbid = false # bool |  (optional) (default to false)
offset = 0 # int | The number of items to skip before starting to collect the result set. (optional) (default to 0)
limit = 50 # int | The numbers of items to return. (optional) (default to 50)

try:
    # Returns a list of PRO terms with EcoCyC ID as cross-reference.
    api_response = api_instance.get_pro_terms_with_eco_cy_c_id(search_field=search_field, search_value=search_value, show_pro_name=show_pro_name, show_pro_term_definition=show_pro_term_definition, show_category=show_category, show_eco_cyc_id=show_eco_cyc_id, show_annotation=show_annotation, show_any_relationship=show_any_relationship, show_child=show_child, show_comment=show_comment, show_gene_name=show_gene_name, show_hgncid=show_hgncid, show_mgiid=show_mgiid, show_ortho_isoform=show_ortho_isoform, show_ortho_modified_form=show_ortho_modified_form, show_pantherid=show_pantherid, show_pirsfid=show_pirsfid, show_pmid=show_pmid, show_reactome_id=show_reactome_id, show_synonym=show_synonym, show_uni_prot_kbid=show_uni_prot_kbid, offset=offset, limit=limit)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DatabaseCrossReferencesApi->get_pro_terms_with_eco_cy_c_id: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search_field** | **str**| Search field that needs to be considered for filter | [optional] 
 **search_value** | **str**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **show_pro_name** | **bool**|  | [optional] [default to true]
 **show_pro_term_definition** | **bool**|  | [optional] [default to true]
 **show_category** | **bool**|  | [optional] [default to true]
 **show_eco_cyc_id** | **bool**|  | [optional] [default to true]
 **show_annotation** | **bool**|  | [optional] [default to false]
 **show_any_relationship** | **bool**|  | [optional] [default to false]
 **show_child** | **bool**|  | [optional] [default to false]
 **show_comment** | **bool**|  | [optional] [default to false]
 **show_gene_name** | **bool**|  | [optional] [default to false]
 **show_hgncid** | **bool**|  | [optional] [default to false]
 **show_mgiid** | **bool**|  | [optional] [default to false]
 **show_ortho_isoform** | **bool**|  | [optional] [default to false]
 **show_ortho_modified_form** | **bool**|  | [optional] [default to false]
 **show_pantherid** | **bool**|  | [optional] [default to false]
 **show_pirsfid** | **bool**|  | [optional] [default to false]
 **show_pmid** | **bool**|  | [optional] [default to false]
 **show_reactome_id** | **bool**|  | [optional] [default to false]
 **show_synonym** | **bool**|  | [optional] [default to false]
 **show_uni_prot_kbid** | **bool**|  | [optional] [default to false]
 **offset** | **int**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**list[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_pro_terms_with_hgnc_id**
> list[PROTerm] get_pro_terms_with_hgnc_id(search_field=search_field, search_value=search_value, show_pro_name=show_pro_name, show_pro_term_definition=show_pro_term_definition, show_category=show_category, show_parent=show_parent, show_hgncid=show_hgncid, show_annotation=show_annotation, show_any_relationship=show_any_relationship, show_child=show_child, show_comment=show_comment, show_eco_cyc_id=show_eco_cyc_id, show_gene_name=show_gene_name, show_mgiid=show_mgiid, show_ortho_isoform=show_ortho_isoform, show_ortho_modified_form=show_ortho_modified_form, show_pantherid=show_pantherid, show_pirsfid=show_pirsfid, show_pmid=show_pmid, show_reactome_id=show_reactome_id, show_synonym=show_synonym, show_uni_prot_kbid=show_uni_prot_kbid, offset=offset, limit=limit)

Returns a list of PRO terms with HGNC ID as cross-reference.

Gets a list of PRO terms with HGNC ID as cross-reference and associated information.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DatabaseCrossReferencesApi()
search_field = 'search_field_example' # str | Search field that needs to be considered for filter (optional)
search_value = 'search_value_example' # str | any string or \"null\" or \"not null\" or a list of space separated ids (optional)
show_pro_name = true # bool |  (optional) (default to true)
show_pro_term_definition = true # bool |  (optional) (default to true)
show_category = true # bool |  (optional) (default to true)
show_parent = true # bool |  (optional) (default to true)
show_hgncid = true # bool |  (optional) (default to true)
show_annotation = false # bool |  (optional) (default to false)
show_any_relationship = false # bool |  (optional) (default to false)
show_child = false # bool |  (optional) (default to false)
show_comment = false # bool |  (optional) (default to false)
show_eco_cyc_id = false # bool |  (optional) (default to false)
show_gene_name = false # bool |  (optional) (default to false)
show_mgiid = false # bool |  (optional) (default to false)
show_ortho_isoform = false # bool |  (optional) (default to false)
show_ortho_modified_form = false # bool |  (optional) (default to false)
show_pantherid = false # bool |  (optional) (default to false)
show_pirsfid = false # bool |  (optional) (default to false)
show_pmid = false # bool |  (optional) (default to false)
show_reactome_id = false # bool |  (optional) (default to false)
show_synonym = false # bool |  (optional) (default to false)
show_uni_prot_kbid = false # bool |  (optional) (default to false)
offset = 0 # int | The number of items to skip before starting to collect the result set. (optional) (default to 0)
limit = 50 # int | The numbers of items to return. (optional) (default to 50)

try:
    # Returns a list of PRO terms with HGNC ID as cross-reference.
    api_response = api_instance.get_pro_terms_with_hgnc_id(search_field=search_field, search_value=search_value, show_pro_name=show_pro_name, show_pro_term_definition=show_pro_term_definition, show_category=show_category, show_parent=show_parent, show_hgncid=show_hgncid, show_annotation=show_annotation, show_any_relationship=show_any_relationship, show_child=show_child, show_comment=show_comment, show_eco_cyc_id=show_eco_cyc_id, show_gene_name=show_gene_name, show_mgiid=show_mgiid, show_ortho_isoform=show_ortho_isoform, show_ortho_modified_form=show_ortho_modified_form, show_pantherid=show_pantherid, show_pirsfid=show_pirsfid, show_pmid=show_pmid, show_reactome_id=show_reactome_id, show_synonym=show_synonym, show_uni_prot_kbid=show_uni_prot_kbid, offset=offset, limit=limit)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DatabaseCrossReferencesApi->get_pro_terms_with_hgnc_id: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search_field** | **str**| Search field that needs to be considered for filter | [optional] 
 **search_value** | **str**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **show_pro_name** | **bool**|  | [optional] [default to true]
 **show_pro_term_definition** | **bool**|  | [optional] [default to true]
 **show_category** | **bool**|  | [optional] [default to true]
 **show_parent** | **bool**|  | [optional] [default to true]
 **show_hgncid** | **bool**|  | [optional] [default to true]
 **show_annotation** | **bool**|  | [optional] [default to false]
 **show_any_relationship** | **bool**|  | [optional] [default to false]
 **show_child** | **bool**|  | [optional] [default to false]
 **show_comment** | **bool**|  | [optional] [default to false]
 **show_eco_cyc_id** | **bool**|  | [optional] [default to false]
 **show_gene_name** | **bool**|  | [optional] [default to false]
 **show_mgiid** | **bool**|  | [optional] [default to false]
 **show_ortho_isoform** | **bool**|  | [optional] [default to false]
 **show_ortho_modified_form** | **bool**|  | [optional] [default to false]
 **show_pantherid** | **bool**|  | [optional] [default to false]
 **show_pirsfid** | **bool**|  | [optional] [default to false]
 **show_pmid** | **bool**|  | [optional] [default to false]
 **show_reactome_id** | **bool**|  | [optional] [default to false]
 **show_synonym** | **bool**|  | [optional] [default to false]
 **show_uni_prot_kbid** | **bool**|  | [optional] [default to false]
 **offset** | **int**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**list[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_pro_terms_with_mgi_id**
> list[PROTerm] get_pro_terms_with_mgi_id(search_field=search_field, search_value=search_value, show_pro_name=show_pro_name, show_pro_term_definition=show_pro_term_definition, show_category=show_category, show_parent=show_parent, show_mgiid=show_mgiid, show_annotation=show_annotation, show_any_relationship=show_any_relationship, show_child=show_child, show_comment=show_comment, show_eco_cyc_id=show_eco_cyc_id, show_gene_name=show_gene_name, show_hgncid=show_hgncid, show_ortho_isoform=show_ortho_isoform, show_ortho_modified_form=show_ortho_modified_form, show_pantherid=show_pantherid, show_pirsfid=show_pirsfid, show_pmid=show_pmid, show_reactome_id=show_reactome_id, show_synonym=show_synonym, show_uni_prot_kbid=show_uni_prot_kbid, offset=offset, limit=limit)

Returns a list of PRO terms with MGI ID as cross-reference.

Gets a list of PRO terms with MGI ID as cross-reference and associated information.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DatabaseCrossReferencesApi()
search_field = 'search_field_example' # str | Search field that needs to be considered for filter (optional)
search_value = 'search_value_example' # str | any string or \"null\" or \"not null\" or a list of space separated ids (optional)
show_pro_name = true # bool |  (optional) (default to true)
show_pro_term_definition = true # bool |  (optional) (default to true)
show_category = true # bool |  (optional) (default to true)
show_parent = true # bool |  (optional) (default to true)
show_mgiid = true # bool |  (optional) (default to true)
show_annotation = false # bool |  (optional) (default to false)
show_any_relationship = false # bool |  (optional) (default to false)
show_child = false # bool |  (optional) (default to false)
show_comment = false # bool |  (optional) (default to false)
show_eco_cyc_id = false # bool |  (optional) (default to false)
show_gene_name = false # bool |  (optional) (default to false)
show_hgncid = false # bool |  (optional) (default to false)
show_ortho_isoform = false # bool |  (optional) (default to false)
show_ortho_modified_form = false # bool |  (optional) (default to false)
show_pantherid = false # bool |  (optional) (default to false)
show_pirsfid = false # bool |  (optional) (default to false)
show_pmid = false # bool |  (optional) (default to false)
show_reactome_id = false # bool |  (optional) (default to false)
show_synonym = false # bool |  (optional) (default to false)
show_uni_prot_kbid = false # bool |  (optional) (default to false)
offset = 0 # int | The number of items to skip before starting to collect the result set. (optional) (default to 0)
limit = 50 # int | The numbers of items to return. (optional) (default to 50)

try:
    # Returns a list of PRO terms with MGI ID as cross-reference.
    api_response = api_instance.get_pro_terms_with_mgi_id(search_field=search_field, search_value=search_value, show_pro_name=show_pro_name, show_pro_term_definition=show_pro_term_definition, show_category=show_category, show_parent=show_parent, show_mgiid=show_mgiid, show_annotation=show_annotation, show_any_relationship=show_any_relationship, show_child=show_child, show_comment=show_comment, show_eco_cyc_id=show_eco_cyc_id, show_gene_name=show_gene_name, show_hgncid=show_hgncid, show_ortho_isoform=show_ortho_isoform, show_ortho_modified_form=show_ortho_modified_form, show_pantherid=show_pantherid, show_pirsfid=show_pirsfid, show_pmid=show_pmid, show_reactome_id=show_reactome_id, show_synonym=show_synonym, show_uni_prot_kbid=show_uni_prot_kbid, offset=offset, limit=limit)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DatabaseCrossReferencesApi->get_pro_terms_with_mgi_id: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search_field** | **str**| Search field that needs to be considered for filter | [optional] 
 **search_value** | **str**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **show_pro_name** | **bool**|  | [optional] [default to true]
 **show_pro_term_definition** | **bool**|  | [optional] [default to true]
 **show_category** | **bool**|  | [optional] [default to true]
 **show_parent** | **bool**|  | [optional] [default to true]
 **show_mgiid** | **bool**|  | [optional] [default to true]
 **show_annotation** | **bool**|  | [optional] [default to false]
 **show_any_relationship** | **bool**|  | [optional] [default to false]
 **show_child** | **bool**|  | [optional] [default to false]
 **show_comment** | **bool**|  | [optional] [default to false]
 **show_eco_cyc_id** | **bool**|  | [optional] [default to false]
 **show_gene_name** | **bool**|  | [optional] [default to false]
 **show_hgncid** | **bool**|  | [optional] [default to false]
 **show_ortho_isoform** | **bool**|  | [optional] [default to false]
 **show_ortho_modified_form** | **bool**|  | [optional] [default to false]
 **show_pantherid** | **bool**|  | [optional] [default to false]
 **show_pirsfid** | **bool**|  | [optional] [default to false]
 **show_pmid** | **bool**|  | [optional] [default to false]
 **show_reactome_id** | **bool**|  | [optional] [default to false]
 **show_synonym** | **bool**|  | [optional] [default to false]
 **show_uni_prot_kbid** | **bool**|  | [optional] [default to false]
 **offset** | **int**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**list[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_pro_terms_with_ncbi_taxon_id**
> list[PROTerm] get_pro_terms_with_ncbi_taxon_id(search_field=search_field, search_value=search_value, show_pro_name=show_pro_name, show_pro_term_definition=show_pro_term_definition, show_category=show_category, show_parent=show_parent, show_annotation=show_annotation, show_any_relationship=show_any_relationship, show_child=show_child, show_comment=show_comment, show_eco_cyc_id=show_eco_cyc_id, show_gene_name=show_gene_name, show_hgncid=show_hgncid, show_mgiid=show_mgiid, show_ortho_isoform=show_ortho_isoform, show_ortho_modified_form=show_ortho_modified_form, show_pantherid=show_pantherid, show_pirsfid=show_pirsfid, show_pmid=show_pmid, show_reactome_id=show_reactome_id, show_uni_prot_kbid=show_uni_prot_kbid, offset=offset, limit=limit)

Returns a list of PRO terms with NCBI Taxon ID as cross-reference.

Gets a list of PRO terms with NCBI Taxon ID as cross-reference and associated information.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DatabaseCrossReferencesApi()
search_field = 'search_field_example' # str | Search field that needs to be considered for filter (optional)
search_value = 'search_value_example' # str | any string or \"null\" or \"not null\" or a list of space separated ids (optional)
show_pro_name = true # bool |  (optional) (default to true)
show_pro_term_definition = true # bool |  (optional) (default to true)
show_category = true # bool |  (optional) (default to true)
show_parent = true # bool |  (optional) (default to true)
show_annotation = true # bool |  (optional) (default to true)
show_any_relationship = false # bool |  (optional) (default to false)
show_child = false # bool |  (optional) (default to false)
show_comment = false # bool |  (optional) (default to false)
show_eco_cyc_id = false # bool |  (optional) (default to false)
show_gene_name = false # bool |  (optional) (default to false)
show_hgncid = false # bool |  (optional) (default to false)
show_mgiid = false # bool |  (optional) (default to false)
show_ortho_isoform = false # bool |  (optional) (default to false)
show_ortho_modified_form = false # bool |  (optional) (default to false)
show_pantherid = false # bool |  (optional) (default to false)
show_pirsfid = false # bool |  (optional) (default to false)
show_pmid = false # bool |  (optional) (default to false)
show_reactome_id = false # bool |  (optional) (default to false)
show_uni_prot_kbid = false # bool |  (optional) (default to false)
offset = 0 # int | The number of items to skip before starting to collect the result set. (optional) (default to 0)
limit = 50 # int | The numbers of items to return. (optional) (default to 50)

try:
    # Returns a list of PRO terms with NCBI Taxon ID as cross-reference.
    api_response = api_instance.get_pro_terms_with_ncbi_taxon_id(search_field=search_field, search_value=search_value, show_pro_name=show_pro_name, show_pro_term_definition=show_pro_term_definition, show_category=show_category, show_parent=show_parent, show_annotation=show_annotation, show_any_relationship=show_any_relationship, show_child=show_child, show_comment=show_comment, show_eco_cyc_id=show_eco_cyc_id, show_gene_name=show_gene_name, show_hgncid=show_hgncid, show_mgiid=show_mgiid, show_ortho_isoform=show_ortho_isoform, show_ortho_modified_form=show_ortho_modified_form, show_pantherid=show_pantherid, show_pirsfid=show_pirsfid, show_pmid=show_pmid, show_reactome_id=show_reactome_id, show_uni_prot_kbid=show_uni_prot_kbid, offset=offset, limit=limit)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DatabaseCrossReferencesApi->get_pro_terms_with_ncbi_taxon_id: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search_field** | **str**| Search field that needs to be considered for filter | [optional] 
 **search_value** | **str**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **show_pro_name** | **bool**|  | [optional] [default to true]
 **show_pro_term_definition** | **bool**|  | [optional] [default to true]
 **show_category** | **bool**|  | [optional] [default to true]
 **show_parent** | **bool**|  | [optional] [default to true]
 **show_annotation** | **bool**|  | [optional] [default to true]
 **show_any_relationship** | **bool**|  | [optional] [default to false]
 **show_child** | **bool**|  | [optional] [default to false]
 **show_comment** | **bool**|  | [optional] [default to false]
 **show_eco_cyc_id** | **bool**|  | [optional] [default to false]
 **show_gene_name** | **bool**|  | [optional] [default to false]
 **show_hgncid** | **bool**|  | [optional] [default to false]
 **show_mgiid** | **bool**|  | [optional] [default to false]
 **show_ortho_isoform** | **bool**|  | [optional] [default to false]
 **show_ortho_modified_form** | **bool**|  | [optional] [default to false]
 **show_pantherid** | **bool**|  | [optional] [default to false]
 **show_pirsfid** | **bool**|  | [optional] [default to false]
 **show_pmid** | **bool**|  | [optional] [default to false]
 **show_reactome_id** | **bool**|  | [optional] [default to false]
 **show_uni_prot_kbid** | **bool**|  | [optional] [default to false]
 **offset** | **int**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**list[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_pro_terms_with_ontology_id**
> list[PROTerm] get_pro_terms_with_ontology_id(search_field=search_field, search_value=search_value, show_pro_name=show_pro_name, show_pro_term_definition=show_pro_term_definition, show_category=show_category, show_parent=show_parent, show_annotation=show_annotation, show_any_relationship=show_any_relationship, show_child=show_child, show_comment=show_comment, show_eco_cyc_id=show_eco_cyc_id, show_gene_name=show_gene_name, show_hgncid=show_hgncid, show_mgiid=show_mgiid, show_ortho_isoform=show_ortho_isoform, show_ortho_modified_form=show_ortho_modified_form, show_pantherid=show_pantherid, show_pirsfid=show_pirsfid, show_pmid=show_pmid, show_reactome_id=show_reactome_id, show_synonym=show_synonym, show_uni_prot_kbid=show_uni_prot_kbid, offset=offset, limit=limit)

Returns a list of PRO terms with Ontology ID as cross-reference.

Gets a list of PRO terms with Ontology ID as cross-reference and associated information.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DatabaseCrossReferencesApi()
search_field = 'search_field_example' # str | Search field that needs to be considered for filter (optional)
search_value = 'search_value_example' # str | any string or \"null\" or \"not null\" or a list of space separated ids (optional)
show_pro_name = true # bool |  (optional) (default to true)
show_pro_term_definition = true # bool |  (optional) (default to true)
show_category = true # bool |  (optional) (default to true)
show_parent = true # bool |  (optional) (default to true)
show_annotation = true # bool |  (optional) (default to true)
show_any_relationship = false # bool |  (optional) (default to false)
show_child = false # bool |  (optional) (default to false)
show_comment = false # bool |  (optional) (default to false)
show_eco_cyc_id = false # bool |  (optional) (default to false)
show_gene_name = false # bool |  (optional) (default to false)
show_hgncid = false # bool |  (optional) (default to false)
show_mgiid = false # bool |  (optional) (default to false)
show_ortho_isoform = false # bool |  (optional) (default to false)
show_ortho_modified_form = false # bool |  (optional) (default to false)
show_pantherid = false # bool |  (optional) (default to false)
show_pirsfid = false # bool |  (optional) (default to false)
show_pmid = false # bool |  (optional) (default to false)
show_reactome_id = false # bool |  (optional) (default to false)
show_synonym = false # bool |  (optional) (default to false)
show_uni_prot_kbid = false # bool |  (optional) (default to false)
offset = 0 # int | The number of items to skip before starting to collect the result set. (optional) (default to 0)
limit = 50 # int | The numbers of items to return. (optional) (default to 50)

try:
    # Returns a list of PRO terms with Ontology ID as cross-reference.
    api_response = api_instance.get_pro_terms_with_ontology_id(search_field=search_field, search_value=search_value, show_pro_name=show_pro_name, show_pro_term_definition=show_pro_term_definition, show_category=show_category, show_parent=show_parent, show_annotation=show_annotation, show_any_relationship=show_any_relationship, show_child=show_child, show_comment=show_comment, show_eco_cyc_id=show_eco_cyc_id, show_gene_name=show_gene_name, show_hgncid=show_hgncid, show_mgiid=show_mgiid, show_ortho_isoform=show_ortho_isoform, show_ortho_modified_form=show_ortho_modified_form, show_pantherid=show_pantherid, show_pirsfid=show_pirsfid, show_pmid=show_pmid, show_reactome_id=show_reactome_id, show_synonym=show_synonym, show_uni_prot_kbid=show_uni_prot_kbid, offset=offset, limit=limit)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DatabaseCrossReferencesApi->get_pro_terms_with_ontology_id: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search_field** | **str**| Search field that needs to be considered for filter | [optional] 
 **search_value** | **str**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **show_pro_name** | **bool**|  | [optional] [default to true]
 **show_pro_term_definition** | **bool**|  | [optional] [default to true]
 **show_category** | **bool**|  | [optional] [default to true]
 **show_parent** | **bool**|  | [optional] [default to true]
 **show_annotation** | **bool**|  | [optional] [default to true]
 **show_any_relationship** | **bool**|  | [optional] [default to false]
 **show_child** | **bool**|  | [optional] [default to false]
 **show_comment** | **bool**|  | [optional] [default to false]
 **show_eco_cyc_id** | **bool**|  | [optional] [default to false]
 **show_gene_name** | **bool**|  | [optional] [default to false]
 **show_hgncid** | **bool**|  | [optional] [default to false]
 **show_mgiid** | **bool**|  | [optional] [default to false]
 **show_ortho_isoform** | **bool**|  | [optional] [default to false]
 **show_ortho_modified_form** | **bool**|  | [optional] [default to false]
 **show_pantherid** | **bool**|  | [optional] [default to false]
 **show_pirsfid** | **bool**|  | [optional] [default to false]
 **show_pmid** | **bool**|  | [optional] [default to false]
 **show_reactome_id** | **bool**|  | [optional] [default to false]
 **show_synonym** | **bool**|  | [optional] [default to false]
 **show_uni_prot_kbid** | **bool**|  | [optional] [default to false]
 **offset** | **int**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**list[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_pro_terms_with_panther_id**
> list[PROTerm] get_pro_terms_with_panther_id(search_field=search_field, search_value=search_value, show_pro_name=show_pro_name, show_pro_term_definition=show_pro_term_definition, show_category=show_category, show_parent=show_parent, show_pantherid=show_pantherid, show_annotation=show_annotation, show_any_relationship=show_any_relationship, show_child=show_child, show_comment=show_comment, show_eco_cyc_id=show_eco_cyc_id, show_gene_name=show_gene_name, show_hgncid=show_hgncid, show_mgiid=show_mgiid, show_ortho_isoform=show_ortho_isoform, show_ortho_modified_form=show_ortho_modified_form, show_pirsfid=show_pirsfid, show_pmid=show_pmid, show_reactome_id=show_reactome_id, show_synonym=show_synonym, show_uni_prot_kbid=show_uni_prot_kbid, offset=offset, limit=limit)

Returns a list of PRO terms with PANTHER ID as cross-reference.

Gets a list of PRO terms with PANTHER ID as cross-reference and associated information.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DatabaseCrossReferencesApi()
search_field = 'search_field_example' # str | Search field that needs to be considered for filter (optional)
search_value = 'search_value_example' # str | any string or \"null\" or \"not null\" or a list of space separated ids (optional)
show_pro_name = true # bool |  (optional) (default to true)
show_pro_term_definition = true # bool |  (optional) (default to true)
show_category = true # bool |  (optional) (default to true)
show_parent = true # bool |  (optional) (default to true)
show_pantherid = true # bool |  (optional) (default to true)
show_annotation = false # bool |  (optional) (default to false)
show_any_relationship = false # bool |  (optional) (default to false)
show_child = false # bool |  (optional) (default to false)
show_comment = false # bool |  (optional) (default to false)
show_eco_cyc_id = false # bool |  (optional) (default to false)
show_gene_name = false # bool |  (optional) (default to false)
show_hgncid = false # bool |  (optional) (default to false)
show_mgiid = false # bool |  (optional) (default to false)
show_ortho_isoform = false # bool |  (optional) (default to false)
show_ortho_modified_form = false # bool |  (optional) (default to false)
show_pirsfid = false # bool |  (optional) (default to false)
show_pmid = false # bool |  (optional) (default to false)
show_reactome_id = false # bool |  (optional) (default to false)
show_synonym = false # bool |  (optional) (default to false)
show_uni_prot_kbid = false # bool |  (optional) (default to false)
offset = 0 # int | The number of items to skip before starting to collect the result set. (optional) (default to 0)
limit = 50 # int | The numbers of items to return. (optional) (default to 50)

try:
    # Returns a list of PRO terms with PANTHER ID as cross-reference.
    api_response = api_instance.get_pro_terms_with_panther_id(search_field=search_field, search_value=search_value, show_pro_name=show_pro_name, show_pro_term_definition=show_pro_term_definition, show_category=show_category, show_parent=show_parent, show_pantherid=show_pantherid, show_annotation=show_annotation, show_any_relationship=show_any_relationship, show_child=show_child, show_comment=show_comment, show_eco_cyc_id=show_eco_cyc_id, show_gene_name=show_gene_name, show_hgncid=show_hgncid, show_mgiid=show_mgiid, show_ortho_isoform=show_ortho_isoform, show_ortho_modified_form=show_ortho_modified_form, show_pirsfid=show_pirsfid, show_pmid=show_pmid, show_reactome_id=show_reactome_id, show_synonym=show_synonym, show_uni_prot_kbid=show_uni_prot_kbid, offset=offset, limit=limit)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DatabaseCrossReferencesApi->get_pro_terms_with_panther_id: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search_field** | **str**| Search field that needs to be considered for filter | [optional] 
 **search_value** | **str**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **show_pro_name** | **bool**|  | [optional] [default to true]
 **show_pro_term_definition** | **bool**|  | [optional] [default to true]
 **show_category** | **bool**|  | [optional] [default to true]
 **show_parent** | **bool**|  | [optional] [default to true]
 **show_pantherid** | **bool**|  | [optional] [default to true]
 **show_annotation** | **bool**|  | [optional] [default to false]
 **show_any_relationship** | **bool**|  | [optional] [default to false]
 **show_child** | **bool**|  | [optional] [default to false]
 **show_comment** | **bool**|  | [optional] [default to false]
 **show_eco_cyc_id** | **bool**|  | [optional] [default to false]
 **show_gene_name** | **bool**|  | [optional] [default to false]
 **show_hgncid** | **bool**|  | [optional] [default to false]
 **show_mgiid** | **bool**|  | [optional] [default to false]
 **show_ortho_isoform** | **bool**|  | [optional] [default to false]
 **show_ortho_modified_form** | **bool**|  | [optional] [default to false]
 **show_pirsfid** | **bool**|  | [optional] [default to false]
 **show_pmid** | **bool**|  | [optional] [default to false]
 **show_reactome_id** | **bool**|  | [optional] [default to false]
 **show_synonym** | **bool**|  | [optional] [default to false]
 **show_uni_prot_kbid** | **bool**|  | [optional] [default to false]
 **offset** | **int**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**list[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_pro_terms_with_pirsf_id**
> list[PROTerm] get_pro_terms_with_pirsf_id(search_field=search_field, search_value=search_value, show_pro_name=show_pro_name, show_pro_term_definition=show_pro_term_definition, show_category=show_category, show_parent=show_parent, show_pirsfid=show_pirsfid, show_annotation=show_annotation, show_any_relationship=show_any_relationship, show_child=show_child, show_comment=show_comment, show_eco_cyc_id=show_eco_cyc_id, show_gene_name=show_gene_name, show_hgncid=show_hgncid, show_mgiid=show_mgiid, show_ortho_isoform=show_ortho_isoform, show_ortho_modified_form=show_ortho_modified_form, show_pantherid=show_pantherid, show_pmid=show_pmid, show_reactome_id=show_reactome_id, show_synonym=show_synonym, show_uni_prot_kbid=show_uni_prot_kbid, offset=offset, limit=limit)

Returns a list of PRO terms with PIRSF ID as cross-reference.

Gets a list of PRO terms with PIRSF ID as cross-reference and associated information.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DatabaseCrossReferencesApi()
search_field = 'search_field_example' # str | Search field that needs to be considered for filter (optional)
search_value = 'search_value_example' # str | any string or \"null\" or \"not null\" or a list of space separated ids (optional)
show_pro_name = true # bool |  (optional) (default to true)
show_pro_term_definition = true # bool |  (optional) (default to true)
show_category = true # bool |  (optional) (default to true)
show_parent = true # bool |  (optional) (default to true)
show_pirsfid = true # bool |  (optional) (default to true)
show_annotation = false # bool |  (optional) (default to false)
show_any_relationship = false # bool |  (optional) (default to false)
show_child = false # bool |  (optional) (default to false)
show_comment = false # bool |  (optional) (default to false)
show_eco_cyc_id = false # bool |  (optional) (default to false)
show_gene_name = false # bool |  (optional) (default to false)
show_hgncid = false # bool |  (optional) (default to false)
show_mgiid = false # bool |  (optional) (default to false)
show_ortho_isoform = false # bool |  (optional) (default to false)
show_ortho_modified_form = false # bool |  (optional) (default to false)
show_pantherid = false # bool |  (optional) (default to false)
show_pmid = false # bool |  (optional) (default to false)
show_reactome_id = false # bool |  (optional) (default to false)
show_synonym = false # bool |  (optional) (default to false)
show_uni_prot_kbid = false # bool |  (optional) (default to false)
offset = 0 # int | The number of items to skip before starting to collect the result set. (optional) (default to 0)
limit = 50 # int | The numbers of items to return. (optional) (default to 50)

try:
    # Returns a list of PRO terms with PIRSF ID as cross-reference.
    api_response = api_instance.get_pro_terms_with_pirsf_id(search_field=search_field, search_value=search_value, show_pro_name=show_pro_name, show_pro_term_definition=show_pro_term_definition, show_category=show_category, show_parent=show_parent, show_pirsfid=show_pirsfid, show_annotation=show_annotation, show_any_relationship=show_any_relationship, show_child=show_child, show_comment=show_comment, show_eco_cyc_id=show_eco_cyc_id, show_gene_name=show_gene_name, show_hgncid=show_hgncid, show_mgiid=show_mgiid, show_ortho_isoform=show_ortho_isoform, show_ortho_modified_form=show_ortho_modified_form, show_pantherid=show_pantherid, show_pmid=show_pmid, show_reactome_id=show_reactome_id, show_synonym=show_synonym, show_uni_prot_kbid=show_uni_prot_kbid, offset=offset, limit=limit)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DatabaseCrossReferencesApi->get_pro_terms_with_pirsf_id: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search_field** | **str**| Search field that needs to be considered for filter | [optional] 
 **search_value** | **str**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **show_pro_name** | **bool**|  | [optional] [default to true]
 **show_pro_term_definition** | **bool**|  | [optional] [default to true]
 **show_category** | **bool**|  | [optional] [default to true]
 **show_parent** | **bool**|  | [optional] [default to true]
 **show_pirsfid** | **bool**|  | [optional] [default to true]
 **show_annotation** | **bool**|  | [optional] [default to false]
 **show_any_relationship** | **bool**|  | [optional] [default to false]
 **show_child** | **bool**|  | [optional] [default to false]
 **show_comment** | **bool**|  | [optional] [default to false]
 **show_eco_cyc_id** | **bool**|  | [optional] [default to false]
 **show_gene_name** | **bool**|  | [optional] [default to false]
 **show_hgncid** | **bool**|  | [optional] [default to false]
 **show_mgiid** | **bool**|  | [optional] [default to false]
 **show_ortho_isoform** | **bool**|  | [optional] [default to false]
 **show_ortho_modified_form** | **bool**|  | [optional] [default to false]
 **show_pantherid** | **bool**|  | [optional] [default to false]
 **show_pmid** | **bool**|  | [optional] [default to false]
 **show_reactome_id** | **bool**|  | [optional] [default to false]
 **show_synonym** | **bool**|  | [optional] [default to false]
 **show_uni_prot_kbid** | **bool**|  | [optional] [default to false]
 **offset** | **int**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**list[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_pro_terms_with_pmid**
> list[PROTerm] get_pro_terms_with_pmid(search_field=search_field, search_value=search_value, show_pro_name=show_pro_name, show_pro_term_definition=show_pro_term_definition, show_category=show_category, show_parent=show_parent, show_pmid=show_pmid, show_annotation=show_annotation, show_any_relationship=show_any_relationship, show_child=show_child, show_comment=show_comment, show_eco_cyc_id=show_eco_cyc_id, show_gene_name=show_gene_name, show_hgncid=show_hgncid, show_mgiid=show_mgiid, show_ortho_isoform=show_ortho_isoform, show_ortho_modified_form=show_ortho_modified_form, show_pantherid=show_pantherid, show_pirsfid=show_pirsfid, show_reactome_id=show_reactome_id, show_synonym=show_synonym, show_uni_prot_kbid=show_uni_prot_kbid, offset=offset, limit=limit)

Returns a list of PRO terms with PMID as cross-reference.

Gets a list of PRO terms with PMID as cross-reference and associated information.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DatabaseCrossReferencesApi()
search_field = 'search_field_example' # str | Search field that needs to be considered for filter (optional)
search_value = 'search_value_example' # str | any string or \"null\" or \"not null\" or a list of space separated ids (optional)
show_pro_name = true # bool |  (optional) (default to true)
show_pro_term_definition = true # bool |  (optional) (default to true)
show_category = true # bool |  (optional) (default to true)
show_parent = true # bool |  (optional) (default to true)
show_pmid = true # bool |  (optional) (default to true)
show_annotation = false # bool |  (optional) (default to false)
show_any_relationship = false # bool |  (optional) (default to false)
show_child = false # bool |  (optional) (default to false)
show_comment = false # bool |  (optional) (default to false)
show_eco_cyc_id = false # bool |  (optional) (default to false)
show_gene_name = false # bool |  (optional) (default to false)
show_hgncid = false # bool |  (optional) (default to false)
show_mgiid = false # bool |  (optional) (default to false)
show_ortho_isoform = false # bool |  (optional) (default to false)
show_ortho_modified_form = false # bool |  (optional) (default to false)
show_pantherid = false # bool |  (optional) (default to false)
show_pirsfid = false # bool |  (optional) (default to false)
show_reactome_id = false # bool |  (optional) (default to false)
show_synonym = false # bool |  (optional) (default to false)
show_uni_prot_kbid = false # bool |  (optional) (default to false)
offset = 0 # int | The number of items to skip before starting to collect the result set. (optional) (default to 0)
limit = 50 # int | The numbers of items to return. (optional) (default to 50)

try:
    # Returns a list of PRO terms with PMID as cross-reference.
    api_response = api_instance.get_pro_terms_with_pmid(search_field=search_field, search_value=search_value, show_pro_name=show_pro_name, show_pro_term_definition=show_pro_term_definition, show_category=show_category, show_parent=show_parent, show_pmid=show_pmid, show_annotation=show_annotation, show_any_relationship=show_any_relationship, show_child=show_child, show_comment=show_comment, show_eco_cyc_id=show_eco_cyc_id, show_gene_name=show_gene_name, show_hgncid=show_hgncid, show_mgiid=show_mgiid, show_ortho_isoform=show_ortho_isoform, show_ortho_modified_form=show_ortho_modified_form, show_pantherid=show_pantherid, show_pirsfid=show_pirsfid, show_reactome_id=show_reactome_id, show_synonym=show_synonym, show_uni_prot_kbid=show_uni_prot_kbid, offset=offset, limit=limit)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DatabaseCrossReferencesApi->get_pro_terms_with_pmid: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search_field** | **str**| Search field that needs to be considered for filter | [optional] 
 **search_value** | **str**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **show_pro_name** | **bool**|  | [optional] [default to true]
 **show_pro_term_definition** | **bool**|  | [optional] [default to true]
 **show_category** | **bool**|  | [optional] [default to true]
 **show_parent** | **bool**|  | [optional] [default to true]
 **show_pmid** | **bool**|  | [optional] [default to true]
 **show_annotation** | **bool**|  | [optional] [default to false]
 **show_any_relationship** | **bool**|  | [optional] [default to false]
 **show_child** | **bool**|  | [optional] [default to false]
 **show_comment** | **bool**|  | [optional] [default to false]
 **show_eco_cyc_id** | **bool**|  | [optional] [default to false]
 **show_gene_name** | **bool**|  | [optional] [default to false]
 **show_hgncid** | **bool**|  | [optional] [default to false]
 **show_mgiid** | **bool**|  | [optional] [default to false]
 **show_ortho_isoform** | **bool**|  | [optional] [default to false]
 **show_ortho_modified_form** | **bool**|  | [optional] [default to false]
 **show_pantherid** | **bool**|  | [optional] [default to false]
 **show_pirsfid** | **bool**|  | [optional] [default to false]
 **show_reactome_id** | **bool**|  | [optional] [default to false]
 **show_synonym** | **bool**|  | [optional] [default to false]
 **show_uni_prot_kbid** | **bool**|  | [optional] [default to false]
 **offset** | **int**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**list[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_pro_terms_with_reactome_id**
> list[PROTerm] get_pro_terms_with_reactome_id(search_field=search_field, search_value=search_value, show_pro_name=show_pro_name, show_pro_term_definition=show_pro_term_definition, show_category=show_category, show_parent=show_parent, show_reactome_id=show_reactome_id, show_annotation=show_annotation, show_any_relationship=show_any_relationship, show_child=show_child, show_comment=show_comment, show_eco_cyc_id=show_eco_cyc_id, show_gene_name=show_gene_name, show_hgncid=show_hgncid, show_mgiid=show_mgiid, show_ortho_isoform=show_ortho_isoform, show_ortho_modified_form=show_ortho_modified_form, show_pantherid=show_pantherid, show_pirsfid=show_pirsfid, show_pmid=show_pmid, show_uni_prot_kbid=show_uni_prot_kbid, offset=offset, limit=limit)

Returns a list of PRO terms with Reactome ID as cross-reference.

Gets a list of PRO terms with Reactome ID as cross-reference and associated information.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DatabaseCrossReferencesApi()
search_field = 'search_field_example' # str | Search field that needs to be considered for filter (optional)
search_value = 'search_value_example' # str | any string or \"null\" or \"not null\" or a list of space separated ids (optional)
show_pro_name = true # bool |  (optional) (default to true)
show_pro_term_definition = true # bool |  (optional) (default to true)
show_category = true # bool |  (optional) (default to true)
show_parent = true # bool |  (optional) (default to true)
show_reactome_id = true # bool |  (optional) (default to true)
show_annotation = false # bool |  (optional) (default to false)
show_any_relationship = false # bool |  (optional) (default to false)
show_child = false # bool |  (optional) (default to false)
show_comment = false # bool |  (optional) (default to false)
show_eco_cyc_id = false # bool |  (optional) (default to false)
show_gene_name = false # bool |  (optional) (default to false)
show_hgncid = false # bool |  (optional) (default to false)
show_mgiid = false # bool |  (optional) (default to false)
show_ortho_isoform = false # bool |  (optional) (default to false)
show_ortho_modified_form = false # bool |  (optional) (default to false)
show_pantherid = false # bool |  (optional) (default to false)
show_pirsfid = false # bool |  (optional) (default to false)
show_pmid = false # bool |  (optional) (default to false)
show_uni_prot_kbid = false # bool |  (optional) (default to false)
offset = 0 # int | The number of items to skip before starting to collect the result set. (optional) (default to 0)
limit = 50 # int | The numbers of items to return. (optional) (default to 50)

try:
    # Returns a list of PRO terms with Reactome ID as cross-reference.
    api_response = api_instance.get_pro_terms_with_reactome_id(search_field=search_field, search_value=search_value, show_pro_name=show_pro_name, show_pro_term_definition=show_pro_term_definition, show_category=show_category, show_parent=show_parent, show_reactome_id=show_reactome_id, show_annotation=show_annotation, show_any_relationship=show_any_relationship, show_child=show_child, show_comment=show_comment, show_eco_cyc_id=show_eco_cyc_id, show_gene_name=show_gene_name, show_hgncid=show_hgncid, show_mgiid=show_mgiid, show_ortho_isoform=show_ortho_isoform, show_ortho_modified_form=show_ortho_modified_form, show_pantherid=show_pantherid, show_pirsfid=show_pirsfid, show_pmid=show_pmid, show_uni_prot_kbid=show_uni_prot_kbid, offset=offset, limit=limit)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DatabaseCrossReferencesApi->get_pro_terms_with_reactome_id: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search_field** | **str**| Search field that needs to be considered for filter | [optional] 
 **search_value** | **str**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **show_pro_name** | **bool**|  | [optional] [default to true]
 **show_pro_term_definition** | **bool**|  | [optional] [default to true]
 **show_category** | **bool**|  | [optional] [default to true]
 **show_parent** | **bool**|  | [optional] [default to true]
 **show_reactome_id** | **bool**|  | [optional] [default to true]
 **show_annotation** | **bool**|  | [optional] [default to false]
 **show_any_relationship** | **bool**|  | [optional] [default to false]
 **show_child** | **bool**|  | [optional] [default to false]
 **show_comment** | **bool**|  | [optional] [default to false]
 **show_eco_cyc_id** | **bool**|  | [optional] [default to false]
 **show_gene_name** | **bool**|  | [optional] [default to false]
 **show_hgncid** | **bool**|  | [optional] [default to false]
 **show_mgiid** | **bool**|  | [optional] [default to false]
 **show_ortho_isoform** | **bool**|  | [optional] [default to false]
 **show_ortho_modified_form** | **bool**|  | [optional] [default to false]
 **show_pantherid** | **bool**|  | [optional] [default to false]
 **show_pirsfid** | **bool**|  | [optional] [default to false]
 **show_pmid** | **bool**|  | [optional] [default to false]
 **show_uni_prot_kbid** | **bool**|  | [optional] [default to false]
 **offset** | **int**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**list[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_pro_terms_with_uni_prot_kbid**
> list[PROTerm] get_pro_terms_with_uni_prot_kbid(search_field=search_field, search_value=search_value, show_pro_name=show_pro_name, show_pro_term_definition=show_pro_term_definition, show_category=show_category, show_parent=show_parent, show_uni_prot_kbid=show_uni_prot_kbid, show_annotation=show_annotation, show_any_relationship=show_any_relationship, show_child=show_child, show_comment=show_comment, show_eco_cyc_id=show_eco_cyc_id, show_gene_name=show_gene_name, show_hgncid=show_hgncid, show_mgiid=show_mgiid, show_ortho_isoform=show_ortho_isoform, show_ortho_modified_form=show_ortho_modified_form, show_pantherid=show_pantherid, show_pirsfid=show_pirsfid, show_pmid=show_pmid, show_reactome_id=show_reactome_id, offset=offset, limit=limit)

Returns a list of PRO terms with UniProtKB ID as cross-reference.

Gets a list of PRO terms with UniProtKB ID as cross-reference and associated information.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DatabaseCrossReferencesApi()
search_field = 'search_field_example' # str | Search field that needs to be considered for filter (optional)
search_value = 'search_value_example' # str | any string or \"null\" or \"not null\" or a list of space separated ids (optional)
show_pro_name = true # bool |  (optional) (default to true)
show_pro_term_definition = true # bool |  (optional) (default to true)
show_category = true # bool |  (optional) (default to true)
show_parent = true # bool |  (optional) (default to true)
show_uni_prot_kbid = true # bool |  (optional) (default to true)
show_annotation = false # bool |  (optional) (default to false)
show_any_relationship = false # bool |  (optional) (default to false)
show_child = false # bool |  (optional) (default to false)
show_comment = false # bool |  (optional) (default to false)
show_eco_cyc_id = false # bool |  (optional) (default to false)
show_gene_name = false # bool |  (optional) (default to false)
show_hgncid = false # bool |  (optional) (default to false)
show_mgiid = false # bool |  (optional) (default to false)
show_ortho_isoform = false # bool |  (optional) (default to false)
show_ortho_modified_form = false # bool |  (optional) (default to false)
show_pantherid = false # bool |  (optional) (default to false)
show_pirsfid = false # bool |  (optional) (default to false)
show_pmid = false # bool |  (optional) (default to false)
show_reactome_id = false # bool |  (optional) (default to false)
offset = 0 # int | The number of items to skip before starting to collect the result set. (optional) (default to 0)
limit = 50 # int | The numbers of items to return. (optional) (default to 50)

try:
    # Returns a list of PRO terms with UniProtKB ID as cross-reference.
    api_response = api_instance.get_pro_terms_with_uni_prot_kbid(search_field=search_field, search_value=search_value, show_pro_name=show_pro_name, show_pro_term_definition=show_pro_term_definition, show_category=show_category, show_parent=show_parent, show_uni_prot_kbid=show_uni_prot_kbid, show_annotation=show_annotation, show_any_relationship=show_any_relationship, show_child=show_child, show_comment=show_comment, show_eco_cyc_id=show_eco_cyc_id, show_gene_name=show_gene_name, show_hgncid=show_hgncid, show_mgiid=show_mgiid, show_ortho_isoform=show_ortho_isoform, show_ortho_modified_form=show_ortho_modified_form, show_pantherid=show_pantherid, show_pirsfid=show_pirsfid, show_pmid=show_pmid, show_reactome_id=show_reactome_id, offset=offset, limit=limit)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DatabaseCrossReferencesApi->get_pro_terms_with_uni_prot_kbid: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search_field** | **str**| Search field that needs to be considered for filter | [optional] 
 **search_value** | **str**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional] 
 **show_pro_name** | **bool**|  | [optional] [default to true]
 **show_pro_term_definition** | **bool**|  | [optional] [default to true]
 **show_category** | **bool**|  | [optional] [default to true]
 **show_parent** | **bool**|  | [optional] [default to true]
 **show_uni_prot_kbid** | **bool**|  | [optional] [default to true]
 **show_annotation** | **bool**|  | [optional] [default to false]
 **show_any_relationship** | **bool**|  | [optional] [default to false]
 **show_child** | **bool**|  | [optional] [default to false]
 **show_comment** | **bool**|  | [optional] [default to false]
 **show_eco_cyc_id** | **bool**|  | [optional] [default to false]
 **show_gene_name** | **bool**|  | [optional] [default to false]
 **show_hgncid** | **bool**|  | [optional] [default to false]
 **show_mgiid** | **bool**|  | [optional] [default to false]
 **show_ortho_isoform** | **bool**|  | [optional] [default to false]
 **show_ortho_modified_form** | **bool**|  | [optional] [default to false]
 **show_pantherid** | **bool**|  | [optional] [default to false]
 **show_pirsfid** | **bool**|  | [optional] [default to false]
 **show_pmid** | **bool**|  | [optional] [default to false]
 **show_reactome_id** | **bool**|  | [optional] [default to false]
 **offset** | **int**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**list[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

