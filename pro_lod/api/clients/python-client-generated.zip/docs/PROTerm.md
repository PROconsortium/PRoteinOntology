# PROTerm

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | The PRO ID. | [optional] 
**name** | **str** | The PRO name. | [optional] 
**term_def** | **str** | The PRO term definition. | [optional] 
**category** | **str** | The PRO term category. | [optional] 
**annotation** | [**list[Annotation]**](Annotation.md) |  | [optional] 
**any_relationship** | **str** |  | [optional] 
**child** | **list[str]** |  | [optional] 
**eco_cyc_id** | **str** |  | [optional] 
**gene_name** | **str** |  | [optional] 
**hgnc_id** | **list[str]** |  | [optional] 
**mgi_id** | **list[str]** |  | [optional] 
**ortho_isoform** | **list[str]** |  | [optional] 
**ortho_modified_form** | **list[str]** |  | [optional] 
**panther_id** | **str** |  | [optional] 
**paraent** | **list[str]** |  | [optional] 
**pirsf_id** | **str** |  | [optional] 
**pm_id** | **str** |  | [optional] 
**synonym** | **list[str]** |  | [optional] 
**reactome_id** | **list[str]** |  | [optional] 
**uniprot_kbid** | **list[str]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

