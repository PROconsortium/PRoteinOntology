# swagger_client.OBOFileApi

All URIs are relative to *https://research.bioinformatics.udel.edu/PRO_API/V1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_obo_by_proi_ds**](OBOFileApi.md#get_obo_by_proi_ds) | **GET** /obo/{proIds} | Returns PRO term in OBO format for the given PRO ID(s).

# **get_obo_by_proi_ds**
> str get_obo_by_proi_ds(pro_ids)

Returns PRO term in OBO format for the given PRO ID(s).

Gets PRO term in OBO format for the given PRO ID(s).

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.OBOFileApi()
pro_ids = 'pro_ids_example' # str | PRO ID(s). Space separated values accepted up to 100.

try:
    # Returns PRO term in OBO format for the given PRO ID(s).
    api_response = api_instance.get_obo_by_proi_ds(pro_ids)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling OBOFileApi->get_obo_by_proi_ds: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pro_ids** | **str**| PRO ID(s). Space separated values accepted up to 100. | 

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

