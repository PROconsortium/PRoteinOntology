# swagger_client.DAGApi

All URIs are relative to *https://research.bioinformatics.udel.edu/PRO_API/V1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_ancestor_by_pro_i_ds**](DAGApi.md#get_ancestor_by_pro_i_ds) | **GET** /dag/ancestor/{proIds} | Returns direct and indirect parent PRO terms by the given PRO ID(s).
[**get_children_by_pro_i_ds**](DAGApi.md#get_children_by_pro_i_ds) | **GET** /dag/children/{proIds} | Returns direct children PRO terms by the given PRO ID(s).
[**get_descendant_by_pro_i_ds**](DAGApi.md#get_descendant_by_pro_i_ds) | **GET** /dag/descendant/{proIds} | Returns direct and indirect children PRO terms by the given PRO ID(s).
[**get_hierarchy_by_pro_id**](DAGApi.md#get_hierarchy_by_pro_id) | **GET** /dag/hierarchy/{proId} | Returns hierarchy of PRO terms by the given PRO ID.
[**get_parent_by_pro_i_ds**](DAGApi.md#get_parent_by_pro_i_ds) | **GET** /dag/parent/{proIds} | Returns direct parent PRO terms by the given PRO ID(s).

# **get_ancestor_by_pro_i_ds**
> list[PROTerm] get_ancestor_by_pro_i_ds(pro_ids, show_pro_name=show_pro_name, show_pro_term_definition=show_pro_term_definition, show_category=show_category, show_parent=show_parent, show_annotation=show_annotation, show_any_relationship=show_any_relationship, show_child=show_child, show_comment=show_comment, show_eco_cyc_id=show_eco_cyc_id, show_gene_name=show_gene_name, show_hgncid=show_hgncid, show_mgiid=show_mgiid, show_ortho_isoform=show_ortho_isoform, show_ortho_modified_form=show_ortho_modified_form, show_pantherid=show_pantherid, show_pirsfid=show_pirsfid, show_pmid=show_pmid, show_reactome_id=show_reactome_id, show_uni_prot_kbid=show_uni_prot_kbid, offset=offset, limit=limit)

Returns direct and indirect parent PRO terms by the given PRO ID(s).

Gets direct and indirect parent PRO terms by the given PRO ID(s) and associated information.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DAGApi()
pro_ids = 'pro_ids_example' # str | PRO ID(s). Space separated values accepted up to 100.
show_pro_name = true # bool |  (optional) (default to true)
show_pro_term_definition = true # bool |  (optional) (default to true)
show_category = true # bool |  (optional) (default to true)
show_parent = true # bool |  (optional) (default to true)
show_annotation = false # bool |  (optional) (default to false)
show_any_relationship = false # bool |  (optional) (default to false)
show_child = false # bool |  (optional) (default to false)
show_comment = false # bool |  (optional) (default to false)
show_eco_cyc_id = false # bool |  (optional) (default to false)
show_gene_name = false # bool |  (optional) (default to false)
show_hgncid = false # bool |  (optional) (default to false)
show_mgiid = false # bool |  (optional) (default to false)
show_ortho_isoform = false # bool |  (optional) (default to false)
show_ortho_modified_form = false # bool |  (optional) (default to false)
show_pantherid = false # bool |  (optional) (default to false)
show_pirsfid = false # bool |  (optional) (default to false)
show_pmid = false # bool |  (optional) (default to false)
show_reactome_id = false # bool |  (optional) (default to false)
show_uni_prot_kbid = false # bool |  (optional) (default to false)
offset = 0 # int | The number of items to skip before starting to collect the result set. (optional) (default to 0)
limit = 50 # int | The numbers of items to return. (optional) (default to 50)

try:
    # Returns direct and indirect parent PRO terms by the given PRO ID(s).
    api_response = api_instance.get_ancestor_by_pro_i_ds(pro_ids, show_pro_name=show_pro_name, show_pro_term_definition=show_pro_term_definition, show_category=show_category, show_parent=show_parent, show_annotation=show_annotation, show_any_relationship=show_any_relationship, show_child=show_child, show_comment=show_comment, show_eco_cyc_id=show_eco_cyc_id, show_gene_name=show_gene_name, show_hgncid=show_hgncid, show_mgiid=show_mgiid, show_ortho_isoform=show_ortho_isoform, show_ortho_modified_form=show_ortho_modified_form, show_pantherid=show_pantherid, show_pirsfid=show_pirsfid, show_pmid=show_pmid, show_reactome_id=show_reactome_id, show_uni_prot_kbid=show_uni_prot_kbid, offset=offset, limit=limit)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DAGApi->get_ancestor_by_pro_i_ds: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pro_ids** | **str**| PRO ID(s). Space separated values accepted up to 100. | 
 **show_pro_name** | **bool**|  | [optional] [default to true]
 **show_pro_term_definition** | **bool**|  | [optional] [default to true]
 **show_category** | **bool**|  | [optional] [default to true]
 **show_parent** | **bool**|  | [optional] [default to true]
 **show_annotation** | **bool**|  | [optional] [default to false]
 **show_any_relationship** | **bool**|  | [optional] [default to false]
 **show_child** | **bool**|  | [optional] [default to false]
 **show_comment** | **bool**|  | [optional] [default to false]
 **show_eco_cyc_id** | **bool**|  | [optional] [default to false]
 **show_gene_name** | **bool**|  | [optional] [default to false]
 **show_hgncid** | **bool**|  | [optional] [default to false]
 **show_mgiid** | **bool**|  | [optional] [default to false]
 **show_ortho_isoform** | **bool**|  | [optional] [default to false]
 **show_ortho_modified_form** | **bool**|  | [optional] [default to false]
 **show_pantherid** | **bool**|  | [optional] [default to false]
 **show_pirsfid** | **bool**|  | [optional] [default to false]
 **show_pmid** | **bool**|  | [optional] [default to false]
 **show_reactome_id** | **bool**|  | [optional] [default to false]
 **show_uni_prot_kbid** | **bool**|  | [optional] [default to false]
 **offset** | **int**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**list[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_children_by_pro_i_ds**
> list[PROTerm] get_children_by_pro_i_ds(pro_ids, show_pro_name=show_pro_name, show_pro_term_definition=show_pro_term_definition, show_category=show_category, show_parent=show_parent, show_annotation=show_annotation, show_any_relationship=show_any_relationship, show_child=show_child, show_comment=show_comment, show_eco_cyc_id=show_eco_cyc_id, show_gene_name=show_gene_name, show_hgncid=show_hgncid, show_mgiid=show_mgiid, show_ortho_isoform=show_ortho_isoform, show_ortho_modified_form=show_ortho_modified_form, show_pantherid=show_pantherid, show_pirsfid=show_pirsfid, show_pmid=show_pmid, show_reactome_id=show_reactome_id, show_uni_prot_kbid=show_uni_prot_kbid, offset=offset, limit=limit)

Returns direct children PRO terms by the given PRO ID(s).

Gets direct children PRO terms by the given PRO ID(s) and associated information.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DAGApi()
pro_ids = 'pro_ids_example' # str | PRO ID(s). Space separated values accepted up to 100.
show_pro_name = true # bool |  (optional) (default to true)
show_pro_term_definition = true # bool |  (optional) (default to true)
show_category = true # bool |  (optional) (default to true)
show_parent = true # bool |  (optional) (default to true)
show_annotation = false # bool |  (optional) (default to false)
show_any_relationship = false # bool |  (optional) (default to false)
show_child = false # bool |  (optional) (default to false)
show_comment = false # bool |  (optional) (default to false)
show_eco_cyc_id = false # bool |  (optional) (default to false)
show_gene_name = false # bool |  (optional) (default to false)
show_hgncid = false # bool |  (optional) (default to false)
show_mgiid = false # bool |  (optional) (default to false)
show_ortho_isoform = false # bool |  (optional) (default to false)
show_ortho_modified_form = false # bool |  (optional) (default to false)
show_pantherid = false # bool |  (optional) (default to false)
show_pirsfid = false # bool |  (optional) (default to false)
show_pmid = false # bool |  (optional) (default to false)
show_reactome_id = false # bool |  (optional) (default to false)
show_uni_prot_kbid = false # bool |  (optional) (default to false)
offset = 0 # int | The number of items to skip before starting to collect the result set. (optional) (default to 0)
limit = 50 # int | The numbers of items to return. (optional) (default to 50)

try:
    # Returns direct children PRO terms by the given PRO ID(s).
    api_response = api_instance.get_children_by_pro_i_ds(pro_ids, show_pro_name=show_pro_name, show_pro_term_definition=show_pro_term_definition, show_category=show_category, show_parent=show_parent, show_annotation=show_annotation, show_any_relationship=show_any_relationship, show_child=show_child, show_comment=show_comment, show_eco_cyc_id=show_eco_cyc_id, show_gene_name=show_gene_name, show_hgncid=show_hgncid, show_mgiid=show_mgiid, show_ortho_isoform=show_ortho_isoform, show_ortho_modified_form=show_ortho_modified_form, show_pantherid=show_pantherid, show_pirsfid=show_pirsfid, show_pmid=show_pmid, show_reactome_id=show_reactome_id, show_uni_prot_kbid=show_uni_prot_kbid, offset=offset, limit=limit)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DAGApi->get_children_by_pro_i_ds: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pro_ids** | **str**| PRO ID(s). Space separated values accepted up to 100. | 
 **show_pro_name** | **bool**|  | [optional] [default to true]
 **show_pro_term_definition** | **bool**|  | [optional] [default to true]
 **show_category** | **bool**|  | [optional] [default to true]
 **show_parent** | **bool**|  | [optional] [default to true]
 **show_annotation** | **bool**|  | [optional] [default to false]
 **show_any_relationship** | **bool**|  | [optional] [default to false]
 **show_child** | **bool**|  | [optional] [default to false]
 **show_comment** | **bool**|  | [optional] [default to false]
 **show_eco_cyc_id** | **bool**|  | [optional] [default to false]
 **show_gene_name** | **bool**|  | [optional] [default to false]
 **show_hgncid** | **bool**|  | [optional] [default to false]
 **show_mgiid** | **bool**|  | [optional] [default to false]
 **show_ortho_isoform** | **bool**|  | [optional] [default to false]
 **show_ortho_modified_form** | **bool**|  | [optional] [default to false]
 **show_pantherid** | **bool**|  | [optional] [default to false]
 **show_pirsfid** | **bool**|  | [optional] [default to false]
 **show_pmid** | **bool**|  | [optional] [default to false]
 **show_reactome_id** | **bool**|  | [optional] [default to false]
 **show_uni_prot_kbid** | **bool**|  | [optional] [default to false]
 **offset** | **int**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**list[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_descendant_by_pro_i_ds**
> list[PROTerm] get_descendant_by_pro_i_ds(pro_ids, show_pro_name=show_pro_name, show_pro_term_definition=show_pro_term_definition, show_category=show_category, show_parent=show_parent, show_annotation=show_annotation, show_any_relationship=show_any_relationship, show_child=show_child, show_comment=show_comment, show_eco_cyc_id=show_eco_cyc_id, show_gene_name=show_gene_name, show_hgncid=show_hgncid, show_mgiid=show_mgiid, show_ortho_isoform=show_ortho_isoform, show_ortho_modified_form=show_ortho_modified_form, show_pantherid=show_pantherid, show_pirsfid=show_pirsfid, show_pmid=show_pmid, show_reactome_id=show_reactome_id, show_uni_prot_kbid=show_uni_prot_kbid, offset=offset, limit=limit)

Returns direct and indirect children PRO terms by the given PRO ID(s).

Gets direct and indirect children PRO terms by the given PRO ID(s) and associated information.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DAGApi()
pro_ids = 'pro_ids_example' # str | PRO ID(s). Space separated values accepted up to 100.
show_pro_name = true # bool |  (optional) (default to true)
show_pro_term_definition = true # bool |  (optional) (default to true)
show_category = true # bool |  (optional) (default to true)
show_parent = true # bool |  (optional) (default to true)
show_annotation = false # bool |  (optional) (default to false)
show_any_relationship = false # bool |  (optional) (default to false)
show_child = false # bool |  (optional) (default to false)
show_comment = false # bool |  (optional) (default to false)
show_eco_cyc_id = false # bool |  (optional) (default to false)
show_gene_name = false # bool |  (optional) (default to false)
show_hgncid = false # bool |  (optional) (default to false)
show_mgiid = false # bool |  (optional) (default to false)
show_ortho_isoform = false # bool |  (optional) (default to false)
show_ortho_modified_form = false # bool |  (optional) (default to false)
show_pantherid = false # bool |  (optional) (default to false)
show_pirsfid = false # bool |  (optional) (default to false)
show_pmid = false # bool |  (optional) (default to false)
show_reactome_id = false # bool |  (optional) (default to false)
show_uni_prot_kbid = false # bool |  (optional) (default to false)
offset = 0 # int | The number of items to skip before starting to collect the result set. (optional) (default to 0)
limit = 50 # int | The numbers of items to return. (optional) (default to 50)

try:
    # Returns direct and indirect children PRO terms by the given PRO ID(s).
    api_response = api_instance.get_descendant_by_pro_i_ds(pro_ids, show_pro_name=show_pro_name, show_pro_term_definition=show_pro_term_definition, show_category=show_category, show_parent=show_parent, show_annotation=show_annotation, show_any_relationship=show_any_relationship, show_child=show_child, show_comment=show_comment, show_eco_cyc_id=show_eco_cyc_id, show_gene_name=show_gene_name, show_hgncid=show_hgncid, show_mgiid=show_mgiid, show_ortho_isoform=show_ortho_isoform, show_ortho_modified_form=show_ortho_modified_form, show_pantherid=show_pantherid, show_pirsfid=show_pirsfid, show_pmid=show_pmid, show_reactome_id=show_reactome_id, show_uni_prot_kbid=show_uni_prot_kbid, offset=offset, limit=limit)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DAGApi->get_descendant_by_pro_i_ds: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pro_ids** | **str**| PRO ID(s). Space separated values accepted up to 100. | 
 **show_pro_name** | **bool**|  | [optional] [default to true]
 **show_pro_term_definition** | **bool**|  | [optional] [default to true]
 **show_category** | **bool**|  | [optional] [default to true]
 **show_parent** | **bool**|  | [optional] [default to true]
 **show_annotation** | **bool**|  | [optional] [default to false]
 **show_any_relationship** | **bool**|  | [optional] [default to false]
 **show_child** | **bool**|  | [optional] [default to false]
 **show_comment** | **bool**|  | [optional] [default to false]
 **show_eco_cyc_id** | **bool**|  | [optional] [default to false]
 **show_gene_name** | **bool**|  | [optional] [default to false]
 **show_hgncid** | **bool**|  | [optional] [default to false]
 **show_mgiid** | **bool**|  | [optional] [default to false]
 **show_ortho_isoform** | **bool**|  | [optional] [default to false]
 **show_ortho_modified_form** | **bool**|  | [optional] [default to false]
 **show_pantherid** | **bool**|  | [optional] [default to false]
 **show_pirsfid** | **bool**|  | [optional] [default to false]
 **show_pmid** | **bool**|  | [optional] [default to false]
 **show_reactome_id** | **bool**|  | [optional] [default to false]
 **show_uni_prot_kbid** | **bool**|  | [optional] [default to false]
 **offset** | **int**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**list[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_hierarchy_by_pro_id**
> list[ChildParentPair] get_hierarchy_by_pro_id(pro_id, show_pro_name=show_pro_name, show_pro_term_definition=show_pro_term_definition, show_category=show_category, show_annotation=show_annotation, show_any_relationship=show_any_relationship, show_comment=show_comment, show_eco_cyc_id=show_eco_cyc_id, show_gene_name=show_gene_name, show_hgncid=show_hgncid, show_mgiid=show_mgiid, show_ortho_isoform=show_ortho_isoform, show_ortho_modified_form=show_ortho_modified_form, show_pantherid=show_pantherid, show_pirsfid=show_pirsfid, show_pmid=show_pmid, show_reactome_id=show_reactome_id, show_synonym=show_synonym, show_taxon_id=show_taxon_id, show_uni_prot_kbid=show_uni_prot_kbid)

Returns hierarchy of PRO terms by the given PRO ID.

Gets hierarchy of PRO terms by the given PRO ID.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DAGApi()
pro_id = 'pro_id_example' # str | Space separated PRO ID(s).
show_pro_name = true # bool |  (optional) (default to true)
show_pro_term_definition = true # bool |  (optional) (default to true)
show_category = true # bool |  (optional) (default to true)
show_annotation = false # bool |  (optional) (default to false)
show_any_relationship = false # bool |  (optional) (default to false)
show_comment = false # bool |  (optional) (default to false)
show_eco_cyc_id = false # bool |  (optional) (default to false)
show_gene_name = false # bool |  (optional) (default to false)
show_hgncid = false # bool |  (optional) (default to false)
show_mgiid = false # bool |  (optional) (default to false)
show_ortho_isoform = false # bool |  (optional) (default to false)
show_ortho_modified_form = false # bool |  (optional) (default to false)
show_pantherid = false # bool |  (optional) (default to false)
show_pirsfid = false # bool |  (optional) (default to false)
show_pmid = false # bool |  (optional) (default to false)
show_reactome_id = false # bool |  (optional) (default to false)
show_synonym = false # bool |  (optional) (default to false)
show_taxon_id = false # bool |  (optional) (default to false)
show_uni_prot_kbid = false # bool |  (optional) (default to false)

try:
    # Returns hierarchy of PRO terms by the given PRO ID.
    api_response = api_instance.get_hierarchy_by_pro_id(pro_id, show_pro_name=show_pro_name, show_pro_term_definition=show_pro_term_definition, show_category=show_category, show_annotation=show_annotation, show_any_relationship=show_any_relationship, show_comment=show_comment, show_eco_cyc_id=show_eco_cyc_id, show_gene_name=show_gene_name, show_hgncid=show_hgncid, show_mgiid=show_mgiid, show_ortho_isoform=show_ortho_isoform, show_ortho_modified_form=show_ortho_modified_form, show_pantherid=show_pantherid, show_pirsfid=show_pirsfid, show_pmid=show_pmid, show_reactome_id=show_reactome_id, show_synonym=show_synonym, show_taxon_id=show_taxon_id, show_uni_prot_kbid=show_uni_prot_kbid)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DAGApi->get_hierarchy_by_pro_id: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pro_id** | **str**| Space separated PRO ID(s). | 
 **show_pro_name** | **bool**|  | [optional] [default to true]
 **show_pro_term_definition** | **bool**|  | [optional] [default to true]
 **show_category** | **bool**|  | [optional] [default to true]
 **show_annotation** | **bool**|  | [optional] [default to false]
 **show_any_relationship** | **bool**|  | [optional] [default to false]
 **show_comment** | **bool**|  | [optional] [default to false]
 **show_eco_cyc_id** | **bool**|  | [optional] [default to false]
 **show_gene_name** | **bool**|  | [optional] [default to false]
 **show_hgncid** | **bool**|  | [optional] [default to false]
 **show_mgiid** | **bool**|  | [optional] [default to false]
 **show_ortho_isoform** | **bool**|  | [optional] [default to false]
 **show_ortho_modified_form** | **bool**|  | [optional] [default to false]
 **show_pantherid** | **bool**|  | [optional] [default to false]
 **show_pirsfid** | **bool**|  | [optional] [default to false]
 **show_pmid** | **bool**|  | [optional] [default to false]
 **show_reactome_id** | **bool**|  | [optional] [default to false]
 **show_synonym** | **bool**|  | [optional] [default to false]
 **show_taxon_id** | **bool**|  | [optional] [default to false]
 **show_uni_prot_kbid** | **bool**|  | [optional] [default to false]

### Return type

[**list[ChildParentPair]**](ChildParentPair.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_parent_by_pro_i_ds**
> list[PROTerm] get_parent_by_pro_i_ds(pro_ids, show_pro_name=show_pro_name, show_pro_term_definition=show_pro_term_definition, show_category=show_category, show_parent=show_parent, show_annotation=show_annotation, show_any_relationship=show_any_relationship, show_child=show_child, show_comment=show_comment, show_eco_cyc_id=show_eco_cyc_id, show_gene_name=show_gene_name, show_hgncid=show_hgncid, show_mgiid=show_mgiid, show_ortho_isoform=show_ortho_isoform, show_ortho_modified_form=show_ortho_modified_form, show_pantherid=show_pantherid, show_pirsfid=show_pirsfid, show_pmid=show_pmid, show_reactome_id=show_reactome_id, show_uni_prot_kbid=show_uni_prot_kbid, offset=offset, limit=limit)

Returns direct parent PRO terms by the given PRO ID(s).

Gets direct parent PRO terms by the given PRO ID(s) and associated information.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DAGApi()
pro_ids = 'pro_ids_example' # str | PRO ID(s). Space separated values accepted up to 100.
show_pro_name = true # bool |  (optional) (default to true)
show_pro_term_definition = true # bool |  (optional) (default to true)
show_category = true # bool |  (optional) (default to true)
show_parent = true # bool |  (optional) (default to true)
show_annotation = false # bool |  (optional) (default to false)
show_any_relationship = false # bool |  (optional) (default to false)
show_child = false # bool |  (optional) (default to false)
show_comment = false # bool |  (optional) (default to false)
show_eco_cyc_id = false # bool |  (optional) (default to false)
show_gene_name = false # bool |  (optional) (default to false)
show_hgncid = false # bool |  (optional) (default to false)
show_mgiid = false # bool |  (optional) (default to false)
show_ortho_isoform = false # bool |  (optional) (default to false)
show_ortho_modified_form = false # bool |  (optional) (default to false)
show_pantherid = false # bool |  (optional) (default to false)
show_pirsfid = false # bool |  (optional) (default to false)
show_pmid = false # bool |  (optional) (default to false)
show_reactome_id = false # bool |  (optional) (default to false)
show_uni_prot_kbid = false # bool |  (optional) (default to false)
offset = 0 # int | The number of items to skip before starting to collect the result set. (optional) (default to 0)
limit = 50 # int | The numbers of items to return. (optional) (default to 50)

try:
    # Returns direct parent PRO terms by the given PRO ID(s).
    api_response = api_instance.get_parent_by_pro_i_ds(pro_ids, show_pro_name=show_pro_name, show_pro_term_definition=show_pro_term_definition, show_category=show_category, show_parent=show_parent, show_annotation=show_annotation, show_any_relationship=show_any_relationship, show_child=show_child, show_comment=show_comment, show_eco_cyc_id=show_eco_cyc_id, show_gene_name=show_gene_name, show_hgncid=show_hgncid, show_mgiid=show_mgiid, show_ortho_isoform=show_ortho_isoform, show_ortho_modified_form=show_ortho_modified_form, show_pantherid=show_pantherid, show_pirsfid=show_pirsfid, show_pmid=show_pmid, show_reactome_id=show_reactome_id, show_uni_prot_kbid=show_uni_prot_kbid, offset=offset, limit=limit)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DAGApi->get_parent_by_pro_i_ds: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pro_ids** | **str**| PRO ID(s). Space separated values accepted up to 100. | 
 **show_pro_name** | **bool**|  | [optional] [default to true]
 **show_pro_term_definition** | **bool**|  | [optional] [default to true]
 **show_category** | **bool**|  | [optional] [default to true]
 **show_parent** | **bool**|  | [optional] [default to true]
 **show_annotation** | **bool**|  | [optional] [default to false]
 **show_any_relationship** | **bool**|  | [optional] [default to false]
 **show_child** | **bool**|  | [optional] [default to false]
 **show_comment** | **bool**|  | [optional] [default to false]
 **show_eco_cyc_id** | **bool**|  | [optional] [default to false]
 **show_gene_name** | **bool**|  | [optional] [default to false]
 **show_hgncid** | **bool**|  | [optional] [default to false]
 **show_mgiid** | **bool**|  | [optional] [default to false]
 **show_ortho_isoform** | **bool**|  | [optional] [default to false]
 **show_ortho_modified_form** | **bool**|  | [optional] [default to false]
 **show_pantherid** | **bool**|  | [optional] [default to false]
 **show_pirsfid** | **bool**|  | [optional] [default to false]
 **show_pmid** | **bool**|  | [optional] [default to false]
 **show_reactome_id** | **bool**|  | [optional] [default to false]
 **show_uni_prot_kbid** | **bool**|  | [optional] [default to false]
 **offset** | **int**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**list[PROTerm]**](PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

