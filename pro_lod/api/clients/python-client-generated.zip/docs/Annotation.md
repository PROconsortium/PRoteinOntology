# Annotation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**modifier** | **str** |  | [optional] 
**relation** | **str** |  | [optional] 
**ontology_id** | **str** |  | [optional] 
**ontology_term** | **str** |  | [optional] 
**relative_to** | **str** |  | [optional] 
**interaction_with** | **str** |  | [optional] 
**evidence** | [**Evidence**](Evidence.md) |  | [optional] 
**ncbi_taxon_id** | **int** |  | [optional] 
**inferred_from** | **list[str]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

