# ReportSearchParameters

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Taxonids** | **string** | NCBI taxonomy IDs. | [optional] [default to null]
**Swissprot** | **bool** | Only search SwissProt protein sequences. | [optional] [default to null]
**Isoform** | **bool** | Include isoforms. | [optional] [default to null]
**Uniref100** | **bool** | Only search UniRef100 protein sequences. | [optional] [default to null]
**Leqi** | **bool** | Treat Leucine (L) and Isoleucine (I) equivalent. | [optional] [default to null]
**Offset** | **int32** | Off set, page starting point, with default value 0. | [optional] [default to null]
**Size** | **int32** | Page size with default value 100. When page size is -1, it returns all records and offset will be ignored. | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


