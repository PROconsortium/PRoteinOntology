# Report

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**NumberFound** | **int32** | Number of documents found. | [optional] [default to null]
**Qtime** | **int32** | Query response time in milliseocnds. | [optional] [default to null]
**Status** | **int32** | Query response status. | [optional] [default to null]
**SearchParameters** | [***ReportSearchParameters**](Report_searchParameters.md) |  | [optional] [default to null]
**Results** | [**[]ReportResults**](Report_results.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


