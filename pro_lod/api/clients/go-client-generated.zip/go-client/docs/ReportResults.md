# ReportResults

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**QueryPeptide** | **string** | Query peptide sequence. | [optional] [default to null]
**Proteins** | [**[]Protein**](Protein.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


