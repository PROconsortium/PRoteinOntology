# ProteinMatchingPeptides

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Peptide** | **string** | Query peptide. | [optional] [default to null]
**MatchRange** | [**[]ProteinMatchRange**](Protein_matchRange.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


