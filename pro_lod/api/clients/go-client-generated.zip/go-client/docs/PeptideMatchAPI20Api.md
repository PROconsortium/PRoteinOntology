# \PeptideMatchAPI20Api

All URIs are relative to *http://ibm-cloud1.proteininformationresource.org/peptidematchapi2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**MatchGetGet**](PeptideMatchAPI20Api.md#MatchGetGet) | **Get** /match_get | Do peptide match using GET method.
[**MatchPostPost**](PeptideMatchAPI20Api.md#MatchPostPost) | **Post** /match_post | Do peptide match using POST method.


# **MatchGetGet**
> Report MatchGetGet(ctx, peptides, optional)
Do peptide match using GET method.

Retrieve UniProtKB protein sequences that would exactly match to the query peptides using GET method.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **peptides** | **string**| A list of comma-separated peptide sequences (up to 100). Each sequence consists of 3 or more amino acids. | [default to AAVEEGIVLGGGCALLR,SVQYDDVPEYK]
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **peptides** | **string**| A list of comma-separated peptide sequences (up to 100). Each sequence consists of 3 or more amino acids. | [default to AAVEEGIVLGGGCALLR,SVQYDDVPEYK]
 **taxonids** | **string**| A list fo comma-separated NCBI taxonomy IDs. | [default to 9606,10090]
 **swissprot** | **bool**| Only search SwissProt protein sequences. | [default to true]
 **isoform** | **bool**| Include isforms. | [default to true]
 **uniref100** | **bool**| Only search UniRef100 protein sequences. | [default to false]
 **leqi** | **bool**| Treat Leucine (L) and Isoleucine (I) equivalent. | [default to false]
 **offset** | **int32**| Off set, page starting point, with default value 0. | [default to 0]
 **size** | **int32**| Page size with default value 100. When page size is -1, it returns all records and offset will be ignored. | [default to 100]

### Return type

[**Report**](Report.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml, text/x-fasta, text/tab-separated-values

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **MatchPostPost**
> Report MatchPostPost(ctx, peptides, optional)
Do peptide match using POST method.

Retrieve UniProtKB protein sequences that would exactly match to the query peptides using POST method.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for logging, tracing, authentication, etc.
  **peptides** | **string**| A list of comma-separated peptide sequences (up to 100). Each sequence consists of 3 or more amino acids. | [default to AAVEEGIVLGGGCALLR,SVQYDDVPEYK]
 **optional** | **map[string]interface{}** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a map[string]interface{}.

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **peptides** | **string**| A list of comma-separated peptide sequences (up to 100). Each sequence consists of 3 or more amino acids. | [default to AAVEEGIVLGGGCALLR,SVQYDDVPEYK]
 **taxonids** | **string**| A list fo comma-separated NCBI taxonomy IDs. | [default to 9606,10090]
 **swissprot** | **bool**| Only search SwissProt protein sequences. | [default to true]
 **isoform** | **bool**| Include isoforms. | [default to true]
 **uniref100** | **bool**| Only search UniRef100 protein sequences. | [default to false]
 **leqi** | **bool**| Treat Leucine (L) and Isoleucine (I) equivalent. | [default to false]
 **offset** | **int32**| Off set, page starting point, with default value 0. | [default to 0]
 **size** | **int32**| Page size with default value 100. When page size is -1, it returns all records and offset will be ignored. | [default to 100]

### Return type

[**Report**](Report.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded
 - **Accept**: application/json, application/xml, text/x-fasta, text/tab-separated-values

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

