# Protein

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ReviewStatus** | **string** | SwissProt or TrEMBL entry. | [optional] [default to null]
**Ac** | **string** | Protein accession number. | [optional] [default to null]
**Id** | **string** | Protein ID. | [optional] [default to null]
**Name** | **string** | Protein name. | [optional] [default to null]
**OrgName** | **string** | Organism name. | [optional] [default to null]
**OrgTaxonId** | **int32** | Organism taxonomy ID. | [optional] [default to null]
**OrgTaxonGroupName** | **string** | Organism taxonomy group name. | [optional] [default to null]
**OrgTaxonGroupId** | **int32** | Organism taxonomy group ID. | [optional] [default to null]
**Sequence** | **string** | Protein sequence. | [optional] [default to null]
**MatchingPeptides** | [**[]ProteinMatchingPeptides**](Protein_matchingPeptides.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


