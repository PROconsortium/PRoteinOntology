package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.ArrayList;
import io.swagger.model.ProteinMatchingPeptides;
import java.util.List;
@Canonical
class Protein {

  /* SwissProt or TrEMBL entry. */
  String reviewStatus = null

  /* Protein accession number. */
  String ac = null

  /* Protein ID. */
  String id = null

  /* Protein name. */
  String name = null

  /* Organism name. */
  String orgName = null

  /* Organism taxonomy ID. */
  Integer orgTaxonId = null

  /* Organism taxonomy group name. */
  String orgTaxonGroupName = null

  /* Organism taxonomy group ID. */
  Integer orgTaxonGroupId = null

  /* Protein sequence. */
  String sequence = null

    List<ProteinMatchingPeptides> matchingPeptides = new ArrayList<ProteinMatchingPeptides>()
  

}

