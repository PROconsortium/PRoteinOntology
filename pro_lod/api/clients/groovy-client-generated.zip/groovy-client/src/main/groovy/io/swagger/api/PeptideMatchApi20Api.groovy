package io.swagger.api;

import groovyx.net.http.*
import static groovyx.net.http.ContentType.*
import static groovyx.net.http.Method.*
import io.swagger.api.ApiUtils

import io.swagger.model.Error
import io.swagger.model.Report

import java.util.*;

@Mixin(ApiUtils)
class PeptideMatchApi20Api {
    String basePath = "http://ibm-cloud1.proteininformationresource.org/peptidematchapi2"
    String versionPath = "/api/v1"

    def matchGetGet ( String peptides, String taxonids, Boolean swissprot, Boolean isoform, Boolean uniref100, Boolean leqi, Integer offset, Integer size, Closure onSuccess, Closure onFailure)  {
        // create path and map path parameters (TODO)
        String resourcePath = "/match_get"

        // query params
        def queryParams = [:]
        def headerParams = [:]
    
        // verify required params are set
        if (peptides == null) {
            throw new RuntimeException("missing required params peptides")
        }

        if (!"null".equals(String.valueOf(peptides)))
            queryParams.put("peptides", String.valueOf(peptides))
if (!"null".equals(String.valueOf(taxonids)))
            queryParams.put("taxonids", String.valueOf(taxonids))
if (!"null".equals(String.valueOf(swissprot)))
            queryParams.put("swissprot", String.valueOf(swissprot))
if (!"null".equals(String.valueOf(isoform)))
            queryParams.put("isoform", String.valueOf(isoform))
if (!"null".equals(String.valueOf(uniref100)))
            queryParams.put("uniref100", String.valueOf(uniref100))
if (!"null".equals(String.valueOf(leqi)))
            queryParams.put("leqi", String.valueOf(leqi))
if (!"null".equals(String.valueOf(offset)))
            queryParams.put("offset", String.valueOf(offset))
if (!"null".equals(String.valueOf(size)))
            queryParams.put("size", String.valueOf(size))


        // Also still TODO: form params, body param

        invokeApi(onSuccess, onFailure, basePath, versionPath, resourcePath, queryParams, headerParams,
                    "GET", "",
                    Report.class )
                    
    }
    def matchPostPost ( String peptides, String taxonids, Boolean swissprot, Boolean isoform, Boolean uniref100, Boolean leqi, Integer offset, Integer size, Closure onSuccess, Closure onFailure)  {
        // create path and map path parameters (TODO)
        String resourcePath = "/match_post"

        // query params
        def queryParams = [:]
        def headerParams = [:]
    
        // verify required params are set
        if (peptides == null) {
            throw new RuntimeException("missing required params peptides")
        }

        

        // Also still TODO: form params, body param

        invokeApi(onSuccess, onFailure, basePath, versionPath, resourcePath, queryParams, headerParams,
                    "POST", "",
                    Report.class )
                    
    }
}
