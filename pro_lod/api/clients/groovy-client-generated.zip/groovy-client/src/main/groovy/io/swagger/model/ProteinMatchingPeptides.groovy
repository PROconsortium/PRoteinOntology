package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.ArrayList;
import io.swagger.model.ProteinMatchRange;
import java.util.List;
@Canonical
class ProteinMatchingPeptides {

  /* Query peptide. */
  String peptide = null

    List<ProteinMatchRange> matchRange = new ArrayList<ProteinMatchRange>()
  

}

