package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
@Canonical
class ReportSearchParameters {

  /* NCBI taxonomy IDs. */
  String taxonids = null

  /* Only search SwissProt protein sequences. */
  Boolean swissprot = null

  /* Include isoforms. */
  Boolean isoform = null

  /* Only search UniRef100 protein sequences. */
  Boolean uniref100 = null

  /* Treat Leucine (L) and Isoleucine (I) equivalent. */
  Boolean leqi = null

  /* Off set, page starting point, with default value 0. */
  Integer offset = null

  /* Page size with default value 100. When page size is -1, it returns all records and offset will be ignored. */
  Integer size = null
  

}

