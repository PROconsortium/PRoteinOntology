package io.swagger.model;

import groovy.transform.Canonical
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.ArrayList;
import io.swagger.model.ReportResults;
import io.swagger.model.ReportSearchParameters;
import java.util.List;
@Canonical
class Report {

  /* Number of documents found. */
  Integer numberFound = null

  /* Query response time in milliseocnds. */
  Integer qtime = null

  /* Query response status. */
  Integer status = null

    ReportSearchParameters searchParameters = null

    List<ReportResults> results = new ArrayList<ReportResults>()
  

}

