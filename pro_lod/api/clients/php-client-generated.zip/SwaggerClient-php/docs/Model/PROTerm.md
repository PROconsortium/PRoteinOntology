# PROTerm

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **string** | The PRO ID. | [optional] 
**name** | **string** | The PRO name. | [optional] 
**term_def** | **string** | The PRO term definition. | [optional] 
**category** | **string** | The PRO term category. | [optional] 
**annotation** | [**\Swagger\Client\Model\Annotation[]**](Annotation.md) |  | [optional] 
**any_relationship** | **string** |  | [optional] 
**child** | **string[]** |  | [optional] 
**eco_cyc_id** | **string** |  | [optional] 
**gene_name** | **string** |  | [optional] 
**hgnc_id** | **string[]** |  | [optional] 
**mgi_id** | **string[]** |  | [optional] 
**ortho_isoform** | **string[]** |  | [optional] 
**ortho_modified_form** | **string[]** |  | [optional] 
**panther_id** | **string** |  | [optional] 
**paraent** | **string[]** |  | [optional] 
**pirsf_id** | **string** |  | [optional] 
**pm_id** | **string** |  | [optional] 
**synonym** | **string[]** |  | [optional] 
**reactome_id** | **string[]** |  | [optional] 
**uniprot_kbid** | **string[]** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

