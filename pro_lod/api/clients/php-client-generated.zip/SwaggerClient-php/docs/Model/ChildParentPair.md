# ChildParentPair

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pro** | [**\Swagger\Client\Model\PROTerm**](PROTerm.md) |  | [optional] 
**pro_parent** | [**\Swagger\Client\Model\PROTerm**](PROTerm.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

