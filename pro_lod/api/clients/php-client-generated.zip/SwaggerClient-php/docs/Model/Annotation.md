# Annotation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**modifier** | **string** |  | [optional] 
**relation** | **string** |  | [optional] 
**ontology_id** | **string** |  | [optional] 
**ontology_term** | **string** |  | [optional] 
**relative_to** | **string** |  | [optional] 
**interaction_with** | **string** |  | [optional] 
**evidence** | [**\Swagger\Client\Model\Evidence**](Evidence.md) |  | [optional] 
**ncbi_taxon_id** | **int** |  | [optional] 
**inferred_from** | **string[]** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

