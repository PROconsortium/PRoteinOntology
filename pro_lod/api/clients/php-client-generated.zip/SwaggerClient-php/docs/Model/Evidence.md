# Evidence

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**evidence_source** | **string[]** |  | [optional] 
**evidence_code** | **string** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

