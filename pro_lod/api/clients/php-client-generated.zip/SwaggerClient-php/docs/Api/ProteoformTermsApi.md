# Swagger\Client\ProteoformTermsApi

All URIs are relative to *https://research.bioinformatics.udel.edu/PRO_API/V1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getAcetylatedForms**](ProteoformTermsApi.md#getacetylatedforms) | **GET** /proforms/modification/acetylated | Returns a list of acetylated protein forms.
[**getGlycosylatedForms**](ProteoformTermsApi.md#getglycosylatedforms) | **GET** /proforms/modification/glycosylated | Returns a list of glycosylated protein forms.
[**getMethylatedForms**](ProteoformTermsApi.md#getmethylatedforms) | **GET** /proforms/modification/methylated | Returns a list of methylated protein forms.
[**getModifiedForms**](ProteoformTermsApi.md#getmodifiedforms) | **GET** /proforms/modification | Returns a list of modified protein forms.
[**getOrganismSequenceLevelProteoforms**](ProteoformTermsApi.md#getorganismsequencelevelproteoforms) | **GET** /proforms/organism-sequence | Returns a list of organism-sequence level protein forms.
[**getOrthoIsoForms**](ProteoformTermsApi.md#getorthoisoforms) | **GET** /proforms/orthoisoform | Returns a list of ortho-isoform protein forms.
[**getOrthoModForms**](ProteoformTermsApi.md#getorthomodforms) | **GET** /proforms/orthomodform | Returns a list of ortho-modform protein forms.
[**getPhosphorylatedForms**](ProteoformTermsApi.md#getphosphorylatedforms) | **GET** /proforms/modification/phosphorylated | Returns a list of phosphorylated protein forms.
[**getSequenceLevelProteoforms**](ProteoformTermsApi.md#getsequencelevelproteoforms) | **GET** /proforms/sequence | Returns a list of sequence level protein forms.
[**getUbiquitinatedForms**](ProteoformTermsApi.md#getubiquitinatedforms) | **GET** /proforms/modification/ubiquitinated | Returns a list of ubiquitinated protein forms.

# **getAcetylatedForms**
> \Swagger\Client\Model\PROTerm[] getAcetylatedForms($search_field, $search_value, $show_pro_name, $show_pro_term_definition, $show_category, $show_parent, $show_annotation, $show_any_relationship, $show_child, $show_comment, $show_eco_cyc_id, $show_gene_name, $show_hgncid, $show_mgiid, $show_ortho_isoform, $show_ortho_modified_form, $show_pantherid, $show_pirsfid, $show_pmid, $show_reactome_id, $show_synonym, $show_uni_prot_kbid, $offset, $limit)

Returns a list of acetylated protein forms.

Gets a list of acetylated protein forms and associated information.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\ProteoformTermsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$search_field = "search_field_example"; // string | Search field that needs to be considered for filter
$search_value = "search_value_example"; // string | any string or \"null\" or \"not null\" or a list of space separated ids
$show_pro_name = true; // bool | 
$show_pro_term_definition = true; // bool | 
$show_category = true; // bool | 
$show_parent = true; // bool | 
$show_annotation = false; // bool | 
$show_any_relationship = false; // bool | 
$show_child = false; // bool | 
$show_comment = false; // bool | 
$show_eco_cyc_id = false; // bool | 
$show_gene_name = false; // bool | 
$show_hgncid = false; // bool | 
$show_mgiid = false; // bool | 
$show_ortho_isoform = false; // bool | 
$show_ortho_modified_form = false; // bool | 
$show_pantherid = false; // bool | 
$show_pirsfid = false; // bool | 
$show_pmid = false; // bool | 
$show_reactome_id = false; // bool | 
$show_synonym = false; // bool | 
$show_uni_prot_kbid = false; // bool | 
$offset = 0; // int | The number of items to skip before starting to collect the result set.
$limit = 50; // int | The numbers of items to return.

try {
    $result = $apiInstance->getAcetylatedForms($search_field, $search_value, $show_pro_name, $show_pro_term_definition, $show_category, $show_parent, $show_annotation, $show_any_relationship, $show_child, $show_comment, $show_eco_cyc_id, $show_gene_name, $show_hgncid, $show_mgiid, $show_ortho_isoform, $show_ortho_modified_form, $show_pantherid, $show_pirsfid, $show_pmid, $show_reactome_id, $show_synonym, $show_uni_prot_kbid, $offset, $limit);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProteoformTermsApi->getAcetylatedForms: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search_field** | **string**| Search field that needs to be considered for filter | [optional]
 **search_value** | **string**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional]
 **show_pro_name** | **bool**|  | [optional] [default to true]
 **show_pro_term_definition** | **bool**|  | [optional] [default to true]
 **show_category** | **bool**|  | [optional] [default to true]
 **show_parent** | **bool**|  | [optional] [default to true]
 **show_annotation** | **bool**|  | [optional] [default to false]
 **show_any_relationship** | **bool**|  | [optional] [default to false]
 **show_child** | **bool**|  | [optional] [default to false]
 **show_comment** | **bool**|  | [optional] [default to false]
 **show_eco_cyc_id** | **bool**|  | [optional] [default to false]
 **show_gene_name** | **bool**|  | [optional] [default to false]
 **show_hgncid** | **bool**|  | [optional] [default to false]
 **show_mgiid** | **bool**|  | [optional] [default to false]
 **show_ortho_isoform** | **bool**|  | [optional] [default to false]
 **show_ortho_modified_form** | **bool**|  | [optional] [default to false]
 **show_pantherid** | **bool**|  | [optional] [default to false]
 **show_pirsfid** | **bool**|  | [optional] [default to false]
 **show_pmid** | **bool**|  | [optional] [default to false]
 **show_reactome_id** | **bool**|  | [optional] [default to false]
 **show_synonym** | **bool**|  | [optional] [default to false]
 **show_uni_prot_kbid** | **bool**|  | [optional] [default to false]
 **offset** | **int**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**\Swagger\Client\Model\PROTerm[]**](../Model/PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getGlycosylatedForms**
> \Swagger\Client\Model\PROTerm[] getGlycosylatedForms($search_field, $search_value, $show_pro_name, $show_pro_term_definition, $show_category, $show_parent, $show_annotation, $show_any_relationship, $show_child, $show_comment, $show_eco_cyc_id, $show_gene_name, $show_hgncid, $show_mgiid, $show_ortho_isoform, $show_ortho_modified_form, $show_pantherid, $show_pirsfid, $show_pmid, $show_reactome_id, $show_synonym, $show_uni_prot_kbid, $offset, $limit)

Returns a list of glycosylated protein forms.

Gets a list of glycosylated protein forms and associated information.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\ProteoformTermsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$search_field = "search_field_example"; // string | Search field that needs to be considered for filter
$search_value = "search_value_example"; // string | any string or \"null\" or \"not null\" or a list of space separated ids
$show_pro_name = true; // bool | 
$show_pro_term_definition = true; // bool | 
$show_category = true; // bool | 
$show_parent = true; // bool | 
$show_annotation = false; // bool | 
$show_any_relationship = false; // bool | 
$show_child = false; // bool | 
$show_comment = false; // bool | 
$show_eco_cyc_id = false; // bool | 
$show_gene_name = false; // bool | 
$show_hgncid = false; // bool | 
$show_mgiid = false; // bool | 
$show_ortho_isoform = false; // bool | 
$show_ortho_modified_form = false; // bool | 
$show_pantherid = false; // bool | 
$show_pirsfid = false; // bool | 
$show_pmid = false; // bool | 
$show_reactome_id = false; // bool | 
$show_synonym = false; // bool | 
$show_uni_prot_kbid = false; // bool | 
$offset = 0; // int | The number of items to skip before starting to collect the result set.
$limit = 50; // int | The numbers of items to return.

try {
    $result = $apiInstance->getGlycosylatedForms($search_field, $search_value, $show_pro_name, $show_pro_term_definition, $show_category, $show_parent, $show_annotation, $show_any_relationship, $show_child, $show_comment, $show_eco_cyc_id, $show_gene_name, $show_hgncid, $show_mgiid, $show_ortho_isoform, $show_ortho_modified_form, $show_pantherid, $show_pirsfid, $show_pmid, $show_reactome_id, $show_synonym, $show_uni_prot_kbid, $offset, $limit);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProteoformTermsApi->getGlycosylatedForms: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search_field** | **string**| Search field that needs to be considered for filter | [optional]
 **search_value** | **string**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional]
 **show_pro_name** | **bool**|  | [optional] [default to true]
 **show_pro_term_definition** | **bool**|  | [optional] [default to true]
 **show_category** | **bool**|  | [optional] [default to true]
 **show_parent** | **bool**|  | [optional] [default to true]
 **show_annotation** | **bool**|  | [optional] [default to false]
 **show_any_relationship** | **bool**|  | [optional] [default to false]
 **show_child** | **bool**|  | [optional] [default to false]
 **show_comment** | **bool**|  | [optional] [default to false]
 **show_eco_cyc_id** | **bool**|  | [optional] [default to false]
 **show_gene_name** | **bool**|  | [optional] [default to false]
 **show_hgncid** | **bool**|  | [optional] [default to false]
 **show_mgiid** | **bool**|  | [optional] [default to false]
 **show_ortho_isoform** | **bool**|  | [optional] [default to false]
 **show_ortho_modified_form** | **bool**|  | [optional] [default to false]
 **show_pantherid** | **bool**|  | [optional] [default to false]
 **show_pirsfid** | **bool**|  | [optional] [default to false]
 **show_pmid** | **bool**|  | [optional] [default to false]
 **show_reactome_id** | **bool**|  | [optional] [default to false]
 **show_synonym** | **bool**|  | [optional] [default to false]
 **show_uni_prot_kbid** | **bool**|  | [optional] [default to false]
 **offset** | **int**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**\Swagger\Client\Model\PROTerm[]**](../Model/PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getMethylatedForms**
> \Swagger\Client\Model\PROTerm[] getMethylatedForms($search_field, $search_value, $show_pro_name, $show_pro_term_definition, $show_category, $show_parent, $show_annotation, $show_any_relationship, $show_child, $show_comment, $show_eco_cyc_id, $show_gene_name, $show_hgncid, $show_mgiid, $show_ortho_isoform, $show_ortho_modified_form, $show_pantherid, $show_pirsfid, $show_pmid, $show_reactome_id, $show_synonym, $show_uni_prot_kbid, $offset, $limit)

Returns a list of methylated protein forms.

Gets a list of methylated protein forms and associated information.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\ProteoformTermsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$search_field = "search_field_example"; // string | Search field that needs to be considered for filter
$search_value = "search_value_example"; // string | any string or \"null\" or \"not null\" or a list of space separated ids
$show_pro_name = true; // bool | 
$show_pro_term_definition = true; // bool | 
$show_category = true; // bool | 
$show_parent = true; // bool | 
$show_annotation = false; // bool | 
$show_any_relationship = false; // bool | 
$show_child = false; // bool | 
$show_comment = false; // bool | 
$show_eco_cyc_id = false; // bool | 
$show_gene_name = false; // bool | 
$show_hgncid = false; // bool | 
$show_mgiid = false; // bool | 
$show_ortho_isoform = false; // bool | 
$show_ortho_modified_form = false; // bool | 
$show_pantherid = false; // bool | 
$show_pirsfid = false; // bool | 
$show_pmid = false; // bool | 
$show_reactome_id = false; // bool | 
$show_synonym = false; // bool | 
$show_uni_prot_kbid = false; // bool | 
$offset = 0; // int | The number of items to skip before starting to collect the result set.
$limit = 50; // int | The numbers of items to return.

try {
    $result = $apiInstance->getMethylatedForms($search_field, $search_value, $show_pro_name, $show_pro_term_definition, $show_category, $show_parent, $show_annotation, $show_any_relationship, $show_child, $show_comment, $show_eco_cyc_id, $show_gene_name, $show_hgncid, $show_mgiid, $show_ortho_isoform, $show_ortho_modified_form, $show_pantherid, $show_pirsfid, $show_pmid, $show_reactome_id, $show_synonym, $show_uni_prot_kbid, $offset, $limit);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProteoformTermsApi->getMethylatedForms: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search_field** | **string**| Search field that needs to be considered for filter | [optional]
 **search_value** | **string**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional]
 **show_pro_name** | **bool**|  | [optional] [default to true]
 **show_pro_term_definition** | **bool**|  | [optional] [default to true]
 **show_category** | **bool**|  | [optional] [default to true]
 **show_parent** | **bool**|  | [optional] [default to true]
 **show_annotation** | **bool**|  | [optional] [default to false]
 **show_any_relationship** | **bool**|  | [optional] [default to false]
 **show_child** | **bool**|  | [optional] [default to false]
 **show_comment** | **bool**|  | [optional] [default to false]
 **show_eco_cyc_id** | **bool**|  | [optional] [default to false]
 **show_gene_name** | **bool**|  | [optional] [default to false]
 **show_hgncid** | **bool**|  | [optional] [default to false]
 **show_mgiid** | **bool**|  | [optional] [default to false]
 **show_ortho_isoform** | **bool**|  | [optional] [default to false]
 **show_ortho_modified_form** | **bool**|  | [optional] [default to false]
 **show_pantherid** | **bool**|  | [optional] [default to false]
 **show_pirsfid** | **bool**|  | [optional] [default to false]
 **show_pmid** | **bool**|  | [optional] [default to false]
 **show_reactome_id** | **bool**|  | [optional] [default to false]
 **show_synonym** | **bool**|  | [optional] [default to false]
 **show_uni_prot_kbid** | **bool**|  | [optional] [default to false]
 **offset** | **int**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**\Swagger\Client\Model\PROTerm[]**](../Model/PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getModifiedForms**
> \Swagger\Client\Model\PROTerm[] getModifiedForms($search_field, $search_value, $show_pro_name, $show_pro_term_definition, $show_category, $show_parent, $show_annotation, $show_any_relationship, $show_child, $show_comment, $show_eco_cyc_id, $show_gene_name, $show_hgncid, $show_mgiid, $show_ortho_isoform, $show_ortho_modified_form, $show_pantherid, $show_pirsfid, $show_pmid, $show_reactome_id, $show_synonym, $show_uni_prot_kbid, $offset, $limit)

Returns a list of modified protein forms.

Gets a list of modified protein forms and associated information.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\ProteoformTermsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$search_field = "search_field_example"; // string | Search field that needs to be considered for filter
$search_value = "search_value_example"; // string | any string or \"null\" or \"not null\" or a list of space separated ids
$show_pro_name = true; // bool | 
$show_pro_term_definition = true; // bool | 
$show_category = true; // bool | 
$show_parent = true; // bool | 
$show_annotation = false; // bool | 
$show_any_relationship = false; // bool | 
$show_child = false; // bool | 
$show_comment = false; // bool | 
$show_eco_cyc_id = false; // bool | 
$show_gene_name = false; // bool | 
$show_hgncid = false; // bool | 
$show_mgiid = false; // bool | 
$show_ortho_isoform = false; // bool | 
$show_ortho_modified_form = false; // bool | 
$show_pantherid = false; // bool | 
$show_pirsfid = false; // bool | 
$show_pmid = false; // bool | 
$show_reactome_id = false; // bool | 
$show_synonym = false; // bool | 
$show_uni_prot_kbid = false; // bool | 
$offset = 0; // int | The number of items to skip before starting to collect the result set.
$limit = 50; // int | The numbers of items to return.

try {
    $result = $apiInstance->getModifiedForms($search_field, $search_value, $show_pro_name, $show_pro_term_definition, $show_category, $show_parent, $show_annotation, $show_any_relationship, $show_child, $show_comment, $show_eco_cyc_id, $show_gene_name, $show_hgncid, $show_mgiid, $show_ortho_isoform, $show_ortho_modified_form, $show_pantherid, $show_pirsfid, $show_pmid, $show_reactome_id, $show_synonym, $show_uni_prot_kbid, $offset, $limit);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProteoformTermsApi->getModifiedForms: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search_field** | **string**| Search field that needs to be considered for filter | [optional]
 **search_value** | **string**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional]
 **show_pro_name** | **bool**|  | [optional] [default to true]
 **show_pro_term_definition** | **bool**|  | [optional] [default to true]
 **show_category** | **bool**|  | [optional] [default to true]
 **show_parent** | **bool**|  | [optional] [default to true]
 **show_annotation** | **bool**|  | [optional] [default to false]
 **show_any_relationship** | **bool**|  | [optional] [default to false]
 **show_child** | **bool**|  | [optional] [default to false]
 **show_comment** | **bool**|  | [optional] [default to false]
 **show_eco_cyc_id** | **bool**|  | [optional] [default to false]
 **show_gene_name** | **bool**|  | [optional] [default to false]
 **show_hgncid** | **bool**|  | [optional] [default to false]
 **show_mgiid** | **bool**|  | [optional] [default to false]
 **show_ortho_isoform** | **bool**|  | [optional] [default to false]
 **show_ortho_modified_form** | **bool**|  | [optional] [default to false]
 **show_pantherid** | **bool**|  | [optional] [default to false]
 **show_pirsfid** | **bool**|  | [optional] [default to false]
 **show_pmid** | **bool**|  | [optional] [default to false]
 **show_reactome_id** | **bool**|  | [optional] [default to false]
 **show_synonym** | **bool**|  | [optional] [default to false]
 **show_uni_prot_kbid** | **bool**|  | [optional] [default to false]
 **offset** | **int**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**\Swagger\Client\Model\PROTerm[]**](../Model/PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getOrganismSequenceLevelProteoforms**
> \Swagger\Client\Model\PROTerm[] getOrganismSequenceLevelProteoforms($search_field, $search_value, $show_pro_name, $show_pro_term_definition, $show_category, $show_parent, $show_annotation, $show_any_relationship, $show_child, $show_comment, $show_eco_cyc_id, $show_gene_name, $show_hgncid, $show_mgiid, $show_ortho_isoform, $show_ortho_modified_form, $show_pantherid, $show_pirsfid, $show_pmid, $show_reactome_id, $show_synonym, $show_uni_prot_kbid, $offset, $limit)

Returns a list of organism-sequence level protein forms.

Gets a list of organism-sequence level protein forms and associated information.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\ProteoformTermsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$search_field = "search_field_example"; // string | Search field that needs to be considered for filter
$search_value = "search_value_example"; // string | any string or \"null\" or \"not null\" or a list of space separated ids
$show_pro_name = true; // bool | 
$show_pro_term_definition = true; // bool | 
$show_category = true; // bool | 
$show_parent = true; // bool | 
$show_annotation = false; // bool | 
$show_any_relationship = false; // bool | 
$show_child = false; // bool | 
$show_comment = false; // bool | 
$show_eco_cyc_id = false; // bool | 
$show_gene_name = false; // bool | 
$show_hgncid = false; // bool | 
$show_mgiid = false; // bool | 
$show_ortho_isoform = false; // bool | 
$show_ortho_modified_form = false; // bool | 
$show_pantherid = false; // bool | 
$show_pirsfid = false; // bool | 
$show_pmid = false; // bool | 
$show_reactome_id = false; // bool | 
$show_synonym = false; // bool | 
$show_uni_prot_kbid = false; // bool | 
$offset = 0; // int | The number of items to skip before starting to collect the result set.
$limit = 50; // int | The numbers of items to return.

try {
    $result = $apiInstance->getOrganismSequenceLevelProteoforms($search_field, $search_value, $show_pro_name, $show_pro_term_definition, $show_category, $show_parent, $show_annotation, $show_any_relationship, $show_child, $show_comment, $show_eco_cyc_id, $show_gene_name, $show_hgncid, $show_mgiid, $show_ortho_isoform, $show_ortho_modified_form, $show_pantherid, $show_pirsfid, $show_pmid, $show_reactome_id, $show_synonym, $show_uni_prot_kbid, $offset, $limit);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProteoformTermsApi->getOrganismSequenceLevelProteoforms: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search_field** | **string**| Search field that needs to be considered for filter | [optional]
 **search_value** | **string**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional]
 **show_pro_name** | **bool**|  | [optional] [default to true]
 **show_pro_term_definition** | **bool**|  | [optional] [default to true]
 **show_category** | **bool**|  | [optional] [default to true]
 **show_parent** | **bool**|  | [optional] [default to true]
 **show_annotation** | **bool**|  | [optional] [default to false]
 **show_any_relationship** | **bool**|  | [optional] [default to false]
 **show_child** | **bool**|  | [optional] [default to false]
 **show_comment** | **bool**|  | [optional] [default to false]
 **show_eco_cyc_id** | **bool**|  | [optional] [default to false]
 **show_gene_name** | **bool**|  | [optional] [default to false]
 **show_hgncid** | **bool**|  | [optional] [default to false]
 **show_mgiid** | **bool**|  | [optional] [default to false]
 **show_ortho_isoform** | **bool**|  | [optional] [default to false]
 **show_ortho_modified_form** | **bool**|  | [optional] [default to false]
 **show_pantherid** | **bool**|  | [optional] [default to false]
 **show_pirsfid** | **bool**|  | [optional] [default to false]
 **show_pmid** | **bool**|  | [optional] [default to false]
 **show_reactome_id** | **bool**|  | [optional] [default to false]
 **show_synonym** | **bool**|  | [optional] [default to false]
 **show_uni_prot_kbid** | **bool**|  | [optional] [default to false]
 **offset** | **int**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**\Swagger\Client\Model\PROTerm[]**](../Model/PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getOrthoIsoForms**
> \Swagger\Client\Model\PROTerm[] getOrthoIsoForms($search_field, $search_value, $show_pro_name, $show_pro_term_definition, $show_category, $show_parent, $show_annotation, $show_any_relationship, $show_child, $show_comment, $show_eco_cyc_id, $show_gene_name, $show_hgncid, $show_mgiid, $show_ortho_isoform, $show_ortho_modified_form, $show_pantherid, $show_pirsfid, $show_pmid, $show_reactome_id, $show_synonym, $show_uni_prot_kbid, $offset, $limit)

Returns a list of ortho-isoform protein forms.

Gets a list of ortho-isoform protien forms and associated information.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\ProteoformTermsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$search_field = "search_field_example"; // string | Search field that needs to be considered for filter
$search_value = "search_value_example"; // string | any string or \"null\" or \"not null\" or a list of space separated ids
$show_pro_name = true; // bool | 
$show_pro_term_definition = true; // bool | 
$show_category = true; // bool | 
$show_parent = true; // bool | 
$show_annotation = false; // bool | 
$show_any_relationship = false; // bool | 
$show_child = false; // bool | 
$show_comment = false; // bool | 
$show_eco_cyc_id = false; // bool | 
$show_gene_name = false; // bool | 
$show_hgncid = false; // bool | 
$show_mgiid = false; // bool | 
$show_ortho_isoform = false; // bool | 
$show_ortho_modified_form = false; // bool | 
$show_pantherid = false; // bool | 
$show_pirsfid = false; // bool | 
$show_pmid = false; // bool | 
$show_reactome_id = false; // bool | 
$show_synonym = false; // bool | 
$show_uni_prot_kbid = false; // bool | 
$offset = 0; // int | The number of items to skip before starting to collect the result set.
$limit = 50; // int | The numbers of items to return.

try {
    $result = $apiInstance->getOrthoIsoForms($search_field, $search_value, $show_pro_name, $show_pro_term_definition, $show_category, $show_parent, $show_annotation, $show_any_relationship, $show_child, $show_comment, $show_eco_cyc_id, $show_gene_name, $show_hgncid, $show_mgiid, $show_ortho_isoform, $show_ortho_modified_form, $show_pantherid, $show_pirsfid, $show_pmid, $show_reactome_id, $show_synonym, $show_uni_prot_kbid, $offset, $limit);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProteoformTermsApi->getOrthoIsoForms: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search_field** | **string**| Search field that needs to be considered for filter | [optional]
 **search_value** | **string**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional]
 **show_pro_name** | **bool**|  | [optional] [default to true]
 **show_pro_term_definition** | **bool**|  | [optional] [default to true]
 **show_category** | **bool**|  | [optional] [default to true]
 **show_parent** | **bool**|  | [optional] [default to true]
 **show_annotation** | **bool**|  | [optional] [default to false]
 **show_any_relationship** | **bool**|  | [optional] [default to false]
 **show_child** | **bool**|  | [optional] [default to false]
 **show_comment** | **bool**|  | [optional] [default to false]
 **show_eco_cyc_id** | **bool**|  | [optional] [default to false]
 **show_gene_name** | **bool**|  | [optional] [default to false]
 **show_hgncid** | **bool**|  | [optional] [default to false]
 **show_mgiid** | **bool**|  | [optional] [default to false]
 **show_ortho_isoform** | **bool**|  | [optional] [default to false]
 **show_ortho_modified_form** | **bool**|  | [optional] [default to false]
 **show_pantherid** | **bool**|  | [optional] [default to false]
 **show_pirsfid** | **bool**|  | [optional] [default to false]
 **show_pmid** | **bool**|  | [optional] [default to false]
 **show_reactome_id** | **bool**|  | [optional] [default to false]
 **show_synonym** | **bool**|  | [optional] [default to false]
 **show_uni_prot_kbid** | **bool**|  | [optional] [default to false]
 **offset** | **int**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**\Swagger\Client\Model\PROTerm[]**](../Model/PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getOrthoModForms**
> \Swagger\Client\Model\PROTerm[] getOrthoModForms($search_field, $search_value, $show_pro_name, $show_pro_term_definition, $show_category, $show_parent, $show_annotation, $show_any_relationship, $show_child, $show_comment, $show_eco_cyc_id, $show_gene_name, $show_hgncid, $show_mgiid, $show_ortho_isoform, $show_ortho_modified_form, $show_pantherid, $show_pirsfid, $show_pmid, $show_reactome_id, $show_synonym, $show_uni_prot_kbid, $offset, $limit)

Returns a list of ortho-modform protein forms.

Gets a list of ortho-modform protein forms and associated information.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\ProteoformTermsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$search_field = "search_field_example"; // string | Search field that needs to be considered for filter
$search_value = "search_value_example"; // string | any string or \"null\" or \"not null\" or a list of space separated ids
$show_pro_name = true; // bool | 
$show_pro_term_definition = true; // bool | 
$show_category = true; // bool | 
$show_parent = true; // bool | 
$show_annotation = false; // bool | 
$show_any_relationship = false; // bool | 
$show_child = false; // bool | 
$show_comment = false; // bool | 
$show_eco_cyc_id = false; // bool | 
$show_gene_name = false; // bool | 
$show_hgncid = false; // bool | 
$show_mgiid = false; // bool | 
$show_ortho_isoform = false; // bool | 
$show_ortho_modified_form = false; // bool | 
$show_pantherid = false; // bool | 
$show_pirsfid = false; // bool | 
$show_pmid = false; // bool | 
$show_reactome_id = false; // bool | 
$show_synonym = false; // bool | 
$show_uni_prot_kbid = false; // bool | 
$offset = 0; // int | The number of items to skip before starting to collect the result set.
$limit = 50; // int | The numbers of items to return.

try {
    $result = $apiInstance->getOrthoModForms($search_field, $search_value, $show_pro_name, $show_pro_term_definition, $show_category, $show_parent, $show_annotation, $show_any_relationship, $show_child, $show_comment, $show_eco_cyc_id, $show_gene_name, $show_hgncid, $show_mgiid, $show_ortho_isoform, $show_ortho_modified_form, $show_pantherid, $show_pirsfid, $show_pmid, $show_reactome_id, $show_synonym, $show_uni_prot_kbid, $offset, $limit);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProteoformTermsApi->getOrthoModForms: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search_field** | **string**| Search field that needs to be considered for filter | [optional]
 **search_value** | **string**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional]
 **show_pro_name** | **bool**|  | [optional] [default to true]
 **show_pro_term_definition** | **bool**|  | [optional] [default to true]
 **show_category** | **bool**|  | [optional] [default to true]
 **show_parent** | **bool**|  | [optional] [default to true]
 **show_annotation** | **bool**|  | [optional] [default to false]
 **show_any_relationship** | **bool**|  | [optional] [default to false]
 **show_child** | **bool**|  | [optional] [default to false]
 **show_comment** | **bool**|  | [optional] [default to false]
 **show_eco_cyc_id** | **bool**|  | [optional] [default to false]
 **show_gene_name** | **bool**|  | [optional] [default to false]
 **show_hgncid** | **bool**|  | [optional] [default to false]
 **show_mgiid** | **bool**|  | [optional] [default to false]
 **show_ortho_isoform** | **bool**|  | [optional] [default to false]
 **show_ortho_modified_form** | **bool**|  | [optional] [default to false]
 **show_pantherid** | **bool**|  | [optional] [default to false]
 **show_pirsfid** | **bool**|  | [optional] [default to false]
 **show_pmid** | **bool**|  | [optional] [default to false]
 **show_reactome_id** | **bool**|  | [optional] [default to false]
 **show_synonym** | **bool**|  | [optional] [default to false]
 **show_uni_prot_kbid** | **bool**|  | [optional] [default to false]
 **offset** | **int**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**\Swagger\Client\Model\PROTerm[]**](../Model/PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getPhosphorylatedForms**
> \Swagger\Client\Model\PROTerm[] getPhosphorylatedForms($search_field, $search_value, $show_pro_name, $show_pro_term_definition, $show_category, $show_parent, $show_annotation, $show_any_relationship, $show_child, $show_comment, $show_eco_cyc_id, $show_gene_name, $show_hgncid, $show_mgiid, $show_ortho_isoform, $show_ortho_modified_form, $show_pantherid, $show_pirsfid, $show_pmid, $show_reactome_id, $show_synonym, $show_uni_prot_kbid, $offset, $limit)

Returns a list of phosphorylated protein forms.

Gets a list of phosphorylated protein forms and associated information.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\ProteoformTermsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$search_field = "search_field_example"; // string | Search field that needs to be considered for filter
$search_value = "search_value_example"; // string | any string or \"null\" or \"not null\" or a list of space separated ids
$show_pro_name = true; // bool | 
$show_pro_term_definition = true; // bool | 
$show_category = true; // bool | 
$show_parent = true; // bool | 
$show_annotation = false; // bool | 
$show_any_relationship = false; // bool | 
$show_child = false; // bool | 
$show_comment = false; // bool | 
$show_eco_cyc_id = false; // bool | 
$show_gene_name = false; // bool | 
$show_hgncid = false; // bool | 
$show_mgiid = false; // bool | 
$show_ortho_isoform = false; // bool | 
$show_ortho_modified_form = false; // bool | 
$show_pantherid = false; // bool | 
$show_pirsfid = false; // bool | 
$show_pmid = false; // bool | 
$show_reactome_id = false; // bool | 
$show_synonym = false; // bool | 
$show_uni_prot_kbid = false; // bool | 
$offset = 0; // int | The number of items to skip before starting to collect the result set.
$limit = 50; // int | The numbers of items to return.

try {
    $result = $apiInstance->getPhosphorylatedForms($search_field, $search_value, $show_pro_name, $show_pro_term_definition, $show_category, $show_parent, $show_annotation, $show_any_relationship, $show_child, $show_comment, $show_eco_cyc_id, $show_gene_name, $show_hgncid, $show_mgiid, $show_ortho_isoform, $show_ortho_modified_form, $show_pantherid, $show_pirsfid, $show_pmid, $show_reactome_id, $show_synonym, $show_uni_prot_kbid, $offset, $limit);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProteoformTermsApi->getPhosphorylatedForms: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search_field** | **string**| Search field that needs to be considered for filter | [optional]
 **search_value** | **string**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional]
 **show_pro_name** | **bool**|  | [optional] [default to true]
 **show_pro_term_definition** | **bool**|  | [optional] [default to true]
 **show_category** | **bool**|  | [optional] [default to true]
 **show_parent** | **bool**|  | [optional] [default to true]
 **show_annotation** | **bool**|  | [optional] [default to false]
 **show_any_relationship** | **bool**|  | [optional] [default to false]
 **show_child** | **bool**|  | [optional] [default to false]
 **show_comment** | **bool**|  | [optional] [default to false]
 **show_eco_cyc_id** | **bool**|  | [optional] [default to false]
 **show_gene_name** | **bool**|  | [optional] [default to false]
 **show_hgncid** | **bool**|  | [optional] [default to false]
 **show_mgiid** | **bool**|  | [optional] [default to false]
 **show_ortho_isoform** | **bool**|  | [optional] [default to false]
 **show_ortho_modified_form** | **bool**|  | [optional] [default to false]
 **show_pantherid** | **bool**|  | [optional] [default to false]
 **show_pirsfid** | **bool**|  | [optional] [default to false]
 **show_pmid** | **bool**|  | [optional] [default to false]
 **show_reactome_id** | **bool**|  | [optional] [default to false]
 **show_synonym** | **bool**|  | [optional] [default to false]
 **show_uni_prot_kbid** | **bool**|  | [optional] [default to false]
 **offset** | **int**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**\Swagger\Client\Model\PROTerm[]**](../Model/PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getSequenceLevelProteoforms**
> \Swagger\Client\Model\PROTerm[] getSequenceLevelProteoforms($search_field, $search_value, $show_pro_name, $show_pro_term_definition, $show_category, $show_parent, $show_annotation, $show_any_relationship, $show_child, $show_comment, $show_eco_cyc_id, $show_gene_name, $show_hgncid, $show_mgiid, $show_ortho_isoform, $show_ortho_modified_form, $show_pantherid, $show_pirsfid, $show_pmid, $show_reactome_id, $show_synonym, $show_uni_prot_kbid, $offset, $limit)

Returns a list of sequence level protein forms.

Gets a list of sequence level protein forms and associated information.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\ProteoformTermsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$search_field = "search_field_example"; // string | Search field that needs to be considered for filter
$search_value = "search_value_example"; // string | any string or \"null\" or \"not null\" or a list of space separated ids
$show_pro_name = true; // bool | 
$show_pro_term_definition = true; // bool | 
$show_category = true; // bool | 
$show_parent = true; // bool | 
$show_annotation = false; // bool | 
$show_any_relationship = false; // bool | 
$show_child = false; // bool | 
$show_comment = false; // bool | 
$show_eco_cyc_id = false; // bool | 
$show_gene_name = false; // bool | 
$show_hgncid = false; // bool | 
$show_mgiid = false; // bool | 
$show_ortho_isoform = false; // bool | 
$show_ortho_modified_form = false; // bool | 
$show_pantherid = false; // bool | 
$show_pirsfid = false; // bool | 
$show_pmid = false; // bool | 
$show_reactome_id = false; // bool | 
$show_synonym = false; // bool | 
$show_uni_prot_kbid = false; // bool | 
$offset = 0; // int | The number of items to skip before starting to collect the result set.
$limit = 50; // int | The numbers of items to return.

try {
    $result = $apiInstance->getSequenceLevelProteoforms($search_field, $search_value, $show_pro_name, $show_pro_term_definition, $show_category, $show_parent, $show_annotation, $show_any_relationship, $show_child, $show_comment, $show_eco_cyc_id, $show_gene_name, $show_hgncid, $show_mgiid, $show_ortho_isoform, $show_ortho_modified_form, $show_pantherid, $show_pirsfid, $show_pmid, $show_reactome_id, $show_synonym, $show_uni_prot_kbid, $offset, $limit);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProteoformTermsApi->getSequenceLevelProteoforms: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search_field** | **string**| Search field that needs to be considered for filter | [optional]
 **search_value** | **string**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional]
 **show_pro_name** | **bool**|  | [optional] [default to true]
 **show_pro_term_definition** | **bool**|  | [optional] [default to true]
 **show_category** | **bool**|  | [optional] [default to true]
 **show_parent** | **bool**|  | [optional] [default to true]
 **show_annotation** | **bool**|  | [optional] [default to false]
 **show_any_relationship** | **bool**|  | [optional] [default to false]
 **show_child** | **bool**|  | [optional] [default to false]
 **show_comment** | **bool**|  | [optional] [default to false]
 **show_eco_cyc_id** | **bool**|  | [optional] [default to false]
 **show_gene_name** | **bool**|  | [optional] [default to false]
 **show_hgncid** | **bool**|  | [optional] [default to false]
 **show_mgiid** | **bool**|  | [optional] [default to false]
 **show_ortho_isoform** | **bool**|  | [optional] [default to false]
 **show_ortho_modified_form** | **bool**|  | [optional] [default to false]
 **show_pantherid** | **bool**|  | [optional] [default to false]
 **show_pirsfid** | **bool**|  | [optional] [default to false]
 **show_pmid** | **bool**|  | [optional] [default to false]
 **show_reactome_id** | **bool**|  | [optional] [default to false]
 **show_synonym** | **bool**|  | [optional] [default to false]
 **show_uni_prot_kbid** | **bool**|  | [optional] [default to false]
 **offset** | **int**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**\Swagger\Client\Model\PROTerm[]**](../Model/PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getUbiquitinatedForms**
> \Swagger\Client\Model\PROTerm[] getUbiquitinatedForms($search_field, $search_value, $show_pro_name, $show_pro_term_definition, $show_category, $show_parent, $show_annotation, $show_any_relationship, $show_child, $show_comment, $show_eco_cyc_id, $show_gene_name, $show_hgncid, $show_mgiid, $show_ortho_isoform, $show_ortho_modified_form, $show_pantherid, $show_pirsfid, $show_pmid, $show_reactome_id, $show_synonym, $show_uni_prot_kbid, $offset, $limit)

Returns a list of ubiquitinated protein forms.

Gets a list of ubiquitinated protein forms and associated information.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\ProteoformTermsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$search_field = "search_field_example"; // string | Search field that needs to be considered for filter
$search_value = "search_value_example"; // string | any string or \"null\" or \"not null\" or a list of space separated ids
$show_pro_name = true; // bool | 
$show_pro_term_definition = true; // bool | 
$show_category = true; // bool | 
$show_parent = true; // bool | 
$show_annotation = false; // bool | 
$show_any_relationship = false; // bool | 
$show_child = false; // bool | 
$show_comment = false; // bool | 
$show_eco_cyc_id = false; // bool | 
$show_gene_name = false; // bool | 
$show_hgncid = false; // bool | 
$show_mgiid = false; // bool | 
$show_ortho_isoform = false; // bool | 
$show_ortho_modified_form = false; // bool | 
$show_pantherid = false; // bool | 
$show_pirsfid = false; // bool | 
$show_pmid = false; // bool | 
$show_reactome_id = false; // bool | 
$show_synonym = false; // bool | 
$show_uni_prot_kbid = false; // bool | 
$offset = 0; // int | The number of items to skip before starting to collect the result set.
$limit = 50; // int | The numbers of items to return.

try {
    $result = $apiInstance->getUbiquitinatedForms($search_field, $search_value, $show_pro_name, $show_pro_term_definition, $show_category, $show_parent, $show_annotation, $show_any_relationship, $show_child, $show_comment, $show_eco_cyc_id, $show_gene_name, $show_hgncid, $show_mgiid, $show_ortho_isoform, $show_ortho_modified_form, $show_pantherid, $show_pirsfid, $show_pmid, $show_reactome_id, $show_synonym, $show_uni_prot_kbid, $offset, $limit);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProteoformTermsApi->getUbiquitinatedForms: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search_field** | **string**| Search field that needs to be considered for filter | [optional]
 **search_value** | **string**| any string or \&quot;null\&quot; or \&quot;not null\&quot; or a list of space separated ids | [optional]
 **show_pro_name** | **bool**|  | [optional] [default to true]
 **show_pro_term_definition** | **bool**|  | [optional] [default to true]
 **show_category** | **bool**|  | [optional] [default to true]
 **show_parent** | **bool**|  | [optional] [default to true]
 **show_annotation** | **bool**|  | [optional] [default to false]
 **show_any_relationship** | **bool**|  | [optional] [default to false]
 **show_child** | **bool**|  | [optional] [default to false]
 **show_comment** | **bool**|  | [optional] [default to false]
 **show_eco_cyc_id** | **bool**|  | [optional] [default to false]
 **show_gene_name** | **bool**|  | [optional] [default to false]
 **show_hgncid** | **bool**|  | [optional] [default to false]
 **show_mgiid** | **bool**|  | [optional] [default to false]
 **show_ortho_isoform** | **bool**|  | [optional] [default to false]
 **show_ortho_modified_form** | **bool**|  | [optional] [default to false]
 **show_pantherid** | **bool**|  | [optional] [default to false]
 **show_pirsfid** | **bool**|  | [optional] [default to false]
 **show_pmid** | **bool**|  | [optional] [default to false]
 **show_reactome_id** | **bool**|  | [optional] [default to false]
 **show_synonym** | **bool**|  | [optional] [default to false]
 **show_uni_prot_kbid** | **bool**|  | [optional] [default to false]
 **offset** | **int**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**\Swagger\Client\Model\PROTerm[]**](../Model/PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

