# Swagger\Client\OBOFileApi

All URIs are relative to *https://research.bioinformatics.udel.edu/PRO_API/V1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getOBOByPROIDs**](OBOFileApi.md#getobobyproids) | **GET** /obo/{proIds} | Returns PRO term in OBO format for the given PRO ID(s).

# **getOBOByPROIDs**
> string getOBOByPROIDs($pro_ids)

Returns PRO term in OBO format for the given PRO ID(s).

Gets PRO term in OBO format for the given PRO ID(s).

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\OBOFileApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$pro_ids = "pro_ids_example"; // string | PRO ID(s). Space separated values accepted up to 100.

try {
    $result = $apiInstance->getOBOByPROIDs($pro_ids);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling OBOFileApi->getOBOByPROIDs: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pro_ids** | **string**| PRO ID(s). Space separated values accepted up to 100. |

### Return type

**string**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

