# Swagger\Client\DAGApi

All URIs are relative to *https://research.bioinformatics.udel.edu/PRO_API/V1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getAncestorByProIDs**](DAGApi.md#getancestorbyproids) | **GET** /dag/ancestor/{proIds} | Returns direct and indirect parent PRO terms by the given PRO ID(s).
[**getChildrenByProIDs**](DAGApi.md#getchildrenbyproids) | **GET** /dag/children/{proIds} | Returns direct children PRO terms by the given PRO ID(s).
[**getDescendantByProIDs**](DAGApi.md#getdescendantbyproids) | **GET** /dag/descendant/{proIds} | Returns direct and indirect children PRO terms by the given PRO ID(s).
[**getHierarchyByProID**](DAGApi.md#gethierarchybyproid) | **GET** /dag/hierarchy/{proId} | Returns hierarchy of PRO terms by the given PRO ID.
[**getParentByProIDs**](DAGApi.md#getparentbyproids) | **GET** /dag/parent/{proIds} | Returns direct parent PRO terms by the given PRO ID(s).

# **getAncestorByProIDs**
> \Swagger\Client\Model\PROTerm[] getAncestorByProIDs($pro_ids, $show_pro_name, $show_pro_term_definition, $show_category, $show_parent, $show_annotation, $show_any_relationship, $show_child, $show_comment, $show_eco_cyc_id, $show_gene_name, $show_hgncid, $show_mgiid, $show_ortho_isoform, $show_ortho_modified_form, $show_pantherid, $show_pirsfid, $show_pmid, $show_reactome_id, $show_uni_prot_kbid, $offset, $limit)

Returns direct and indirect parent PRO terms by the given PRO ID(s).

Gets direct and indirect parent PRO terms by the given PRO ID(s) and associated information.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DAGApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$pro_ids = "pro_ids_example"; // string | PRO ID(s). Space separated values accepted up to 100.
$show_pro_name = true; // bool | 
$show_pro_term_definition = true; // bool | 
$show_category = true; // bool | 
$show_parent = true; // bool | 
$show_annotation = false; // bool | 
$show_any_relationship = false; // bool | 
$show_child = false; // bool | 
$show_comment = false; // bool | 
$show_eco_cyc_id = false; // bool | 
$show_gene_name = false; // bool | 
$show_hgncid = false; // bool | 
$show_mgiid = false; // bool | 
$show_ortho_isoform = false; // bool | 
$show_ortho_modified_form = false; // bool | 
$show_pantherid = false; // bool | 
$show_pirsfid = false; // bool | 
$show_pmid = false; // bool | 
$show_reactome_id = false; // bool | 
$show_uni_prot_kbid = false; // bool | 
$offset = 0; // int | The number of items to skip before starting to collect the result set.
$limit = 50; // int | The numbers of items to return.

try {
    $result = $apiInstance->getAncestorByProIDs($pro_ids, $show_pro_name, $show_pro_term_definition, $show_category, $show_parent, $show_annotation, $show_any_relationship, $show_child, $show_comment, $show_eco_cyc_id, $show_gene_name, $show_hgncid, $show_mgiid, $show_ortho_isoform, $show_ortho_modified_form, $show_pantherid, $show_pirsfid, $show_pmid, $show_reactome_id, $show_uni_prot_kbid, $offset, $limit);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DAGApi->getAncestorByProIDs: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pro_ids** | **string**| PRO ID(s). Space separated values accepted up to 100. |
 **show_pro_name** | **bool**|  | [optional] [default to true]
 **show_pro_term_definition** | **bool**|  | [optional] [default to true]
 **show_category** | **bool**|  | [optional] [default to true]
 **show_parent** | **bool**|  | [optional] [default to true]
 **show_annotation** | **bool**|  | [optional] [default to false]
 **show_any_relationship** | **bool**|  | [optional] [default to false]
 **show_child** | **bool**|  | [optional] [default to false]
 **show_comment** | **bool**|  | [optional] [default to false]
 **show_eco_cyc_id** | **bool**|  | [optional] [default to false]
 **show_gene_name** | **bool**|  | [optional] [default to false]
 **show_hgncid** | **bool**|  | [optional] [default to false]
 **show_mgiid** | **bool**|  | [optional] [default to false]
 **show_ortho_isoform** | **bool**|  | [optional] [default to false]
 **show_ortho_modified_form** | **bool**|  | [optional] [default to false]
 **show_pantherid** | **bool**|  | [optional] [default to false]
 **show_pirsfid** | **bool**|  | [optional] [default to false]
 **show_pmid** | **bool**|  | [optional] [default to false]
 **show_reactome_id** | **bool**|  | [optional] [default to false]
 **show_uni_prot_kbid** | **bool**|  | [optional] [default to false]
 **offset** | **int**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**\Swagger\Client\Model\PROTerm[]**](../Model/PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getChildrenByProIDs**
> \Swagger\Client\Model\PROTerm[] getChildrenByProIDs($pro_ids, $show_pro_name, $show_pro_term_definition, $show_category, $show_parent, $show_annotation, $show_any_relationship, $show_child, $show_comment, $show_eco_cyc_id, $show_gene_name, $show_hgncid, $show_mgiid, $show_ortho_isoform, $show_ortho_modified_form, $show_pantherid, $show_pirsfid, $show_pmid, $show_reactome_id, $show_uni_prot_kbid, $offset, $limit)

Returns direct children PRO terms by the given PRO ID(s).

Gets direct children PRO terms by the given PRO ID(s) and associated information.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DAGApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$pro_ids = "pro_ids_example"; // string | PRO ID(s). Space separated values accepted up to 100.
$show_pro_name = true; // bool | 
$show_pro_term_definition = true; // bool | 
$show_category = true; // bool | 
$show_parent = true; // bool | 
$show_annotation = false; // bool | 
$show_any_relationship = false; // bool | 
$show_child = false; // bool | 
$show_comment = false; // bool | 
$show_eco_cyc_id = false; // bool | 
$show_gene_name = false; // bool | 
$show_hgncid = false; // bool | 
$show_mgiid = false; // bool | 
$show_ortho_isoform = false; // bool | 
$show_ortho_modified_form = false; // bool | 
$show_pantherid = false; // bool | 
$show_pirsfid = false; // bool | 
$show_pmid = false; // bool | 
$show_reactome_id = false; // bool | 
$show_uni_prot_kbid = false; // bool | 
$offset = 0; // int | The number of items to skip before starting to collect the result set.
$limit = 50; // int | The numbers of items to return.

try {
    $result = $apiInstance->getChildrenByProIDs($pro_ids, $show_pro_name, $show_pro_term_definition, $show_category, $show_parent, $show_annotation, $show_any_relationship, $show_child, $show_comment, $show_eco_cyc_id, $show_gene_name, $show_hgncid, $show_mgiid, $show_ortho_isoform, $show_ortho_modified_form, $show_pantherid, $show_pirsfid, $show_pmid, $show_reactome_id, $show_uni_prot_kbid, $offset, $limit);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DAGApi->getChildrenByProIDs: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pro_ids** | **string**| PRO ID(s). Space separated values accepted up to 100. |
 **show_pro_name** | **bool**|  | [optional] [default to true]
 **show_pro_term_definition** | **bool**|  | [optional] [default to true]
 **show_category** | **bool**|  | [optional] [default to true]
 **show_parent** | **bool**|  | [optional] [default to true]
 **show_annotation** | **bool**|  | [optional] [default to false]
 **show_any_relationship** | **bool**|  | [optional] [default to false]
 **show_child** | **bool**|  | [optional] [default to false]
 **show_comment** | **bool**|  | [optional] [default to false]
 **show_eco_cyc_id** | **bool**|  | [optional] [default to false]
 **show_gene_name** | **bool**|  | [optional] [default to false]
 **show_hgncid** | **bool**|  | [optional] [default to false]
 **show_mgiid** | **bool**|  | [optional] [default to false]
 **show_ortho_isoform** | **bool**|  | [optional] [default to false]
 **show_ortho_modified_form** | **bool**|  | [optional] [default to false]
 **show_pantherid** | **bool**|  | [optional] [default to false]
 **show_pirsfid** | **bool**|  | [optional] [default to false]
 **show_pmid** | **bool**|  | [optional] [default to false]
 **show_reactome_id** | **bool**|  | [optional] [default to false]
 **show_uni_prot_kbid** | **bool**|  | [optional] [default to false]
 **offset** | **int**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**\Swagger\Client\Model\PROTerm[]**](../Model/PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getDescendantByProIDs**
> \Swagger\Client\Model\PROTerm[] getDescendantByProIDs($pro_ids, $show_pro_name, $show_pro_term_definition, $show_category, $show_parent, $show_annotation, $show_any_relationship, $show_child, $show_comment, $show_eco_cyc_id, $show_gene_name, $show_hgncid, $show_mgiid, $show_ortho_isoform, $show_ortho_modified_form, $show_pantherid, $show_pirsfid, $show_pmid, $show_reactome_id, $show_uni_prot_kbid, $offset, $limit)

Returns direct and indirect children PRO terms by the given PRO ID(s).

Gets direct and indirect children PRO terms by the given PRO ID(s) and associated information.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DAGApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$pro_ids = "pro_ids_example"; // string | PRO ID(s). Space separated values accepted up to 100.
$show_pro_name = true; // bool | 
$show_pro_term_definition = true; // bool | 
$show_category = true; // bool | 
$show_parent = true; // bool | 
$show_annotation = false; // bool | 
$show_any_relationship = false; // bool | 
$show_child = false; // bool | 
$show_comment = false; // bool | 
$show_eco_cyc_id = false; // bool | 
$show_gene_name = false; // bool | 
$show_hgncid = false; // bool | 
$show_mgiid = false; // bool | 
$show_ortho_isoform = false; // bool | 
$show_ortho_modified_form = false; // bool | 
$show_pantherid = false; // bool | 
$show_pirsfid = false; // bool | 
$show_pmid = false; // bool | 
$show_reactome_id = false; // bool | 
$show_uni_prot_kbid = false; // bool | 
$offset = 0; // int | The number of items to skip before starting to collect the result set.
$limit = 50; // int | The numbers of items to return.

try {
    $result = $apiInstance->getDescendantByProIDs($pro_ids, $show_pro_name, $show_pro_term_definition, $show_category, $show_parent, $show_annotation, $show_any_relationship, $show_child, $show_comment, $show_eco_cyc_id, $show_gene_name, $show_hgncid, $show_mgiid, $show_ortho_isoform, $show_ortho_modified_form, $show_pantherid, $show_pirsfid, $show_pmid, $show_reactome_id, $show_uni_prot_kbid, $offset, $limit);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DAGApi->getDescendantByProIDs: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pro_ids** | **string**| PRO ID(s). Space separated values accepted up to 100. |
 **show_pro_name** | **bool**|  | [optional] [default to true]
 **show_pro_term_definition** | **bool**|  | [optional] [default to true]
 **show_category** | **bool**|  | [optional] [default to true]
 **show_parent** | **bool**|  | [optional] [default to true]
 **show_annotation** | **bool**|  | [optional] [default to false]
 **show_any_relationship** | **bool**|  | [optional] [default to false]
 **show_child** | **bool**|  | [optional] [default to false]
 **show_comment** | **bool**|  | [optional] [default to false]
 **show_eco_cyc_id** | **bool**|  | [optional] [default to false]
 **show_gene_name** | **bool**|  | [optional] [default to false]
 **show_hgncid** | **bool**|  | [optional] [default to false]
 **show_mgiid** | **bool**|  | [optional] [default to false]
 **show_ortho_isoform** | **bool**|  | [optional] [default to false]
 **show_ortho_modified_form** | **bool**|  | [optional] [default to false]
 **show_pantherid** | **bool**|  | [optional] [default to false]
 **show_pirsfid** | **bool**|  | [optional] [default to false]
 **show_pmid** | **bool**|  | [optional] [default to false]
 **show_reactome_id** | **bool**|  | [optional] [default to false]
 **show_uni_prot_kbid** | **bool**|  | [optional] [default to false]
 **offset** | **int**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**\Swagger\Client\Model\PROTerm[]**](../Model/PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getHierarchyByProID**
> \Swagger\Client\Model\ChildParentPair[] getHierarchyByProID($pro_id, $show_pro_name, $show_pro_term_definition, $show_category, $show_annotation, $show_any_relationship, $show_comment, $show_eco_cyc_id, $show_gene_name, $show_hgncid, $show_mgiid, $show_ortho_isoform, $show_ortho_modified_form, $show_pantherid, $show_pirsfid, $show_pmid, $show_reactome_id, $show_synonym, $show_taxon_id, $show_uni_prot_kbid)

Returns hierarchy of PRO terms by the given PRO ID.

Gets hierarchy of PRO terms by the given PRO ID.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DAGApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$pro_id = "pro_id_example"; // string | Space separated PRO ID(s).
$show_pro_name = true; // bool | 
$show_pro_term_definition = true; // bool | 
$show_category = true; // bool | 
$show_annotation = false; // bool | 
$show_any_relationship = false; // bool | 
$show_comment = false; // bool | 
$show_eco_cyc_id = false; // bool | 
$show_gene_name = false; // bool | 
$show_hgncid = false; // bool | 
$show_mgiid = false; // bool | 
$show_ortho_isoform = false; // bool | 
$show_ortho_modified_form = false; // bool | 
$show_pantherid = false; // bool | 
$show_pirsfid = false; // bool | 
$show_pmid = false; // bool | 
$show_reactome_id = false; // bool | 
$show_synonym = false; // bool | 
$show_taxon_id = false; // bool | 
$show_uni_prot_kbid = false; // bool | 

try {
    $result = $apiInstance->getHierarchyByProID($pro_id, $show_pro_name, $show_pro_term_definition, $show_category, $show_annotation, $show_any_relationship, $show_comment, $show_eco_cyc_id, $show_gene_name, $show_hgncid, $show_mgiid, $show_ortho_isoform, $show_ortho_modified_form, $show_pantherid, $show_pirsfid, $show_pmid, $show_reactome_id, $show_synonym, $show_taxon_id, $show_uni_prot_kbid);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DAGApi->getHierarchyByProID: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pro_id** | **string**| Space separated PRO ID(s). |
 **show_pro_name** | **bool**|  | [optional] [default to true]
 **show_pro_term_definition** | **bool**|  | [optional] [default to true]
 **show_category** | **bool**|  | [optional] [default to true]
 **show_annotation** | **bool**|  | [optional] [default to false]
 **show_any_relationship** | **bool**|  | [optional] [default to false]
 **show_comment** | **bool**|  | [optional] [default to false]
 **show_eco_cyc_id** | **bool**|  | [optional] [default to false]
 **show_gene_name** | **bool**|  | [optional] [default to false]
 **show_hgncid** | **bool**|  | [optional] [default to false]
 **show_mgiid** | **bool**|  | [optional] [default to false]
 **show_ortho_isoform** | **bool**|  | [optional] [default to false]
 **show_ortho_modified_form** | **bool**|  | [optional] [default to false]
 **show_pantherid** | **bool**|  | [optional] [default to false]
 **show_pirsfid** | **bool**|  | [optional] [default to false]
 **show_pmid** | **bool**|  | [optional] [default to false]
 **show_reactome_id** | **bool**|  | [optional] [default to false]
 **show_synonym** | **bool**|  | [optional] [default to false]
 **show_taxon_id** | **bool**|  | [optional] [default to false]
 **show_uni_prot_kbid** | **bool**|  | [optional] [default to false]

### Return type

[**\Swagger\Client\Model\ChildParentPair[]**](../Model/ChildParentPair.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getParentByProIDs**
> \Swagger\Client\Model\PROTerm[] getParentByProIDs($pro_ids, $show_pro_name, $show_pro_term_definition, $show_category, $show_parent, $show_annotation, $show_any_relationship, $show_child, $show_comment, $show_eco_cyc_id, $show_gene_name, $show_hgncid, $show_mgiid, $show_ortho_isoform, $show_ortho_modified_form, $show_pantherid, $show_pirsfid, $show_pmid, $show_reactome_id, $show_uni_prot_kbid, $offset, $limit)

Returns direct parent PRO terms by the given PRO ID(s).

Gets direct parent PRO terms by the given PRO ID(s) and associated information.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DAGApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$pro_ids = "pro_ids_example"; // string | PRO ID(s). Space separated values accepted up to 100.
$show_pro_name = true; // bool | 
$show_pro_term_definition = true; // bool | 
$show_category = true; // bool | 
$show_parent = true; // bool | 
$show_annotation = false; // bool | 
$show_any_relationship = false; // bool | 
$show_child = false; // bool | 
$show_comment = false; // bool | 
$show_eco_cyc_id = false; // bool | 
$show_gene_name = false; // bool | 
$show_hgncid = false; // bool | 
$show_mgiid = false; // bool | 
$show_ortho_isoform = false; // bool | 
$show_ortho_modified_form = false; // bool | 
$show_pantherid = false; // bool | 
$show_pirsfid = false; // bool | 
$show_pmid = false; // bool | 
$show_reactome_id = false; // bool | 
$show_uni_prot_kbid = false; // bool | 
$offset = 0; // int | The number of items to skip before starting to collect the result set.
$limit = 50; // int | The numbers of items to return.

try {
    $result = $apiInstance->getParentByProIDs($pro_ids, $show_pro_name, $show_pro_term_definition, $show_category, $show_parent, $show_annotation, $show_any_relationship, $show_child, $show_comment, $show_eco_cyc_id, $show_gene_name, $show_hgncid, $show_mgiid, $show_ortho_isoform, $show_ortho_modified_form, $show_pantherid, $show_pirsfid, $show_pmid, $show_reactome_id, $show_uni_prot_kbid, $offset, $limit);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DAGApi->getParentByProIDs: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pro_ids** | **string**| PRO ID(s). Space separated values accepted up to 100. |
 **show_pro_name** | **bool**|  | [optional] [default to true]
 **show_pro_term_definition** | **bool**|  | [optional] [default to true]
 **show_category** | **bool**|  | [optional] [default to true]
 **show_parent** | **bool**|  | [optional] [default to true]
 **show_annotation** | **bool**|  | [optional] [default to false]
 **show_any_relationship** | **bool**|  | [optional] [default to false]
 **show_child** | **bool**|  | [optional] [default to false]
 **show_comment** | **bool**|  | [optional] [default to false]
 **show_eco_cyc_id** | **bool**|  | [optional] [default to false]
 **show_gene_name** | **bool**|  | [optional] [default to false]
 **show_hgncid** | **bool**|  | [optional] [default to false]
 **show_mgiid** | **bool**|  | [optional] [default to false]
 **show_ortho_isoform** | **bool**|  | [optional] [default to false]
 **show_ortho_modified_form** | **bool**|  | [optional] [default to false]
 **show_pantherid** | **bool**|  | [optional] [default to false]
 **show_pirsfid** | **bool**|  | [optional] [default to false]
 **show_pmid** | **bool**|  | [optional] [default to false]
 **show_reactome_id** | **bool**|  | [optional] [default to false]
 **show_uni_prot_kbid** | **bool**|  | [optional] [default to false]
 **offset** | **int**| The number of items to skip before starting to collect the result set. | [optional] [default to 0]
 **limit** | **int**| The numbers of items to return. | [optional] [default to 50]

### Return type

[**\Swagger\Client\Model\PROTerm[]**](../Model/PROTerm.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

