# SwaggerClient::ProteinMatchRange

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**start** | **Integer** |  | [optional] 
**_end** | **Integer** |  | [optional] 
**replaced_locs** | **Array&lt;Integer&gt;** |  | [optional] 


