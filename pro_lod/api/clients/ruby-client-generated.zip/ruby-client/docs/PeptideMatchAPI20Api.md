# SwaggerClient::PeptideMatchAPI20Api

All URIs are relative to *http://ibm-cloud1.proteininformationresource.org/peptidematchapi2*

Method | HTTP request | Description
------------- | ------------- | -------------
[**match_get_get**](PeptideMatchAPI20Api.md#match_get_get) | **GET** /match_get | Do peptide match using GET method.
[**match_post_post**](PeptideMatchAPI20Api.md#match_post_post) | **POST** /match_post | Do peptide match using POST method.


# **match_get_get**
> Report match_get_get(peptides, opts)

Do peptide match using GET method.

Retrieve UniProtKB protein sequences that would exactly match to the query peptides using GET method.

### Example
```ruby
# load the gem
require 'swagger_client'

api_instance = SwaggerClient::PeptideMatchAPI20Api.new

peptides = "AAVEEGIVLGGGCALLR,SVQYDDVPEYK" # String | A list of comma-separated peptide sequences (up to 100). Each sequence consists of 3 or more amino acids.

opts = { 
  taxonids: "9606,10090", # String | A list fo comma-separated NCBI taxonomy IDs.
  swissprot: true, # BOOLEAN | Only search SwissProt protein sequences.
  isoform: true, # BOOLEAN | Include isforms.
  uniref100: false, # BOOLEAN | Only search UniRef100 protein sequences.
  leqi: false, # BOOLEAN | Treat Leucine (L) and Isoleucine (I) equivalent.
  offset: 0, # Integer | Off set, page starting point, with default value 0.
  size: 100 # Integer | Page size with default value 100. When page size is -1, it returns all records and offset will be ignored.
}

begin
  #Do peptide match using GET method.
  result = api_instance.match_get_get(peptides, opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling PeptideMatchAPI20Api->match_get_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **peptides** | **String**| A list of comma-separated peptide sequences (up to 100). Each sequence consists of 3 or more amino acids. | [default to AAVEEGIVLGGGCALLR,SVQYDDVPEYK]
 **taxonids** | **String**| A list fo comma-separated NCBI taxonomy IDs. | [optional] [default to 9606,10090]
 **swissprot** | **BOOLEAN**| Only search SwissProt protein sequences. | [optional] [default to true]
 **isoform** | **BOOLEAN**| Include isforms. | [optional] [default to true]
 **uniref100** | **BOOLEAN**| Only search UniRef100 protein sequences. | [optional] [default to false]
 **leqi** | **BOOLEAN**| Treat Leucine (L) and Isoleucine (I) equivalent. | [optional] [default to false]
 **offset** | **Integer**| Off set, page starting point, with default value 0. | [optional] [default to 0]
 **size** | **Integer**| Page size with default value 100. When page size is -1, it returns all records and offset will be ignored. | [optional] [default to 100]

### Return type

[**Report**](Report.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml, text/x-fasta, text/tab-separated-values



# **match_post_post**
> Report match_post_post(peptides, opts)

Do peptide match using POST method.

Retrieve UniProtKB protein sequences that would exactly match to the query peptides using POST method.

### Example
```ruby
# load the gem
require 'swagger_client'

api_instance = SwaggerClient::PeptideMatchAPI20Api.new

peptides = "AAVEEGIVLGGGCALLR,SVQYDDVPEYK" # String | A list of comma-separated peptide sequences (up to 100). Each sequence consists of 3 or more amino acids.

opts = { 
  taxonids: "9606,10090", # String | A list fo comma-separated NCBI taxonomy IDs.
  swissprot: true, # BOOLEAN | Only search SwissProt protein sequences.
  isoform: true, # BOOLEAN | Include isoforms.
  uniref100: false, # BOOLEAN | Only search UniRef100 protein sequences.
  leqi: false, # BOOLEAN | Treat Leucine (L) and Isoleucine (I) equivalent.
  offset: 0, # Integer | Off set, page starting point, with default value 0.
  size: 100 # Integer | Page size with default value 100. When page size is -1, it returns all records and offset will be ignored.
}

begin
  #Do peptide match using POST method.
  result = api_instance.match_post_post(peptides, opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling PeptideMatchAPI20Api->match_post_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **peptides** | **String**| A list of comma-separated peptide sequences (up to 100). Each sequence consists of 3 or more amino acids. | [default to AAVEEGIVLGGGCALLR,SVQYDDVPEYK]
 **taxonids** | **String**| A list fo comma-separated NCBI taxonomy IDs. | [optional] [default to 9606,10090]
 **swissprot** | **BOOLEAN**| Only search SwissProt protein sequences. | [optional] [default to true]
 **isoform** | **BOOLEAN**| Include isoforms. | [optional] [default to true]
 **uniref100** | **BOOLEAN**| Only search UniRef100 protein sequences. | [optional] [default to false]
 **leqi** | **BOOLEAN**| Treat Leucine (L) and Isoleucine (I) equivalent. | [optional] [default to false]
 **offset** | **Integer**| Off set, page starting point, with default value 0. | [optional] [default to 0]
 **size** | **Integer**| Page size with default value 100. When page size is -1, it returns all records and offset will be ignored. | [optional] [default to 100]

### Return type

[**Report**](Report.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded
 - **Accept**: application/json, application/xml, text/x-fasta, text/tab-separated-values



