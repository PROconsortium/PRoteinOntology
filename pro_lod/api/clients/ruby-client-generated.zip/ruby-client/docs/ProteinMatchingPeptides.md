# SwaggerClient::ProteinMatchingPeptides

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**peptide** | **String** | Query peptide. | [optional] 
**match_range** | [**Array&lt;ProteinMatchRange&gt;**](ProteinMatchRange.md) |  | [optional] 


