# SwaggerClient::Protein

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**review_status** | **String** | SwissProt or TrEMBL entry. | [optional] 
**ac** | **String** | Protein accession number. | [optional] 
**id** | **String** | Protein ID. | [optional] 
**name** | **String** | Protein name. | [optional] 
**org_name** | **String** | Organism name. | [optional] 
**org_taxon_id** | **Integer** | Organism taxonomy ID. | [optional] 
**org_taxon_group_name** | **String** | Organism taxonomy group name. | [optional] 
**org_taxon_group_id** | **Integer** | Organism taxonomy group ID. | [optional] 
**sequence** | **String** | Protein sequence. | [optional] 
**matching_peptides** | [**Array&lt;ProteinMatchingPeptides&gt;**](ProteinMatchingPeptides.md) |  | [optional] 


