# SwaggerClient::ReportResults

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**query_peptide** | **String** | Query peptide sequence. | [optional] 
**proteins** | [**Array&lt;Protein&gt;**](Protein.md) |  | [optional] 


