# SwaggerClient::ReportSearchParameters

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**taxonids** | **String** | NCBI taxonomy IDs. | [optional] 
**swissprot** | **BOOLEAN** | Only search SwissProt protein sequences. | [optional] 
**isoform** | **BOOLEAN** | Include isoforms. | [optional] 
**uniref100** | **BOOLEAN** | Only search UniRef100 protein sequences. | [optional] 
**leqi** | **BOOLEAN** | Treat Leucine (L) and Isoleucine (I) equivalent. | [optional] 
**offset** | **Integer** | Off set, page starting point, with default value 0. | [optional] 
**size** | **Integer** | Page size with default value 100. When page size is -1, it returns all records and offset will be ignored. | [optional] 


