# SwaggerClient::Report

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number_found** | **Integer** | Number of documents found. | [optional] 
**qtime** | **Integer** | Query response time in milliseocnds. | [optional] 
**status** | **Integer** | Query response status. | [optional] 
**search_parameters** | [**ReportSearchParameters**](ReportSearchParameters.md) |  | [optional] 
**results** | [**Array&lt;ReportResults&gt;**](ReportResults.md) |  | [optional] 


